/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      colors: {
        horizon: {
          cyan: '#00f0ff',
          amber: '#ffb800',
          emerald: '#10b981',
          crimson: '#f43f5e',
          dark: '#090d16',
          panel: 'rgba(12, 18, 30, 0.82)',
        }
      }
    },
  },
  plugins: [],
}
