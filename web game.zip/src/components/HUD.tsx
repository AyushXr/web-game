import React from 'react';
import {
  Award,
  Car,
  Compass,
  HelpCircle,
  Pause,
  RotateCcw,
  Sparkles,
  Sun,
  Timer,
  Zap,
} from 'lucide-react';
import {
  HUDTelemetry,
  MinimapBuilding,
  NotificationBanner,
  SaveData,
  TimeOfDayPreset,
} from '../types/game';
import { Minimap } from './Minimap';
import { Speedometer } from './Speedometer';
import { DATA_SHARDS } from '../game/data/worldCatalog';
import { VirtualTouchInput } from '../game/HorizonEngine';
import { audioManager } from '../managers/AudioManager';

interface HUDProps {
  telemetry: HUDTelemetry;
  saveData: SaveData;
  buildings: MinimapBuilding[];
  notification: NotificationBanner | null;
  onPause: () => void;
  onOpenHelp: () => void;
  onOpenMissionsAndGarage: () => void;
  onRestartMission: () => void;
  onInteract: () => void;
  onResetEntity: () => void;
  onCycleTimeOfDay: (next: TimeOfDayPreset) => void;
  onTouchInputChange: (partial: Partial<VirtualTouchInput>) => void;
}

export const HUD: React.FC<HUDProps> = ({
  telemetry,
  saveData,
  buildings,
  notification,
  onPause,
  onOpenHelp,
  onOpenMissionsAndGarage,
  onRestartMission,
  onInteract,
  onResetEntity,
  onCycleTimeOfDay,
  onTouchInputChange,
}) => {
  const mission = telemetry.activeMission;
  const stage = mission ? mission.stages[telemetry.activeStageIndex] : null;
  const xpInCurrentLevel = saveData.xp % 500;
  const xpPercent = Math.min(100, Math.round((xpInCurrentLevel / 500) * 100));

  const nextTimeOfDay = (): TimeOfDayPreset => {
    const order: TimeOfDayPreset[] = ['sunset', 'day', 'night'];
    const idx = order.indexOf(saveData.settings.timeOfDay);
    return order[(idx + 1) % order.length];
  };

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-4 sm:p-5">
      {/* TOP BAR: Mission Panel (Left), Notification Banner (Center), Player Status & Controls (Right) */}
      <div className="flex items-start justify-between gap-4">
        {/* Top-Left: Active Mission Objective Panel */}
        <div className="pointer-events-auto w-72 sm:w-80 bg-slate-950/82 border border-slate-800/90 rounded-2xl p-3.5 backdrop-blur-md shadow-[0_10px_30px_rgba(0,0,0,0.55)]">
          {mission && stage ? (
            <>
              <div className="flex items-center justify-between gap-2 mb-1">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">
                    {mission.code} • {mission.category}
                  </span>
                </div>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                  STAGE {telemetry.activeStageIndex + 1}/{mission.stages.length}
                </span>
              </div>

              <h2 className="text-sm font-extrabold text-white tracking-tight">
                {mission.title}
              </h2>

              <div className="mt-1.5 text-xs font-semibold text-cyan-200 flex items-center justify-between">
                <span className="truncate pr-2">{stage.title}</span>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 shrink-0">
                  {telemetry.distanceToTarget} m
                </span>
              </div>

              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                {stage.instruction}
              </p>

              {/* Time Trial Countdown Timer if active */}
              {telemetry.missionTimerRemaining !== null && (
                <div className="mt-2.5 px-2.5 py-1.5 rounded-lg bg-rose-950/60 border border-rose-500/40 flex items-center justify-between">
                  <span className="text-[11px] font-bold text-rose-300 flex items-center gap-1.5">
                    <Timer className="w-3.5 h-3.5 animate-spin" /> TIME REMAINING
                  </span>
                  <span className="font-mono text-sm font-black text-white">
                    {telemetry.missionTimerRemaining.toFixed(1)}s
                  </span>
                </div>
              )}

              {/* Quick Mission Actions */}
              <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => {
                    audioManager.playUiClick();
                    onOpenMissionsAndGarage();
                  }}
                  className="flex-1 py-1.5 px-2.5 rounded-lg bg-slate-800/90 hover:bg-cyan-500 hover:text-slate-950 text-slate-200 text-[11px] font-bold flex items-center justify-center gap-1.5 transition"
                >
                  <Compass className="w-3.5 h-3.5" />
                  Missions & Garage
                </button>
                <button
                  onClick={() => {
                    audioManager.playUiClick();
                    onRestartMission();
                  }}
                  title="Restart Current Mission"
                  className="p-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </>
          ) : (
            <div className="text-xs text-slate-300">All objectives completed. Free Roam active.</div>
          )}
        </div>

        {/* Top-Center: Notification Banner */}
        <div className="flex-1 flex justify-center pointer-events-none">
          {notification && (
            <div
              key={notification.id}
              className={`max-w-md w-full px-5 py-3.5 rounded-2xl border backdrop-blur-md shadow-2xl transition-all duration-300 text-center ${
                notification.type === 'mission_complete'
                  ? 'bg-emerald-950/90 border-emerald-400/70 shadow-emerald-500/20'
                  : notification.type === 'shard'
                  ? 'bg-amber-950/90 border-amber-400/70 shadow-amber-500/20'
                  : 'bg-slate-950/90 border-cyan-400/60 shadow-cyan-500/20'
              }`}
            >
              <div className="flex items-center justify-center gap-1.5 text-xs font-black uppercase tracking-widest text-white">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{notification.title}</span>
              </div>
              <div className="text-xs text-slate-200 mt-0.5 font-medium">
                {notification.subtitle}
              </div>
              {notification.rewardText && (
                <div className="mt-1.5 inline-block px-3 py-0.5 rounded-full bg-slate-900/90 border border-amber-400/40 text-amber-300 font-mono text-xs font-extrabold">
                  {notification.rewardText}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Top-Right: Credits, XP/Level, Time-of-Day, Help & Pause */}
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          <div className="bg-slate-950/82 border border-slate-800/90 rounded-2xl px-3.5 py-2.5 backdrop-blur-md flex items-center gap-3.5 shadow-lg">
            {/* Level & XP Bar */}
            <div>
              <div className="flex items-center justify-between gap-2 text-[10px] font-bold">
                <span className="text-cyan-400 uppercase tracking-wider">LVL {saveData.level}</span>
                <span className="font-mono text-slate-400">{saveData.xp} XP</span>
              </div>
              <div className="w-24 h-1.5 rounded-full bg-slate-900 overflow-hidden mt-1">
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-300"
                  style={{ width: `${xpPercent}%` }}
                />
              </div>
            </div>

            <div className="h-6 w-px bg-slate-800" />

            {/* Credits */}
            <div>
              <div className="text-[9px] text-slate-400 uppercase tracking-wider">Credits</div>
              <div className="text-sm font-black font-mono text-amber-300">
                ₡ {saveData.credits}
              </div>
            </div>

            <div className="h-6 w-px bg-slate-800 hidden sm:block" />

            {/* Shards */}
            <div className="hidden sm:block">
              <div className="text-[9px] text-slate-400 uppercase tracking-wider">Shards</div>
              <div className="text-xs font-bold font-mono text-emerald-300 flex items-center gap-1">
                <Award className="w-3 h-3 text-amber-400" />
                {saveData.collectedShardIds.length}/{DATA_SHARDS.length}
              </div>
            </div>
          </div>

          {/* Utility Action Buttons */}
          <div className="flex items-center gap-1.5">
            {saveData.settings.showFps && (
              <div className="px-2.5 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] font-mono text-emerald-400">
                {telemetry.fps} FPS
              </div>
            )}

            <button
              onClick={() => {
                audioManager.playUiClick();
                onCycleTimeOfDay(nextTimeOfDay());
              }}
              title="Switch Time of Day Lighting"
              className="px-2.5 py-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span className="capitalize hidden sm:inline">{saveData.settings.timeOfDay}</span>
            </button>

            <button
              onClick={() => {
                audioManager.playUiClick();
                onOpenHelp();
              }}
              title="Controls & Help (H)"
              className="p-2 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-slate-200 transition"
            >
              <HelpCircle className="w-4 h-4 text-cyan-400" />
            </button>

            <button
              onClick={() => {
                audioManager.playUiClick();
                onPause();
              }}
              title="Pause Game (ESC)"
              className="px-3 py-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-slate-100 text-xs font-bold flex items-center gap-1.5 transition"
            >
              <Pause className="w-3.5 h-3.5 text-cyan-400" />
              <span>ESC</span>
            </button>
          </div>
        </div>
      </div>

      {/* BOTTOM BAR: Minimap (Left), Interaction Prompt & Stamina (Center), Speedometer / Vehicle Deploy (Right) */}
      <div className="flex items-end justify-between gap-4">
        {/* Bottom-Left: Live 2D Minimap */}
        <Minimap telemetry={telemetry} buildings={buildings} />

        {/* Bottom-Center: Context-Sensitive Interaction Prompt & On-Foot Stamina */}
        <div className="flex flex-col items-center gap-2 pointer-events-auto mb-1">
          {telemetry.interactionPrompt && (
            <button
              onClick={() => {
                audioManager.playUiClick();
                onInteract();
              }}
              className="px-4 py-2 rounded-xl bg-slate-950/90 hover:bg-cyan-950/90 border border-cyan-400/60 text-cyan-200 text-xs font-bold tracking-wide shadow-[0_0_20px_rgba(0,240,255,0.25)] flex items-center gap-2 transition animate-bounce"
            >
              <Car className="w-4 h-4 text-cyan-400" />
              <span>{telemetry.interactionPrompt}</span>
            </button>
          )}

          {!telemetry.isDriving && telemetry.stamina < 99 && (
            <div className="w-44 bg-slate-950/80 border border-slate-800 rounded-full px-3 py-1 flex items-center gap-2">
              <Zap className="w-3 h-3 text-cyan-400 shrink-0" />
              <div className="flex-1 h-1.5 bg-slate-900 rounded-full overflow-hidden">
                <div
                  className="h-full bg-cyan-400 transition-all duration-75"
                  style={{ width: `${telemetry.stamina}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Bottom-Right: Speedometer when driving OR Quick Vehicle Summon button when on foot */}
        <div className="flex flex-col items-end gap-2">
          <Speedometer telemetry={telemetry} onResetVehicle={onResetEntity} />

          {!telemetry.isDriving && (
            <div className="pointer-events-auto flex items-center gap-2">
              <button
                onClick={() => {
                  audioManager.playUiClick();
                  onOpenMissionsAndGarage();
                }}
                className="px-3.5 py-2 rounded-xl bg-slate-950/85 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-bold flex items-center gap-2 backdrop-blur-md transition shadow-lg"
              >
                <Car className="w-4 h-4 text-amber-400" />
                <span>Summon Vehicle / Garage</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* OPTIONAL ON-SCREEN TOUCH CONTROLS */}
      {saveData.settings.touchControls && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-30 flex items-center gap-6 pointer-events-auto bg-slate-950/80 border border-slate-800 p-3 rounded-2xl backdrop-blur-md">
          <div className="grid grid-cols-3 gap-1.5 w-36">
            <div />
            <button
              onMouseDown={() => onTouchInputChange({ forward: true })}
              onMouseUp={() => onTouchInputChange({ forward: false })}
              onTouchStart={() => onTouchInputChange({ forward: true })}
              onTouchEnd={() => onTouchInputChange({ forward: false })}
              className="py-2 rounded-lg bg-slate-800 active:bg-cyan-500 text-xs font-bold text-white"
            >
              W
            </button>
            <div />
            <button
              onMouseDown={() => onTouchInputChange({ left: true })}
              onMouseUp={() => onTouchInputChange({ left: false })}
              onTouchStart={() => onTouchInputChange({ left: true })}
              onTouchEnd={() => onTouchInputChange({ left: false })}
              className="py-2 rounded-lg bg-slate-800 active:bg-cyan-500 text-xs font-bold text-white"
            >
              A
            </button>
            <button
              onMouseDown={() => onTouchInputChange({ backward: true })}
              onMouseUp={() => onTouchInputChange({ backward: false })}
              onTouchStart={() => onTouchInputChange({ backward: true })}
              onTouchEnd={() => onTouchInputChange({ backward: false })}
              className="py-2 rounded-lg bg-slate-800 active:bg-cyan-500 text-xs font-bold text-white"
            >
              S
            </button>
            <button
              onMouseDown={() => onTouchInputChange({ right: true })}
              onMouseUp={() => onTouchInputChange({ right: false })}
              onTouchStart={() => onTouchInputChange({ right: true })}
              onTouchEnd={() => onTouchInputChange({ right: false })}
              className="py-2 rounded-lg bg-slate-800 active:bg-cyan-500 text-xs font-bold text-white"
            >
              D
            </button>
          </div>

          <div className="flex flex-col gap-1.5">
            <button
              onMouseDown={() => onTouchInputChange({ sprintOrBoost: true })}
              onMouseUp={() => onTouchInputChange({ sprintOrBoost: false })}
              onTouchStart={() => onTouchInputChange({ sprintOrBoost: true })}
              onTouchEnd={() => onTouchInputChange({ sprintOrBoost: false })}
              className="px-3 py-2 rounded-lg bg-amber-500/20 border border-amber-400/50 text-amber-300 text-xs font-bold"
            >
              {telemetry.isDriving ? 'NITRO' : 'SPRINT'}
            </button>
            <button
              onMouseDown={() => onTouchInputChange({ jumpOrBrake: true })}
              onMouseUp={() => onTouchInputChange({ jumpOrBrake: false })}
              onTouchStart={() => onTouchInputChange({ jumpOrBrake: true })}
              onTouchEnd={() => onTouchInputChange({ jumpOrBrake: false })}
              className="px-3 py-2 rounded-lg bg-cyan-500/20 border border-cyan-400/50 text-cyan-300 text-xs font-bold"
            >
              {telemetry.isDriving ? 'DRIFT' : 'JUMP'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
