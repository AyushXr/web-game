import React from 'react';
import {
  Award,
  Car,
  CheckCircle2,
  Compass,
  Cpu,
  HelpCircle,
  Play,
  RotateCcw,
  Settings,
  Sliders,
  Sparkles,
  Sun,
  Trash2,
  Volume2,
  X,
} from 'lucide-react';
import {
  GameSettings,
  GraphicsQuality,
  SaveData,
  TimeOfDayPreset,
  WorldActivityLevel,
} from '../types/game';
import { DATA_SHARDS, MISSIONS, VEHICLE_CATALOG } from '../game/data/worldCatalog';
import { audioManager } from '../managers/AudioManager';

interface ModalWrapperProps {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: React.ReactNode;
  maxWidthClass?: string;
}

const ModalWrapper: React.FC<ModalWrapperProps> = ({
  title,
  subtitle,
  onClose,
  children,
  maxWidthClass = 'max-w-2xl',
}) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-md p-4 pointer-events-auto">
    <div
      className={`w-full ${maxWidthClass} bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-[0_24px_64px_rgba(0,0,0,0.85)] overflow-hidden flex flex-col max-h-[90vh]`}
    >
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50">
        <div>
          <h2 className="text-lg font-extrabold tracking-wide text-white uppercase">{title}</h2>
          {subtitle && <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>}
        </div>
        <button
          onClick={() => {
            audioManager.playUiClick();
            onClose();
          }}
          className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="p-6 overflow-y-auto space-y-5">{children}</div>
    </div>
  </div>
);

/* 1. PAUSE MENU MODAL */
export const PauseModal: React.FC<{
  saveData: SaveData;
  onResume: () => void;
  onRestartMission: () => void;
  onOpenMissions: () => void;
  onOpenSettings: () => void;
  onOpenControls: () => void;
  onOpenResetConfirm: () => void;
  onReturnMainMenu: () => void;
}> = ({
  saveData,
  onResume,
  onRestartMission,
  onOpenMissions,
  onOpenSettings,
  onOpenControls,
  onOpenResetConfirm,
  onReturnMainMenu,
}) => (
  <ModalWrapper
    title="System Paused"
    subtitle="Project Horizon — Tactical Open-World Simulation"
    onClose={onResume}
    maxWidthClass="max-w-md"
  >
    {/* Quick Player Summary */}
    <div className="grid grid-cols-3 gap-2.5 bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 text-center">
      <div>
        <div className="text-[10px] text-slate-400 uppercase">Level</div>
        <div className="text-base font-black text-cyan-400">LVL {saveData.level}</div>
      </div>
      <div>
        <div className="text-[10px] text-slate-400 uppercase">Credits</div>
        <div className="text-base font-black text-amber-400">₡ {saveData.credits}</div>
      </div>
      <div>
        <div className="text-[10px] text-slate-400 uppercase">Missions</div>
        <div className="text-base font-black text-emerald-400">
          {saveData.completedMissionIds.length}/{MISSIONS.length}
        </div>
      </div>
    </div>

    <div className="flex flex-col gap-2.5">
      <button
        onClick={() => {
          audioManager.playUiClick();
          onResume();
        }}
        className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold tracking-wide flex items-center justify-center gap-2 transition shadow-lg shadow-cyan-500/20"
      >
        <Play className="w-4 h-4 fill-current" />
        RESUME GAMEPLAY
      </button>

      <button
        onClick={() => {
          audioManager.playUiClick();
          onOpenMissions();
        }}
        className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold flex items-center justify-between transition"
      >
        <span className="flex items-center gap-2.5">
          <Compass className="w-4 h-4 text-cyan-400" />
          Missions & Garage Deployment
        </span>
        <span className="text-xs text-slate-400">Select / Replay</span>
      </button>

      <button
        onClick={() => {
          audioManager.playUiClick();
          onRestartMission();
          onResume();
        }}
        className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold flex items-center justify-between transition"
      >
        <span className="flex items-center gap-2.5">
          <RotateCcw className="w-4 h-4 text-amber-400" />
          Restart Current Objective
        </span>
      </button>

      <button
        onClick={() => {
          audioManager.playUiClick();
          onOpenSettings();
        }}
        className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold flex items-center justify-between transition"
      >
        <span className="flex items-center gap-2.5">
          <Settings className="w-4 h-4 text-cyan-400" />
          Settings (Graphics, Audio, Controls)
        </span>
      </button>

      <button
        onClick={() => {
          audioManager.playUiClick();
          onOpenControls();
        }}
        className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold flex items-center justify-between transition"
      >
        <span className="flex items-center gap-2.5">
          <HelpCircle className="w-4 h-4 text-cyan-400" />
          Controls & Keybindings
        </span>
      </button>

      <div className="pt-2 border-t border-slate-800 flex gap-2">
        <button
          onClick={() => {
            audioManager.playUiClick();
            onOpenResetConfirm();
          }}
          className="flex-1 py-2.5 px-3 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Reset Save
        </button>

        <button
          onClick={() => {
            audioManager.playUiClick();
            onReturnMainMenu();
          }}
          className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
        >
          Main Menu
        </button>
      </div>
    </div>
  </ModalWrapper>
);

/* 2. SETTINGS MODAL */
export const SettingsModal: React.FC<{
  settings: GameSettings;
  onUpdateSettings: (partial: Partial<GameSettings>) => void;
  onClose: () => void;
}> = ({ settings, onUpdateSettings, onClose }) => (
  <ModalWrapper
    title="System Settings"
    subtitle="Configure graphics presets, world simulation density, audio levels, and camera sensitivity"
    onClose={onClose}
  >
    {/* Graphics & Atmosphere Section */}
    <div className="space-y-3 bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-400">
        <Sun className="w-4 h-4" /> Graphics & Atmosphere
      </div>

      {/* Graphics Quality Preset */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="text-sm font-semibold text-white">Graphics Quality Preset</div>
          <div className="text-xs text-slate-400">Adjusts render resolution scaling and post-processing glow</div>
        </div>
        <div className="flex gap-1.5">
          {(['low', 'medium', 'high'] as GraphicsQuality[]).map((q) => (
            <button
              key={q}
              onClick={() => {
                audioManager.playUiClick();
                onUpdateSettings({ graphicsQuality: q });
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                settings.graphicsQuality === q
                  ? 'bg-cyan-500 text-slate-950'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Time of Day */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-800/70">
        <div>
          <div className="text-sm font-semibold text-white">Time of Day Lighting</div>
          <div className="text-xs text-slate-400">Switch directional sun, sky color palette, and atmospheric fog</div>
        </div>
        <div className="flex gap-1.5">
          {(['day', 'sunset', 'night'] as TimeOfDayPreset[]).map((tod) => (
            <button
              key={tod}
              onClick={() => {
                audioManager.playUiClick();
                onUpdateSettings({ timeOfDay: tod });
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                settings.timeOfDay === tod
                  ? 'bg-amber-400 text-slate-950'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {tod}
            </button>
          ))}
        </div>
      </div>

      {/* Traffic & NPC Density */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-800/70">
        <div>
          <div className="text-sm font-semibold text-white">AI Traffic & Pedestrians</div>
          <div className="text-xs text-slate-400">Disable on lower-performance devices for maximum frame rate</div>
        </div>
        <div className="flex gap-1.5">
          {(['off', 'low', 'high'] as WorldActivityLevel[]).map((lvl) => (
            <button
              key={lvl}
              onClick={() => {
                audioManager.playUiClick();
                onUpdateSettings({ worldActivity: lvl });
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase transition ${
                settings.worldActivity === lvl
                  ? 'bg-emerald-400 text-slate-950'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {lvl}
            </button>
          ))}
        </div>
      </div>

      {/* Shadows & FPS Toggles */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-slate-800/70">
        <button
          onClick={() => onUpdateSettings({ shadowsEnabled: !settings.shadowsEnabled })}
          className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-between transition ${
            settings.shadowsEnabled
              ? 'bg-cyan-950/40 border-cyan-500/50 text-cyan-200'
              : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}
        >
          <span>Dynamic Shadows</span>
          <span>{settings.shadowsEnabled ? 'ON' : 'OFF'}</span>
        </button>

        <button
          onClick={() => onUpdateSettings({ showFps: !settings.showFps })}
          className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-between transition ${
            settings.showFps
              ? 'bg-cyan-950/40 border-cyan-500/50 text-cyan-200'
              : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}
        >
          <span>FPS Telemetry</span>
          <span>{settings.showFps ? 'ON' : 'OFF'}</span>
        </button>

        <button
          onClick={() => onUpdateSettings({ touchControls: !settings.touchControls })}
          className={`p-2.5 rounded-lg border text-xs font-semibold flex items-center justify-between transition ${
            settings.touchControls
              ? 'bg-cyan-950/40 border-cyan-500/50 text-cyan-200'
              : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}
        >
          <span>On-Screen Pad</span>
          <span>{settings.touchControls ? 'ON' : 'OFF'}</span>
        </button>
      </div>
    </div>

    {/* Controls Sensitivity Section */}
    <div className="space-y-3 bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-400">
        <Sliders className="w-4 h-4" /> Camera Sensitivity
      </div>
      <div>
        <div className="flex justify-between text-xs mb-1">
          <span className="text-slate-300">Mouse Look Sensitivity</span>
          <span className="font-mono text-cyan-300">{settings.mouseSensitivity.toFixed(2)}x</span>
        </div>
        <input
          type="range"
          min="0.25"
          max="2.5"
          step="0.05"
          value={settings.mouseSensitivity}
          onChange={(e) => onUpdateSettings({ mouseSensitivity: parseFloat(e.target.value) })}
          className="w-full accent-cyan-400 cursor-pointer"
        />
      </div>
    </div>

    {/* Audio Mixer Section */}
    <div className="space-y-3 bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-400">
        <Volume2 className="w-4 h-4" /> Audio Synthesizer Mixer
      </div>

      <div>
        <div className="flex justify-between text-xs mb-1">
          <span className="text-slate-300">Master Volume</span>
          <span className="font-mono text-cyan-300">{Math.round(settings.masterVolume * 100)}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="1"
          step="0.05"
          value={settings.masterVolume}
          onChange={(e) => onUpdateSettings({ masterVolume: parseFloat(e.target.value) })}
          className="w-full accent-cyan-400 cursor-pointer"
        />
      </div>

      <div>
        <div className="flex justify-between text-xs mb-1">
          <span className="text-slate-300">City Ambience & Pad Volume</span>
          <span className="font-mono text-cyan-300">{Math.round(settings.musicVolume * 100)}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="1"
          step="0.05"
          value={settings.musicVolume}
          onChange={(e) => onUpdateSettings({ musicVolume: parseFloat(e.target.value) })}
          className="w-full accent-cyan-400 cursor-pointer"
        />
      </div>

      <div>
        <div className="flex justify-between text-xs mb-1">
          <span className="text-slate-300">Effects Volume (Engines, Footsteps, UI)</span>
          <span className="font-mono text-cyan-300">{Math.round(settings.sfxVolume * 100)}%</span>
        </div>
        <input
          type="range"
          min="0"
          max="1"
          step="0.05"
          value={settings.sfxVolume}
          onChange={(e) => onUpdateSettings({ sfxVolume: parseFloat(e.target.value) })}
          className="w-full accent-cyan-400 cursor-pointer"
        />
      </div>
    </div>
  </ModalWrapper>
);

/* 3. CONTROLS HELP OVERLAY */
export const ControlsModal: React.FC<{ onClose: () => void }> = ({ onClose }) => (
  <ModalWrapper
    title="Controls & Field Manual"
    subtitle="Keyboard, Mouse, and Vehicle Handling Reference"
    onClose={onClose}
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2.5">
        <div className="text-xs font-bold uppercase tracking-wider text-cyan-400 mb-2">
          Third-Person On-Foot Controls
        </div>
        {[
          ['W / A / S / D or Arrows', 'Move Character'],
          ['Left Shift (Hold)', 'Sprint (Uses Stamina)'],
          ['Spacebar', 'Jump'],
          ['E or F', 'Enter Nearby Vehicle'],
          ['Mouse Drag / Q & C', 'Rotate Camera Orbit'],
          ['Mouse Scroll Wheel', 'Zoom Camera Distance'],
        ].map(([k, desc]) => (
          <div key={k} className="flex items-center justify-between text-xs border-b border-slate-800/60 pb-1.5">
            <span className="font-mono font-bold text-slate-200 bg-slate-800 px-2 py-0.5 rounded">
              {k}
            </span>
            <span className="text-slate-400">{desc}</span>
          </div>
        ))}
      </div>

      <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2.5">
        <div className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
          Vehicle Driving Controls
        </div>
        {[
          ['W / Up Arrow', 'Accelerate Throttle'],
          ['S / Down Arrow', 'Brake / Reverse'],
          ['A / D or Left / Right', 'Steer Front Wheels'],
          ['Spacebar (Hold)', 'Handbrake / Corner Drift'],
          ['Left Shift (Hold)', 'Nitro Boost'],
          ['E or F', 'Exit Vehicle'],
          ['R', 'Reset Vehicle Upright to Road'],
        ].map(([k, desc]) => (
          <div key={k} className="flex items-center justify-between text-xs border-b border-slate-800/60 pb-1.5">
            <span className="font-mono font-bold text-slate-200 bg-slate-800 px-2 py-0.5 rounded">
              {k}
            </span>
            <span className="text-slate-400">{desc}</span>
          </div>
        ))}
      </div>
    </div>

    <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
      <span>
        <strong className="text-cyan-300">[ESC] or [P]</strong> Pause Game
      </span>
      <span>
        <strong className="text-cyan-300">[H]</strong> Toggle Help Overlay
      </span>
      <span>
        <strong className="text-amber-300">Tip:</strong> You can also summon any car or replay any mission from the HUD Mission/Garage Drawer!
      </span>
    </div>
  </ModalWrapper>
);

/* 4. MISSIONS & GARAGE DEPLOYMENT MODAL */
export const MissionAndGarageModal: React.FC<{
  saveData: SaveData;
  onSelectMission: (missionId: string) => void;
  onSummonVehicle: (vehicleId: string) => void;
  onClose: () => void;
}> = ({ saveData, onSelectMission, onSummonVehicle, onClose }) => (
  <ModalWrapper
    title="Mission Command & Horizon Garage"
    subtitle="Launch or replay any district operation, or deploy a vehicle directly to your location"
    onClose={onClose}
    maxWidthClass="max-w-3xl"
  >
    {/* Missions List */}
    <div>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
          <Award className="w-4 h-4" /> District Operations ({saveData.completedMissionIds.length}/{MISSIONS.length} Completed)
        </h3>
        <span className="text-xs text-amber-300 font-mono">
          Data Shards: {saveData.collectedShardIds.length}/{DATA_SHARDS.length}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {MISSIONS.map((m) => {
          const isCompleted = saveData.completedMissionIds.includes(m.id);
          const isActive = saveData.activeMissionId === m.id;
          return (
            <div
              key={m.id}
              className={`p-4 rounded-xl border transition flex flex-col justify-between ${
                isActive
                  ? 'bg-cyan-950/35 border-cyan-400/70'
                  : 'bg-slate-950/65 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded bg-slate-800 text-cyan-300">
                    {m.code} • {m.category}
                  </span>
                  {isCompleted && (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                    </span>
                  )}
                </div>
                <div className="text-sm font-bold text-white mt-1">{m.title}</div>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{m.description}</p>
              </div>

              <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-800/80">
                <span className="text-xs font-mono text-amber-300">
                  +{m.rewardCredits} ₡ • +{m.rewardXp} XP
                </span>
                <button
                  onClick={() => {
                    audioManager.playUiClick();
                    onSelectMission(m.id);
                    onClose();
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    isActive
                      ? 'bg-cyan-500 text-slate-950'
                      : 'bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-slate-200'
                  }`}
                >
                  {isActive ? 'Restart Active' : isCompleted ? 'Replay Mission' : 'Start Mission'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>

    {/* Garage Vehicles */}
    <div className="pt-2 border-t border-slate-800">
      <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5 mb-3">
        <Car className="w-4 h-4" /> Horizon Garage — Instant Vehicle Drop
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {VEHICLE_CATALOG.map((v) => {
          const isSelected = saveData.selectedVehicleId === v.id;
          return (
            <div
              key={v.id}
              className="p-3.5 rounded-xl bg-slate-950/65 border border-slate-800 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">{v.name}</span>
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-white/30"
                    style={{ backgroundColor: v.primaryColor }}
                  />
                </div>
                <div className="text-[10px] text-cyan-400 uppercase tracking-wider font-semibold">
                  {v.category}
                </div>
                <p className="text-xs text-slate-400 mt-1">{v.description}</p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <div className="text-[11px] font-mono text-slate-300">
                  Top: {Math.round(v.topSpeed * 4.75)} km/h
                </div>
                <button
                  onClick={() => {
                    audioManager.playUiClick();
                    onSummonVehicle(v.id);
                    onClose();
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    isSelected
                      ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                      : 'bg-slate-800 hover:bg-amber-400 hover:text-slate-950 text-slate-200'
                  }`}
                >
                  Deploy & Drive
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  </ModalWrapper>
);

/* 5. ABOUT MODAL */
export const AboutModal: React.FC<{ onClose: () => void }> = ({ onClose }) => (
  <ModalWrapper
    title="About Project Horizon"
    subtitle="3D Open-World Browser Action & Driving Game"
    onClose={onClose}
  >
    <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
      <p>
        <strong className="text-white">Project Horizon</strong> is a complete single-player 3D open-world exploration and driving experience built with{' '}
        <span className="text-cyan-300 font-semibold">Babylon.js</span>,{' '}
        <span className="text-cyan-300 font-semibold">TypeScript</span>,{' '}
        <span className="text-cyan-300 font-semibold">React</span>, and{' '}
        <span className="text-cyan-300 font-semibold">Web Audio API</span> procedural synthesis.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
          <div className="font-bold text-white flex items-center gap-1.5 mb-1">
            <Sparkles className="w-4 h-4 text-cyan-400" /> Open-World District
          </div>
          <p className="text-slate-400">
            Explore New Horizon District featuring Central Plaza, Horizon Spire, Westside Auto Garage, Emerald Commons Park, and the South Marina Waterfront.
          </p>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
          <div className="font-bold text-white flex items-center gap-1.5 mb-1">
            <Cpu className="w-4 h-4 text-amber-400" /> Physics & Simulation
          </div>
          <p className="text-slate-400">
            Seamless third-person character locomotion, 4 driveable vehicles with suspension pitch/roll, drift & nitro, plus AI road traffic and sidewalk pedestrians.
          </p>
        </div>
      </div>
    </div>
  </ModalWrapper>
);

/* 6. RESET PROGRESS CONFIRMATION MODAL */
export const ResetConfirmModal: React.FC<{
  onConfirmReset: () => void;
  onCancel: () => void;
}> = ({ onConfirmReset, onCancel }) => (
  <ModalWrapper
    title="Reset Saved Progress?"
    subtitle="This will clear completed missions, credits, XP, and collected data shards."
    onClose={onCancel}
    maxWidthClass="max-w-md"
  >
    <p className="text-xs text-slate-300 leading-relaxed">
      Are you sure you want to reset your saved progress back to Level 1 and Mission 01? Your graphics and audio preferences will be preserved.
    </p>
    <div className="flex gap-3 pt-2">
      <button
        onClick={onCancel}
        className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
      >
        Cancel
      </button>
      <button
        onClick={() => {
          audioManager.playUiClick();
          onConfirmReset();
        }}
        className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition"
      >
        Confirm Reset
      </button>
    </div>
  </ModalWrapper>
);
