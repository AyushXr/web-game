import React from 'react';
import { Flame, Gauge, RotateCcw } from 'lucide-react';
import { HUDTelemetry } from '../types/game';

interface SpeedometerProps {
  telemetry: HUDTelemetry;
  onResetVehicle: () => void;
}

export const Speedometer: React.FC<SpeedometerProps> = ({ telemetry, onResetVehicle }) => {
  if (!telemetry.isDriving) return null;

  const rpmPercent = Math.min(100, Math.max(5, Math.round(((telemetry.rpm - 800) / 7000) * 100)));
  const isRedline = rpmPercent > 82;

  return (
    <div className="pointer-events-auto bg-slate-950/85 border border-slate-800/90 rounded-2xl p-4 w-64 backdrop-blur-md shadow-[0_12px_36px_rgba(0,0,0,0.65)]">
      {/* Header: Vehicle Name & Category */}
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-3">
        <div>
          <div className="text-[10px] uppercase tracking-widest text-cyan-400 font-semibold">
            {telemetry.currentVehicleCategory}
          </div>
          <div className="text-sm font-bold text-white truncate">
            {telemetry.currentVehicleName}
          </div>
        </div>
        <button
          onClick={onResetVehicle}
          title="Reset Vehicle Upright (R)"
          className="px-2 py-1 rounded-md bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] flex items-center gap-1 transition"
        >
          <RotateCcw className="w-3 h-3" />
          <span>[R]</span>
        </button>
      </div>

      {/* Main Speed + Gear Row */}
      <div className="flex items-end justify-between mb-3">
        <div className="flex items-baseline gap-1.5">
          <span className="text-4xl font-black font-mono tracking-tight text-white tabular-nums">
            {String(telemetry.speedKmh).padStart(3, '0')}
          </span>
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            KM/H
          </span>
        </div>

        {/* Gear Indicator Box */}
        <div className="flex items-center gap-2">
          {telemetry.isDrifting && (
            <span className="px-2 py-0.5 rounded bg-amber-500/20 border border-amber-400/50 text-amber-300 text-[10px] font-bold tracking-wider uppercase animate-pulse">
              DRIFT
            </span>
          )}
          <div className="w-10 h-10 rounded-xl bg-slate-900 border border-cyan-500/40 flex flex-col items-center justify-center">
            <span className="text-[9px] text-slate-400 uppercase leading-none">GEAR</span>
            <span className="text-lg font-black font-mono text-cyan-300 leading-tight">
              {telemetry.gear}
            </span>
          </div>
        </div>
      </div>

      {/* RPM Bar */}
      <div className="mb-2.5">
        <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1">
          <span className="flex items-center gap-1">
            <Gauge className="w-3 h-3 text-cyan-400" /> RPM
          </span>
          <span className={isRedline ? 'text-rose-400 font-bold' : 'text-slate-300'}>
            {telemetry.rpm}
          </span>
        </div>
        <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden p-0.5 border border-slate-800">
          <div
            className={`h-full rounded-full transition-all duration-75 ${
              isRedline
                ? 'bg-gradient-to-r from-amber-400 to-rose-500'
                : 'bg-gradient-to-r from-cyan-400 to-blue-500'
            }`}
            style={{ width: `${rpmPercent}%` }}
          />
        </div>
      </div>

      {/* Nitro Boost Bar */}
      <div>
        <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1">
          <span className="flex items-center gap-1">
            <Flame className="w-3 h-3 text-amber-400" /> NITRO [SHIFT]
          </span>
          <span className="text-amber-300">{telemetry.nitro}%</span>
        </div>
        <div className="w-full h-1.5 rounded-full bg-slate-900 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-amber-500 to-yellow-300 transition-all duration-100"
            style={{ width: `${telemetry.nitro}%` }}
          />
        </div>
      </div>
    </div>
  );
};
