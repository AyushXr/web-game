import React from 'react';
import {
  Award,
  Car,
  Compass,
  HelpCircle,
  Info,
  Play,
  RotateCcw,
  Settings,
  Sparkles,
} from 'lucide-react';
import { SaveData } from '../types/game';
import { MISSIONS, VEHICLE_CATALOG } from '../game/data/worldCatalog';
import { audioManager } from '../managers/AudioManager';

interface MainMenuProps {
  saveData: SaveData;
  onStartGame: (spawnInVehicle?: boolean) => void;
  onOpenSettings: () => void;
  onOpenControls: () => void;
  onOpenAbout: () => void;
  onOpenResetConfirm: () => void;
  onSelectVehicle: (vehicleId: string) => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  saveData,
  onStartGame,
  onOpenSettings,
  onOpenControls,
  onOpenAbout,
  onOpenResetConfirm,
  onSelectVehicle,
}) => {
  const selectedCar =
    VEHICLE_CATALOG.find((v) => v.id === saveData.selectedVehicleId) || VEHICLE_CATALOG[0];
  const activeMission =
    MISSIONS.find((m) => m.id === saveData.activeMissionId) || MISSIONS[0];

  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-between p-6 sm:p-10 pointer-events-none bg-gradient-to-r from-slate-950/90 via-slate-950/55 to-transparent">
      {/* Top Bar */}
      <div className="flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/30">
            <Compass className="w-6 h-6 text-slate-950" />
          </div>
          <div>
            <div className="text-[10px] font-bold tracking-[0.28em] text-cyan-400 uppercase">
              Open-World Browser Simulation
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              PROJECT <span className="text-cyan-400">HORIZON</span>
            </h1>
          </div>
        </div>

        {/* Saved Profile Pill */}
        <div className="hidden sm:flex items-center gap-4 px-4 py-2 rounded-xl bg-slate-900/85 border border-slate-800 backdrop-blur-md text-xs">
          <div>
            <span className="text-slate-400 mr-1.5">LEVEL</span>
            <span className="font-bold text-cyan-300">{saveData.level}</span>
          </div>
          <div className="h-3 w-px bg-slate-700" />
          <div>
            <span className="text-slate-400 mr-1.5">CREDITS</span>
            <span className="font-bold text-amber-300">₡ {saveData.credits}</span>
          </div>
          <div className="h-3 w-px bg-slate-700" />
          <div>
            <span className="text-slate-400 mr-1.5">MISSIONS</span>
            <span className="font-bold text-emerald-300">
              {saveData.completedMissionIds.length}/{MISSIONS.length}
            </span>
          </div>
        </div>
      </div>

      {/* Center-Left Main Menu Panel */}
      <div className="my-auto max-w-md w-full space-y-5 pointer-events-auto">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-[11px] font-semibold">
            <Sparkles className="w-3.5 h-3.5" /> New Horizon District • Real-Time 3D
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Explore the downtown skyline on foot or behind the wheel. Complete checkpoint missions, master high-speed street time trials, and recover Horizon Data Shards.
          </p>
        </div>

        {/* Primary Action Buttons */}
        <div className="space-y-2.5">
          {saveData.hasSavedGame ? (
            <>
              <button
                onClick={() => {
                  audioManager.playUiClick();
                  onStartGame(false);
                }}
                className="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black tracking-wide text-sm flex items-center justify-between transition shadow-[0_0_25px_rgba(0,240,255,0.35)]"
              >
                <span className="flex items-center gap-2.5">
                  <Play className="w-4 h-4 fill-current" />
                  CONTINUE PROGRESS
                </span>
                <span className="text-xs font-bold opacity-80">
                  {activeMission.code} • LVL {saveData.level}
                </span>
              </button>

              <button
                onClick={() => {
                  audioManager.playUiClick();
                  onStartGame(true);
                }}
                className="w-full py-3 px-5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/30 text-white font-bold text-xs flex items-center justify-between transition"
              >
                <span className="flex items-center gap-2">
                  <Car className="w-4 h-4 text-amber-400" />
                  PLAY IN {selectedCar.name.toUpperCase()}
                </span>
                <span className="text-amber-300">Instant Drive</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => {
                  audioManager.playUiClick();
                  onStartGame(false);
                }}
                className="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black tracking-wide text-sm flex items-center justify-between transition shadow-[0_0_25px_rgba(0,240,255,0.35)]"
              >
                <span className="flex items-center gap-2.5">
                  <Play className="w-4 h-4 fill-current" />
                  PLAY PROJECT HORIZON
                </span>
                <span className="text-xs font-bold opacity-80">Mission 01</span>
              </button>

              <button
                onClick={() => {
                  audioManager.playUiClick();
                  onStartGame(true);
                }}
                className="w-full py-3 px-5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/30 text-white font-bold text-xs flex items-center justify-between transition"
              >
                <span className="flex items-center gap-2">
                  <Car className="w-4 h-4 text-amber-400" />
                  START IN {selectedCar.name.toUpperCase()}
                </span>
                <span className="text-amber-300">Instant Drive</span>
              </button>
            </>
          )}
        </div>

        {/* Starting Vehicle Quick Selector */}
        <div className="p-3.5 rounded-xl bg-slate-900/85 border border-slate-800 backdrop-blur-md space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Car className="w-3.5 h-3.5 text-cyan-400" /> Preferred Vehicle
            </span>
            <span className="font-bold text-white">{selectedCar.name}</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {VEHICLE_CATALOG.map((v) => {
              const active = v.id === selectedCar.id;
              return (
                <button
                  key={v.id}
                  onClick={() => {
                    audioManager.playUiClick();
                    onSelectVehicle(v.id);
                  }}
                  className={`py-1.5 px-2 rounded-lg text-[10px] font-bold truncate border transition ${
                    active
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                      : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {v.name.split(' ')[0]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Secondary Menu Buttons */}
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => {
              audioManager.playUiClick();
              onOpenSettings();
            }}
            className="py-2.5 px-3 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <Settings className="w-3.5 h-3.5 text-cyan-400" />
            Settings
          </button>

          <button
            onClick={() => {
              audioManager.playUiClick();
              onOpenControls();
            }}
            className="py-2.5 px-3 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
            Controls
          </button>

          <button
            onClick={() => {
              audioManager.playUiClick();
              onOpenAbout();
            }}
            className="py-2.5 px-3 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <Info className="w-3.5 h-3.5 text-cyan-400" />
            About
          </button>
        </div>

        {saveData.hasSavedGame && (
          <button
            onClick={() => {
              audioManager.playUiClick();
              onOpenResetConfirm();
            }}
            className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1.5 transition"
          >
            <RotateCcw className="w-3 h-3" /> Reset Saved Progress
          </button>
        )}
      </div>

      {/* Bottom Footer */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 pointer-events-auto">
        <div className="flex items-center gap-2">
          <Award className="w-3.5 h-3.5 text-cyan-400" />
          <span>Active Objective: {activeMission.code} — {activeMission.title}</span>
        </div>
        <div className="font-mono text-slate-400">
          WASD Move/Drive • SHIFT Sprint/Nitro • E Enter/Exit Car • ESC Pause
        </div>
      </div>
    </div>
  );
};
