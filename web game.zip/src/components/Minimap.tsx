import React, { useEffect, useRef } from 'react';
import { HUDTelemetry, MinimapBuilding } from '../types/game';
import { CityBuilder } from '../game/world/CityBuilder';

interface MinimapProps {
  telemetry: HUDTelemetry;
  buildings: MinimapBuilding[];
}

export const Minimap: React.FC<MinimapProps> = ({ telemetry, buildings }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    const half = size * 0.5;
    // Scale: 1.05 pixels per world meter (~180m radius visible)
    const scale = 1.05;

    ctx.clearRect(0, 0, size, size);

    // Circular radar clip
    ctx.save();
    ctx.beginPath();
    ctx.arc(half, half, half - 2, 0, Math.PI * 2);
    ctx.clip();

    // Background dark radar fill
    ctx.fillStyle = 'rgba(9, 14, 26, 0.92)';
    ctx.fillRect(0, 0, size, size);

    // Subtle radar range rings
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
    ctx.lineWidth = 1;
    for (const r of [35, 70]) {
      ctx.beginPath();
      ctx.arc(half, half, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    const px = telemetry.playerPos.x;
    const pz = telemetry.playerPos.z;

    // World-to-minimap transform (North +Z is UP on the minimap -> canvas -Y)
    const toMapX = (wx: number) => half + (wx - px) * scale;
    const toMapY = (wz: number) => half - (wz - pz) * scale;

    // Draw South Marina Water
    const waterY = toMapY(-132);
    if (waterY < size) {
      ctx.fillStyle = 'rgba(14, 116, 144, 0.35)';
      ctx.fillRect(0, waterY, size, size - waterY);
    }

    // Draw Emerald Park
    const parkX = toMapX(9);
    const parkY = toMapY(51);
    ctx.fillStyle = 'rgba(16, 185, 129, 0.22)';
    ctx.fillRect(parkX, parkY, 42 * scale, 42 * scale);

    // Draw Grid Roads
    ctx.fillStyle = 'rgba(51, 65, 85, 0.85)';
    const rw = CityBuilder.ROAD_WIDTH * scale;
    for (const gx of CityBuilder.GRID_COORDS) {
      const mx = toMapX(gx) - rw * 0.5;
      ctx.fillRect(mx, toMapY(130), rw, 260 * scale);
    }
    for (const gz of CityBuilder.GRID_COORDS) {
      const my = toMapY(gz) - rw * 0.5;
      ctx.fillRect(toMapX(-130), my, 260 * scale, rw);
    }

    // Draw Buildings
    for (const b of buildings) {
      const bx = toMapX(b.x - b.w * 0.5);
      const by = toMapY(b.z + b.d * 0.5);
      ctx.fillStyle = 'rgba(30, 41, 59, 0.95)';
      ctx.strokeStyle = 'rgba(100, 116, 139, 0.45)';
      ctx.lineWidth = 1;
      ctx.fillRect(bx, by, b.w * scale, b.d * scale);
      ctx.strokeRect(bx, by, b.w * scale, b.d * scale);
    }

    // Draw Uncollected Data Shards (amber diamonds)
    for (const s of telemetry.shards) {
      if (s.collected) continue;
      const sx = toMapX(s.x);
      const sy = toMapY(s.z);
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(sx, sy, 3.0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Draw Traffic Vehicles (subtle slate dots)
    ctx.fillStyle = 'rgba(148, 163, 184, 0.7)';
    for (const tv of telemetry.trafficVehicles) {
      const tx = toMapX(tv.x);
      const ty = toMapY(tv.z);
      ctx.fillRect(tx - 2, ty - 2, 4, 4);
    }

    // Draw Driveable Parked Vehicles (emerald markers)
    for (const pv of telemetry.parkedVehicles) {
      const vx = toMapX(pv.x);
      const vy = toMapY(pv.z);
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(vx, vy, 3.8, 0, Math.PI * 2);
      ctx.fill();
    }

    // Draw Active Mission Objective Checkpoint
    if (telemetry.targetPos) {
      let tx = toMapX(telemetry.targetPos.x);
      let ty = toMapY(telemetry.targetPos.z);

      // Clamp to radar edge if outside radius so player always knows which direction to go
      const dx = tx - half;
      const dy = ty - half;
      const dist = Math.hypot(dx, dy);
      const maxR = half - 12;
      if (dist > maxR) {
        tx = half + (dx / dist) * maxR;
        ty = half + (dy / dist) * maxR;
      }

      // Line from player center to checkpoint
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.45)';
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(half, half);
      ctx.lineTo(tx, ty);
      ctx.stroke();
      ctx.setLineDash([]);

      // Target pulsing ring
      ctx.fillStyle = '#00f0ff';
      ctx.beginPath();
      ctx.arc(tx, ty, 5.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(tx, ty, 8.5, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Draw Player Arrow at Center
    ctx.save();
    ctx.translate(half, half);
    ctx.rotate(telemetry.playerHeading);
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0ea5e9';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, -7);
    ctx.lineTo(5.5, 6);
    ctx.lineTo(0, 3.2);
    ctx.lineTo(-5.5, 6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    ctx.restore();
  }, [telemetry, buildings]);

  return (
    <div className="flex flex-col items-start gap-1.5 pointer-events-auto">
      <div className="relative rounded-full p-1 bg-slate-950/85 border border-cyan-500/40 shadow-[0_0_24px_rgba(0,240,255,0.18)] backdrop-blur-md">
        <canvas ref={canvasRef} width={168} height={168} className="rounded-full block" />
        {/* North Badge */}
        <div className="absolute -top-2 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded bg-slate-900 border border-cyan-400/50 text-[10px] font-bold text-cyan-300 tracking-wider">
          N
        </div>
      </div>

      <div className="px-3 py-1.5 rounded-lg bg-slate-950/80 border border-slate-800/90 backdrop-blur-md flex items-center gap-2.5 text-xs">
        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
        <span className="font-semibold text-slate-100 tracking-wide">
          {telemetry.districtName}
        </span>
        <span className="text-slate-400 font-mono text-[11px]">
          {Math.round(telemetry.playerPos.x)}, {Math.round(telemetry.playerPos.z)}
        </span>
      </div>
    </div>
  );
};
