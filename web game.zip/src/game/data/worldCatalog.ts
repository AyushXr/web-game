import { MissionDefinition, VehicleSpec, Vec3 } from '../../types/game';

export const PLAYER_SPAWN_POS: Vec3 = { x: 0, y: 0, z: -48 };

export const VEHICLE_CATALOG: VehicleSpec[] = [
  {
    id: 'horizon-gtr',
    name: 'Horizon GT-R Apex',
    category: 'Sports Coupe',
    topSpeed: 40, // ~190 km/h
    acceleration: 25,
    handling: 3.1,
    braking: 36,
    primaryColor: '#00d2ff',
    secondaryColor: '#0f172a',
    neonColor: '#00f0ff',
    description: 'Twin-turbo all-wheel-drive coupe engineered for tight downtown corners and rapid sprints.',
    spawnPos: { x: 8, y: 0, z: -40 },
    spawnRotY: 0,
  },
  {
    id: 'solaris-v8',
    name: 'Solaris V8 Interceptor',
    category: 'Hyper Intercept',
    topSpeed: 45, // ~215 km/h
    acceleration: 29,
    handling: 3.3,
    braking: 40,
    primaryColor: '#f43f5e',
    secondaryColor: '#111827',
    neonColor: '#fb7185',
    description: 'High-downforce carbon supercar parked at the Horizon Garage showcase bay.',
    spawnPos: { x: -46, y: 0, z: -38 },
    spawnRotY: Math.PI / 2,
  },
  {
    id: 'vanguard-sedan',
    name: 'Vanguard Executive S',
    category: 'Street Sedan',
    topSpeed: 34, // ~160 km/h
    acceleration: 20,
    handling: 2.8,
    braking: 32,
    primaryColor: '#f59e0b',
    secondaryColor: '#1e293b',
    neonColor: '#fbbf24',
    description: 'Balanced executive sports sedan with smooth suspension and predictable drift recovery.',
    spawnPos: { x: 46, y: 0, z: 10 },
    spawnRotY: -Math.PI / 2,
  },
  {
    id: 'atlas-overland',
    name: 'Atlas 4x4 Defender',
    category: 'Tactical SUV',
    topSpeed: 32, // ~150 km/h
    acceleration: 22,
    handling: 2.6,
    braking: 34,
    primaryColor: '#10b981',
    secondaryColor: '#0f172a',
    neonColor: '#34d399',
    description: 'Heavy-duty utility rig built for curb hopping, park trails, and urban exploration.',
    spawnPos: { x: -10, y: 0, z: 54 },
    spawnRotY: Math.PI,
  },
];

export const MISSIONS: MissionDefinition[] = [
  {
    id: 'mission-01',
    code: 'MISSION 01',
    title: 'Reach the Destination',
    category: 'Story Objective',
    description:
      'Welcome to New Horizon District. Walk or take the Horizon GT-R parked nearby and travel north along Central Avenue to the Horizon Tower Plaza beacon.',
    rewardCredits: 500,
    rewardXp: 250,
    recommendedMode: 'any',
    stages: [
      {
        id: 'm1-s1',
        title: 'Reach Horizon Tower Plaza',
        instruction: 'Head north up Central Avenue (on foot or by car) and enter the glowing cyan checkpoint beacon at Central Plaza.',
        targetPos: { x: 0, y: 0, z: 18 },
        radius: 6.5,
      },
    ],
  },
  {
    id: 'mission-02',
    code: 'MISSION 02',
    title: 'Downtown Express Delivery',
    category: 'Express Delivery',
    description:
      'Retrieve an encrypted architectural core from the Westside Tech Garage and transport it safely to the East Harbor Terminal.',
    rewardCredits: 850,
    rewardXp: 400,
    recommendedMode: 'vehicle',
    stages: [
      {
        id: 'm2-s1',
        title: 'Collect Core at Horizon Garage',
        instruction: 'Drive or sprint to the Westside Horizon Garage bay to pick up the encrypted data core.',
        targetPos: { x: -58, y: 0, z: -32 },
        radius: 6.5,
      },
      {
        id: 'm2-s2',
        title: 'Pass North Cross Intersection',
        instruction: 'Cut across the North Crosstown Avenue checkpoint toward the East District.',
        targetPos: { x: 0, y: 0, z: 60 },
        radius: 7.0,
      },
      {
        id: 'm2-s3',
        title: 'Deliver to East Harbor Terminal',
        instruction: 'Deliver the payload to the Eastside Logistics Plaza before the signal decays.',
        targetPos: { x: 60, y: 0, z: -60 },
        radius: 7.0,
      },
    ],
  },
  {
    id: 'mission-03',
    code: 'MISSION 03',
    title: 'Sunset Boulevard Circuit',
    category: 'Time Trial',
    description:
      'Push your driving skills to the limit. Hit all 4 street checkpoints around the New Horizon perimeter loop before the countdown expires.',
    rewardCredits: 1200,
    rewardXp: 600,
    recommendedMode: 'vehicle',
    stages: [
      {
        id: 'm3-s1',
        title: 'Gate 1/4: West Avenue Sprint',
        instruction: 'Accelerate through the West Avenue Gate before time runs out!',
        targetPos: { x: -60, y: 0, z: 0 },
        radius: 7.5,
        timeLimitSeconds: 45,
      },
      {
        id: 'm3-s2',
        title: 'Gate 2/4: North Skyline Corner',
        instruction: 'Drift right at the North Skyline intersection and hit Gate 2!',
        targetPos: { x: -60, y: 0, z: 60 },
        radius: 7.5,
        timeLimitSeconds: 45,
      },
      {
        id: 'm3-s3',
        title: 'Gate 3/4: Emerald Park Straight',
        instruction: 'Full throttle east across the northern boulevard to Gate 3!',
        targetPos: { x: 60, y: 0, z: 60 },
        radius: 7.5,
        timeLimitSeconds: 45,
      },
      {
        id: 'm3-s4',
        title: 'Gate 4/4: Grand Finish Line',
        instruction: 'Blast south down East Boulevard to cross the finish beacon!',
        targetPos: { x: 60, y: 0, z: 0 },
        radius: 8.0,
        timeLimitSeconds: 45,
      },
    ],
  },
  {
    id: 'mission-04',
    code: 'MISSION 04',
    title: 'Skyline & Park Reconnaissance',
    category: 'Reconnaissance',
    description:
      'Survey the district landmarks: visit Emerald Central Park, inspect the Northeast Observation Plaza, and return to South Marina Boardwalk.',
    rewardCredits: 1500,
    rewardXp: 800,
    recommendedMode: 'any',
    stages: [
      {
        id: 'm4-s1',
        title: 'Survey Emerald Park Pavilion',
        instruction: 'Enter the Emerald Park courtyard in the northeast sector.',
        targetPos: { x: 30, y: 0, z: 32 },
        radius: 6.5,
      },
      {
        id: 'm4-s2',
        title: 'Scan North Apex Intersection',
        instruction: 'Proceed to the North Apex Tower overlook.',
        targetPos: { x: 0, y: 0, z: 112 },
        radius: 7.0,
      },
      {
        id: 'm4-s3',
        title: 'Return to South Marina Promenade',
        instruction: 'Head south down Central Avenue to the Marina Waterfront.',
        targetPos: { x: 0, y: 0, z: -108 },
        radius: 7.5,
      },
    ],
  },
];

export interface DataShardDef {
  id: string;
  name: string;
  pos: Vec3;
}

export const DATA_SHARDS: DataShardDef[] = [
  { id: 'shard-01', name: 'Central Plaza Shard', pos: { x: -12, y: 1.2, z: -18 } },
  { id: 'shard-02', name: 'Horizon Garage Rooftop Edge', pos: { x: -46, y: 1.2, z: -22 } },
  { id: 'shard-03', name: 'Emerald Park Fountain Shard', pos: { x: 30, y: 1.2, z: 24 } },
  { id: 'shard-04', name: 'North Boulevard Shard', pos: { x: 0, y: 1.2, z: 85 } },
  { id: 'shard-05', name: 'East Financial Alley Shard', pos: { x: 84, y: 1.2, z: -28 } },
  { id: 'shard-06', name: 'South Waterfront Pier Shard', pos: { x: 26, y: 1.2, z: -112 } },
  { id: 'shard-07', name: 'West Tech Block Shard', pos: { x: -88, y: 1.2, z: 30 } },
  { id: 'shard-08', name: 'Apex Tower Courtyard Shard', pos: { x: -28, y: 1.2, z: 88 } },
];

export function getDistrictName(x: number, z: number): string {
  if (z < -85) return 'South Marina Waterfront';
  if (x < -35 && z < 0) return 'Westside Auto & Tech District';
  if (x > 12 && x < 52 && z > 8 && z < 52) return 'Emerald Commons Park';
  if (Math.abs(x) < 28 && Math.abs(z) < 35) return 'Horizon Tower Central Plaza';
  if (z > 70) return 'North Skyline Quarter';
  if (x > 45) return 'East Financial Boulevard';
  return 'New Horizon Downtown Core';
}
