import {
  Color3,
  Mesh,
  MeshBuilder,
  Scene,
  ShadowGenerator,
  TransformNode,
  Vector3,
} from '@babylonjs/core';
import { MaterialLibrary } from '../materials/MaterialLibrary';
import { CollisionSystem } from '../systems/CollisionSystem';
import { MinimapBuilding } from '../../types/game';

export class CityBuilder {
  private scene: Scene;
  private materials: MaterialLibrary;
  private collision: CollisionSystem;
  private shadowGen: ShadowGenerator | null;
  private rootNode: TransformNode;
  private minimapBuildings: MinimapBuilding[] = [];

  public static readonly GRID_COORDS = [-120, -60, 0, 60, 120];
  public static readonly ROAD_WIDTH = 14;

  constructor(
    scene: Scene,
    materials: MaterialLibrary,
    collision: CollisionSystem,
    shadowGen: ShadowGenerator | null
  ) {
    this.scene = scene;
    this.materials = materials;
    this.collision = collision;
    this.shadowGen = shadowGen;
    this.rootNode = new TransformNode('cityRoot', this.scene);
  }

  public buildCity(): MinimapBuilding[] {
    this.minimapBuildings = [];
    this.buildGroundAndWater();
    this.buildRoadNetwork();
    this.buildSpecialLandmarks();
    this.buildCityBlocks();
    this.buildStreetlightsAndTrees();
    this.buildDistantSkyline();
    return this.minimapBuildings;
  }

  private buildGroundAndWater(): void {
    // Base urban concrete/sidewalk ground
    const ground = MeshBuilder.CreateGround(
      'cityGround',
      { width: 360, height: 360 },
      this.scene
    );
    ground.position.y = -0.02;
    ground.material = this.materials.getSidewalkMaterial();
    ground.receiveShadows = true;
    ground.parent = this.rootNode;

    // South Marina ocean water
    const water = MeshBuilder.CreateGround(
      'marinaWater',
      { width: 650, height: 260 },
      this.scene
    );
    water.position.set(0, -0.35, -260);
    water.material = this.materials.getWaterMaterial();
    water.parent = this.rootNode;

    // Waterfront seawall curb at z = -132
    const seawall = MeshBuilder.CreateBox(
      'seawall',
      { width: 340, height: 1.2, depth: 2.5 },
      this.scene
    );
    seawall.position.set(0, 0.4, -132);
    seawall.material = this.materials.getSolidPBR('seawall', '#334155', 0.1, 0.8);
    seawall.parent = this.rootNode;
    this.collision.addBoxCollider('seawall_col', 0, 0.5, -132, 340, 2.0, 2.5);
  }

  private buildRoadNetwork(): void {
    const coords = CityBuilder.GRID_COORDS;
    const rw = CityBuilder.ROAD_WIDTH;
    const interMat = this.materials.getIntersectionMaterial();
    const nsMat = this.materials.getRoadMaterial('ns');
    const ewMat = this.materials.getRoadMaterial('ew');

    // 25 Intersections
    for (const x of coords) {
      for (const z of coords) {
        const inter = MeshBuilder.CreateGround(
          `inter_${x}_${z}`,
          { width: rw, height: rw },
          this.scene
        );
        inter.position.set(x, 0.01, z);
        inter.material = interMat;
        inter.receiveShadows = true;
        inter.parent = this.rootNode;
      }
    }

    // North-South road segments
    for (const x of coords) {
      for (let i = 0; i < coords.length - 1; i++) {
        const z1 = coords[i];
        const z2 = coords[i + 1];
        const segLen = z2 - z1 - rw;
        const midZ = (z1 + z2) * 0.5;

        const seg = MeshBuilder.CreateGround(
          `road_ns_${x}_${i}`,
          { width: rw, height: segLen },
          this.scene
        );
        seg.position.set(x, 0.01, midZ);
        seg.material = nsMat;
        seg.receiveShadows = true;
        seg.parent = this.rootNode;
      }
    }

    // East-West road segments
    for (const z of coords) {
      for (let i = 0; i < coords.length - 1; i++) {
        const x1 = coords[i];
        const x2 = coords[i + 1];
        const segLen = x2 - x1 - rw;
        const midX = (x1 + x2) * 0.5;

        const seg = MeshBuilder.CreateGround(
          `road_ew_${z}_${i}`,
          { width: segLen, height: rw },
          this.scene
        );
        seg.position.set(midX, 0.01, z);
        seg.material = ewMat;
        seg.receiveShadows = true;
        seg.parent = this.rootNode;
      }
    }
  }

  private buildSpecialLandmarks(): void {
    // 1. HORIZON TOWER & CENTRAL PLAZA (North of Center Intersection at x=0, z=36)
    const plazaFloor = MeshBuilder.CreateGround(
      'horizonPlazaFloor',
      { width: 38, height: 38 },
      this.scene
    );
    plazaFloor.position.set(0, 0.02, 32);
    plazaFloor.material = this.materials.getPlazaMaterial();
    plazaFloor.receiveShadows = true;
    plazaFloor.parent = this.rootNode;

    // Horizon Spire Skyscraper (at x=0, z=43 so x=0, z=18 is open plaza in front of it)
    this.createSkyscraper({
      id: 'horizon_spire',
      x: 0,
      z: 42,
      w: 18,
      d: 14,
      h: 64,
      style: 0,
      neonHex: '#00f0ff',
      hasSpire: true,
    });

    // Spawn Welcome Archway over Central Ave South (x=0, z=-34)
    const archLeft = MeshBuilder.CreateBox('archL', { width: 1.4, height: 9, depth: 1.4 }, this.scene);
    archLeft.position.set(-8.5, 4.5, -34);
    archLeft.material = this.materials.getSolidPBR('archPillar', '#1e293b', 0.6, 0.3);
    archLeft.parent = this.rootNode;
    this.collision.addBoxCollider('archL_col', -8.5, 4.5, -34, 1.4, 9, 1.4);

    const archRight = MeshBuilder.CreateBox('archR', { width: 1.4, height: 9, depth: 1.4 }, this.scene);
    archRight.position.set(8.5, 4.5, -34);
    archRight.material = archLeft.material;
    archRight.parent = this.rootNode;
    this.collision.addBoxCollider('archR_col', 8.5, 4.5, -34, 1.4, 9, 1.4);

    const archBeam = MeshBuilder.CreateBox('archBeam', { width: 19, height: 1.4, depth: 1.8 }, this.scene);
    archBeam.position.set(0, 8.8, -34);
    archBeam.material = archLeft.material;
    archBeam.parent = this.rootNode;

    const archNeon = MeshBuilder.CreateBox('archNeon', { width: 16, height: 0.35, depth: 2.0 }, this.scene);
    archNeon.position.set(0, 8.8, -34);
    archNeon.material = this.materials.getEmissiveMaterial('archCyan', '#00f0ff', 1.4);
    archNeon.parent = this.rootNode;

    // 2. WESTSIDE HORIZON GARAGE (around x=-38, z=-38)
    const garageFloor = MeshBuilder.CreateGround('garageApron', { width: 34, height: 34 }, this.scene);
    garageFloor.position.set(-34, 0.02, -34);
    garageFloor.material = this.materials.getPlazaMaterial();
    garageFloor.parent = this.rootNode;

    // Garage back wall & canopy (open toward East & South so player can drive right in)
    const garageBackWall = MeshBuilder.CreateBox('garageBack', { width: 2.0, height: 7.5, depth: 22 }, this.scene);
    garageBackWall.position.set(-49, 3.75, -36);
    garageBackWall.material = this.materials.getSolidPBR('garageWall', '#1e293b', 0.4, 0.5);
    garageBackWall.parent = this.rootNode;
    this.collision.addBoxCollider('garageBack_col', -49, 3.75, -36, 2.0, 7.5, 22);

    const garageNorthWall = MeshBuilder.CreateBox('garageNorth', { width: 16, height: 7.5, depth: 2.0 }, this.scene);
    garageNorthWall.position.set(-42, 3.75, -25);
    garageNorthWall.material = garageBackWall.material;
    garageNorthWall.parent = this.rootNode;
    this.collision.addBoxCollider('garageNorth_col', -42, 3.75, -25, 16, 7.5, 2.0);

    const garageRoof = MeshBuilder.CreateBox('garageRoof', { width: 16, height: 0.9, depth: 22 }, this.scene);
    garageRoof.position.set(-42, 7.6, -36);
    garageRoof.material = this.materials.getSolidPBR('garageRoofMat', '#0f172a', 0.5, 0.4);
    garageRoof.parent = this.rootNode;

    const garageSign = MeshBuilder.CreateBox('garageSign', { width: 0.5, height: 1.1, depth: 18 }, this.scene);
    garageSign.position.set(-34, 7.8, -36);
    garageSign.material = this.materials.getEmissiveMaterial('garageNeon', '#f43f5e', 1.3);
    garageSign.parent = this.rootNode;

    this.minimapBuildings.push({ x: -42, z: -36, w: 16, d: 22, color: '#f43f5e' });

    // 3. EMERALD COMMONS PARK (Block centered at x=30, z=30)
    const parkLawn = MeshBuilder.CreateGround('emeraldParkLawn', { width: 42, height: 42 }, this.scene);
    parkLawn.position.set(30, 0.02, 30);
    parkLawn.material = this.materials.getGrassMaterial();
    parkLawn.receiveShadows = true;
    parkLawn.parent = this.rootNode;

    const parkPond = MeshBuilder.CreateCylinder('parkPond', { diameter: 13, height: 0.16, tessellation: 24 }, this.scene);
    parkPond.position.set(30, 0.04, 30);
    parkPond.material = this.materials.getWaterMaterial();
    parkPond.parent = this.rootNode;

    const fountainCenter = MeshBuilder.CreateCylinder('fountainCenter', { diameter: 2.6, height: 2.2, tessellation: 16 }, this.scene);
    fountainCenter.position.set(30, 1.1, 30);
    fountainCenter.material = this.materials.getEmissiveMaterial('fountainGlow', '#38bdf8', 1.1);
    fountainCenter.parent = this.rootNode;
    this.collision.addBoxCollider('fountain_col', 30, 1.1, 30, 2.6, 2.4, 2.6);
  }

  private buildCityBlocks(): void {
    // Define structured architectural buildings across the district blocks
    const specs: Array<{
      id: string;
      x: number;
      z: number;
      w: number;
      d: number;
      h: number;
      style: number;
      neonHex?: string;
      hasSpire?: boolean;
    }> = [
      // Southwest Downtown Block (East of Central Ave, South of 0)
      { id: 'b_se_1', x: 26, z: -26, w: 18, d: 18, h: 36, style: 0, neonHex: '#38bdf8' },
      { id: 'b_se_2', x: 42, z: -42, w: 14, d: 16, h: 24, style: 1 },
      { id: 'b_se_3', x: 22, z: -44, w: 14, d: 12, h: 19, style: 2 },

      // Northwest Block (x: -48..-14, z: 14..48)
      { id: 'b_nw_1', x: -26, z: 26, w: 18, d: 18, h: 44, style: 2, neonHex: '#2dd4bf', hasSpire: true },
      { id: 'b_nw_2', x: -43, z: 24, w: 12, d: 16, h: 28, style: 4 },
      { id: 'b_nw_3', x: -34, z: 44, w: 24, d: 12, h: 32, style: 0 },

      // Far West South Block (x: -108..-72, z: -48..-14)
      { id: 'b_fws_1', x: -84, z: -26, w: 20, d: 18, h: 30, style: 1, neonHex: '#f59e0b' },
      { id: 'b_fws_2', x: -96, z: -44, w: 18, d: 14, h: 22, style: 3 },

      // Far West North Block (x: -108..-72, z: 14..48)
      { id: 'b_fwn_1', x: -84, z: 22, w: 18, d: 16, h: 38, style: 4, neonHex: '#818cf8' },
      { id: 'b_fwn_2', x: -98, z: 42, w: 16, d: 16, h: 26, style: 0 },

      // Far East South Block (x: 72..108, z: -48..-14)
      { id: 'b_fes_1', x: 84, z: -22, w: 20, d: 16, h: 42, style: 0, neonHex: '#00f0ff', hasSpire: true },
      { id: 'b_fes_2', x: 96, z: -42, w: 18, d: 16, h: 28, style: 2 },

      // Far East North Block (x: 72..108, z: 14..48)
      { id: 'b_fen_1', x: 86, z: 26, w: 22, d: 18, h: 34, style: 1 },
      { id: 'b_fen_2', x: 92, z: 46, w: 18, d: 12, h: 24, style: 3 },

      // North Skyline Blocks (z: 72..108)
      { id: 'b_nnw_1', x: -30, z: 82, w: 22, d: 16, h: 48, style: 0, neonHex: '#38bdf8', hasSpire: true },
      { id: 'b_nnw_2', x: -44, z: 100, w: 14, d: 14, h: 30, style: 4 },
      { id: 'b_nne_1', x: 28, z: 84, w: 20, d: 18, h: 40, style: 2, neonHex: '#10b981' },
      { id: 'b_nne_2', x: 44, z: 102, w: 14, d: 14, h: 26, style: 1 },
      { id: 'b_nfw_1', x: -90, z: 90, w: 24, d: 24, h: 35, style: 3 },
      { id: 'b_nfe_1', x: 90, z: 90, w: 24, d: 24, h: 38, style: 0 },

      // South Marina Blocks (z: -108..-72)
      { id: 'b_ssw_1', x: -32, z: -86, w: 22, d: 18, h: 26, style: 2, neonHex: '#fbbf24' },
      { id: 'b_ssw_2', x: -46, z: -102, w: 14, d: 12, h: 18, style: 3 },
      { id: 'b_sse_1', x: 32, z: -86, w: 22, d: 18, h: 28, style: 1, neonHex: '#00f0ff' },
      { id: 'b_sse_2', x: 46, z: -102, w: 14, d: 12, h: 20, style: 4 },
      { id: 'b_sfw_1', x: -88, z: -90, w: 22, d: 20, h: 24, style: 0 },
      { id: 'b_sfe_1', x: 88, z: -90, w: 22, d: 20, h: 25, style: 2 },
    ];

    for (const spec of specs) {
      this.createSkyscraper(spec);
    }
  }

  private createSkyscraper(spec: {
    id: string;
    x: number;
    z: number;
    w: number;
    d: number;
    h: number;
    style: number;
    neonHex?: string;
    hasSpire?: boolean;
  }): void {
    const { id, x, z, w, d, h, style, neonHex, hasSpire } = spec;

    // Lobby podium base
    const podiumH = Math.min(4.5, h * 0.18);
    const podium = MeshBuilder.CreateBox(
      `${id}_podium`,
      { width: w + 1.2, height: podiumH, depth: d + 1.2 },
      this.scene
    );
    podium.position.set(x, podiumH * 0.5, z);
    podium.material = this.materials.getSolidPBR('podiumDark', '#1e293b', 0.4, 0.5);
    podium.receiveShadows = true;
    podium.parent = this.rootNode;

    // Main facade tower
    const tower = MeshBuilder.CreateBox(
      `${id}_tower`,
      { width: w, height: h, depth: d },
      this.scene
    );
    tower.position.set(x, h * 0.5, z);
    tower.material = this.materials.getBuildingFacadeMaterial(style);
    tower.receiveShadows = true;
    tower.parent = this.rootNode;

    if (this.shadowGen) {
      this.shadowGen.addShadowCaster(tower);
    }

    // Rooftop crown ledge
    const crown = MeshBuilder.CreateBox(
      `${id}_crown`,
      { width: w + 0.6, height: 0.9, depth: d + 0.6 },
      this.scene
    );
    crown.position.set(x, h + 0.45, z);
    crown.material = neonHex
      ? this.materials.getEmissiveMaterial(`crown_${neonHex}`, neonHex, 1.2)
      : this.materials.getSolidPBR('crownMetal', '#334155', 0.6, 0.3);
    crown.parent = this.rootNode;

    if (hasSpire) {
      const tier = MeshBuilder.CreateBox(
        `${id}_tier`,
        { width: w * 0.6, height: 7, depth: d * 0.6 },
        this.scene
      );
      tier.position.set(x, h + 3.5, z);
      tier.material = tower.material;
      tier.parent = this.rootNode;

      const spire = MeshBuilder.CreateCylinder(
        `${id}_spire`,
        { diameterTop: 0.15, diameterBottom: 0.9, height: 14, tessellation: 8 },
        this.scene
      );
      spire.position.set(x, h + 13, z);
      spire.material = this.materials.getEmissiveMaterial('spireBeacon', neonHex || '#00f0ff', 1.4);
      spire.parent = this.rootNode;
    }

    // Register solid collision box
    this.collision.addBoxCollider(`${id}_col`, x, h * 0.5, z, w + 1.0, h + 2, d + 1.0, {
      isBuilding: true,
    });

    this.minimapBuildings.push({
      x,
      z,
      w: w + 1.0,
      d: d + 1.0,
      color: neonHex || '#334155',
    });
  }

  private buildStreetlightsAndTrees(): void {
    // Master streetlight pole + luminaire merged or instanced
    const poleMaster = MeshBuilder.CreateCylinder(
      'streetPoleMaster',
      { diameterTop: 0.16, diameterBottom: 0.24, height: 6.5, tessellation: 8 },
      this.scene
    );
    poleMaster.material = this.materials.getSolidPBR('poleMetal', '#334155', 0.7, 0.3);
    poleMaster.isVisible = false;

    const bulbMaster = MeshBuilder.CreateBox(
      'streetBulbMaster',
      { width: 0.9, height: 0.22, depth: 0.45 },
      this.scene
    );
    bulbMaster.material = this.materials.getEmissiveMaterial('streetBulbGlow', '#fef08a', 1.5);
    bulbMaster.isVisible = false;

    let lampIdx = 0;
    for (const x of [-60, 0, 60]) {
      for (let z = -105; z <= 105; z += 30) {
        if (Math.abs(z % 60) < 12) continue; // skip inside intersections
        for (const side of [-1, 1]) {
          const lx = x + side * 8.4;
          const poleInst = poleMaster.createInstance(`lampPole_${lampIdx}`);
          poleInst.position.set(lx, 3.25, z);
          poleInst.parent = this.rootNode;

          const bulbInst = bulbMaster.createInstance(`lampBulb_${lampIdx}`);
          bulbInst.position.set(lx - side * 0.6, 6.4, z);
          bulbInst.parent = this.rootNode;
          lampIdx++;
        }
      }
    }

    // Instanced Trees (Park & Boulevards)
    const trunkMaster = MeshBuilder.CreateCylinder(
      'treeTrunkMaster',
      { diameterTop: 0.35, diameterBottom: 0.55, height: 2.6, tessellation: 7 },
      this.scene
    );
    trunkMaster.material = this.materials.getSolidPBR('bark', '#452c1e', 0.05, 0.9);
    trunkMaster.isVisible = false;

    const canopyMaster = MeshBuilder.CreateSphere(
      'treeCanopyMaster',
      { diameter: 3.8, segments: 6 },
      this.scene
    );
    canopyMaster.material = this.materials.getSolidPBR('foliage', '#15803d', 0.05, 0.85);
    canopyMaster.isVisible = false;

    const treePositions: Array<[number, number, number]> = [
      // Emerald Park perimeter & interior
      [18, 18, 1.1],
      [42, 18, 1.2],
      [18, 42, 1.0],
      [42, 42, 1.3],
      [22, 32, 0.9],
      [38, 28, 1.15],
      [30, 44, 1.05],
      // Central Plaza trees
      [-14, 16, 1.0],
      [14, 16, 1.0],
      [-14, 28, 1.1],
      [14, 28, 1.1],
      // Spawn Plaza & Marina Promenade trees
      [-12, -42, 1.0],
      [12, -42, 1.0],
      [-24, -126, 1.2],
      [0, -126, 1.2],
      [24, -126, 1.2],
      [-48, -126, 1.1],
      [48, -126, 1.1],
    ];

    treePositions.forEach(([tx, tz, scale], i) => {
      const tInst = trunkMaster.createInstance(`treeTrunk_${i}`);
      tInst.position.set(tx, 1.3 * scale, tz);
      tInst.scaling.setAll(scale);
      tInst.parent = this.rootNode;

      const cInst = canopyMaster.createInstance(`treeCanopy_${i}`);
      cInst.position.set(tx, 3.4 * scale, tz);
      cInst.scaling.set(scale, scale * 1.15, scale);
      cInst.parent = this.rootNode;

      this.collision.addBoxCollider(`tree_col_${i}`, tx, 1.5, tz, 0.7, 3.5, 0.7, {
        isBuilding: false,
      });
    });
  }

  private buildDistantSkyline(): void {
    const skylineMat = this.materials.getSolidPBR('distantSkyline', '#0f172a', 0.3, 0.7, '#091326');
    const ringRadius = 215;
    const count = 36;

    const skylineMaster = MeshBuilder.CreateBox(
      'skylineMaster',
      { width: 22, height: 1, depth: 22 },
      this.scene
    );
    skylineMaster.material = skylineMat;
    skylineMaster.isVisible = false;

    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      // Leave South Marina Bay open to the ocean view
      if (Math.sin(angle) < -0.55) continue;

      const dist = ringRadius + (i % 3) * 18;
      const sx = Math.cos(angle) * dist;
      const sz = Math.sin(angle) * dist;
      const h = 35 + ((i * 19) % 55);

      const inst = skylineMaster.createInstance(`skyline_${i}`);
      inst.position.set(sx, h * 0.5, sz);
      inst.scaling.set(1 + (i % 2) * 0.4, h, 1 + ((i + 1) % 2) * 0.4);
      inst.parent = this.rootNode;
    }
  }
}
