import {
  Color3,
  Color4,
  DirectionalLight,
  Engine,
  GlowLayer,
  HemisphericLight,
  Mesh,
  MeshBuilder,
  Scene,
  ShadowGenerator,
  StandardMaterial,
  Vector3,
} from '@babylonjs/core';
import { MaterialLibrary } from './materials/MaterialLibrary';
import { CollisionSystem } from './systems/CollisionSystem';
import { CityBuilder } from './world/CityBuilder';
import { PlayerController } from './entities/PlayerController';
import { VehicleEntity } from './entities/VehicleController';
import { CameraController } from './systems/CameraController';
import { MissionManager } from './systems/MissionManager';
import { TrafficAndNPCSystem } from './systems/TrafficAndNPCSystem';
import {
  GameSettings,
  HUDTelemetry,
  MinimapBuilding,
  NotificationBanner,
  TimeOfDayPreset,
} from '../types/game';
import { getDistrictName, VEHICLE_CATALOG } from './data/worldCatalog';
import { saveManager } from '../managers/SaveManager';
import { audioManager } from '../managers/AudioManager';

export interface VirtualTouchInput {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  sprintOrBoost: boolean;
  jumpOrBrake: boolean;
}

export class HorizonEngine {
  private canvas: HTMLCanvasElement;
  private engine: Engine;
  private scene: Scene;

  private hemiLight!: HemisphericLight;
  private dirLight!: DirectionalLight;
  private shadowGen: ShadowGenerator | null = null;
  private glowLayer: GlowLayer | null = null;
  private skyDome!: Mesh;
  private skyMat!: StandardMaterial;

  private materials!: MaterialLibrary;
  private collision!: CollisionSystem;
  private cityBuilder!: CityBuilder;
  private player!: PlayerController;
  private vehicles: VehicleEntity[] = [];
  private activeVehicle: VehicleEntity | null = null;
  private nearbyVehicle: VehicleEntity | null = null;
  private cameraCtrl!: CameraController;
  private missionMgr!: MissionManager;
  private trafficSys!: TrafficAndNPCSystem;

  private minimapBuildings: MinimapBuilding[] = [];

  private keysDown: Set<string> = new Set();
  private touchInput: VirtualTouchInput = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    sprintOrBoost: false,
    jumpOrBrake: false,
  };

  private isPointerDragging = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  public mode: 'menu' | 'playing' | 'paused' = 'menu';
  private telemetryTimer = 0;
  private distanceAccumulator = 0;

  private onTelemetry: (telemetry: HUDTelemetry) => void;
  private onNotification: (banner: NotificationBanner) => void;
  private onPauseToggle: (paused: boolean) => void;
  private onHelpToggle: () => void;

  private boundKeyDown: (e: KeyboardEvent) => void;
  private boundKeyUp: (e: KeyboardEvent) => void;
  private boundMouseMove: (e: MouseEvent) => void;
  private boundMouseDown: (e: MouseEvent) => void;
  private boundMouseUp: () => void;
  private boundWheel: (e: WheelEvent) => void;
  private boundResize: () => void;
  private boundVisibility: () => void;

  constructor(
    canvas: HTMLCanvasElement,
    callbacks: {
      onTelemetry: (t: HUDTelemetry) => void;
      onNotification: (b: NotificationBanner) => void;
      onPauseToggle: (paused: boolean) => void;
      onHelpToggle: () => void;
    }
  ) {
    this.canvas = canvas;
    this.onTelemetry = callbacks.onTelemetry;
    this.onNotification = callbacks.onNotification;
    this.onPauseToggle = callbacks.onPauseToggle;
    this.onHelpToggle = callbacks.onHelpToggle;

    this.engine = new Engine(this.canvas, true, {
      preserveDrawingBuffer: false,
      stencil: true,
      antialias: true,
      powerPreference: 'high-performance',
    });

    this.scene = new Scene(this.engine);

    this.initLightingAndSky();
    this.initWorldAndEntities();
    this.applySettings(saveManager.getData().settings);

    // Bind input & lifecycle handlers
    this.boundKeyDown = this.handleKeyDown.bind(this);
    this.boundKeyUp = this.handleKeyUp.bind(this);
    this.boundMouseMove = this.handleMouseMove.bind(this);
    this.boundMouseDown = this.handleMouseDown.bind(this);
    this.boundMouseUp = this.handleMouseUp.bind(this);
    this.boundWheel = this.handleWheel.bind(this);
    this.boundResize = () => this.engine.resize();
    this.boundVisibility = this.handleVisibilityChange.bind(this);

    window.addEventListener('keydown', this.boundKeyDown);
    window.addEventListener('keyup', this.boundKeyUp);
    window.addEventListener('mousemove', this.boundMouseMove);
    this.canvas.addEventListener('mousedown', this.boundMouseDown);
    window.addEventListener('mouseup', this.boundMouseUp);
    this.canvas.addEventListener('wheel', this.boundWheel, { passive: true });
    window.addEventListener('resize', this.boundResize);
    document.addEventListener('visibilitychange', this.boundVisibility);

    // Start render loop
    this.engine.runRenderLoop(() => {
      const rawDt = this.engine.getDeltaTime() / 1000;
      const dt = Math.min(0.05, Math.max(0.001, rawDt));
      this.update(dt);
      this.scene.render();
    });
  }

  private initLightingAndSky(): void {
    this.hemiLight = new HemisphericLight('hemiLight', new Vector3(0, 1, 0), this.scene);
    this.hemiLight.intensity = 0.72;

    this.dirLight = new DirectionalLight('sunLight', new Vector3(-0.55, -0.82, -0.35), this.scene);
    this.dirLight.position = new Vector3(90, 140, 60);
    this.dirLight.intensity = 1.25;

    this.shadowGen = new ShadowGenerator(1024, this.dirLight);
    this.shadowGen.useBlurExponentialShadowMap = true;
    this.shadowGen.blurKernel = 16;

    this.glowLayer = new GlowLayer('horizonGlowLayer', this.scene);
    this.glowLayer.intensity = 0.55;

    // Sky dome
    this.skyDome = MeshBuilder.CreateSphere(
      'skyDome',
      { diameter: 750, segments: 16, sideOrientation: Mesh.BACKSIDE },
      this.scene
    );
    this.skyMat = new StandardMaterial('skyMat', this.scene);
    this.skyMat.disableLighting = true;
    this.skyDome.material = this.skyMat;

    this.scene.fogMode = Scene.FOGMODE_EXP2;
    this.scene.fogDensity = 0.0032;
  }

  private initWorldAndEntities(): void {
    this.materials = new MaterialLibrary(this.scene);
    this.collision = new CollisionSystem();

    this.cityBuilder = new CityBuilder(
      this.scene,
      this.materials,
      this.collision,
      this.shadowGen
    );
    this.minimapBuildings = this.cityBuilder.buildCity();

    this.player = new PlayerController(
      this.scene,
      this.materials,
      this.collision,
      this.shadowGen
    );

    // Spawn all driveable vehicles
    this.vehicles = VEHICLE_CATALOG.map(
      (spec) => new VehicleEntity(spec, this.scene, this.materials, this.shadowGen)
    );

    this.cameraCtrl = new CameraController(this.scene, this.collision);

    this.missionMgr = new MissionManager(
      this.scene,
      this.materials,
      (banner) => this.onNotification(banner)
    );

    this.trafficSys = new TrafficAndNPCSystem(this.scene, this.materials);
  }

  public getMinimapBuildings(): MinimapBuilding[] {
    return this.minimapBuildings;
  }

  public applySettings(settings: GameSettings): void {
    // Hardware scaling for graphics quality
    const scaleMap = {
      low: 1.45,
      medium: 1.15,
      high: 1.0,
    };
    this.engine.setHardwareScalingLevel(scaleMap[settings.graphicsQuality] || 1.0);

    // Glow & Shadows
    if (this.glowLayer) {
      this.glowLayer.intensity = settings.graphicsQuality === 'low' ? 0.25 : 0.55;
    }
    this.dirLight.shadowEnabled = settings.shadowsEnabled && settings.graphicsQuality !== 'low';

    // World activity
    this.trafficSys.setActivityLevel(settings.worldActivity);

    // Time of Day atmosphere
    this.applyTimeOfDay(settings.timeOfDay);

    // Audio
    audioManager.applySettings(settings);
  }

  public applyTimeOfDay(preset: TimeOfDayPreset): void {
    if (preset === 'sunset') {
      this.scene.clearColor = new Color4(0.11, 0.12, 0.22, 1);
      this.scene.fogColor = new Color3(0.16, 0.15, 0.26);
      this.scene.fogDensity = 0.0028;
      this.skyMat.emissiveColor = new Color3(0.14, 0.13, 0.25);
      this.hemiLight.diffuse = new Color3(0.85, 0.72, 0.78);
      this.hemiLight.groundColor = new Color3(0.18, 0.18, 0.25);
      this.hemiLight.intensity = 0.72;
      this.dirLight.diffuse = new Color3(1.0, 0.76, 0.52);
      this.dirLight.intensity = 1.35;
    } else if (preset === 'day') {
      this.scene.clearColor = new Color4(0.38, 0.62, 0.88, 1);
      this.scene.fogColor = new Color3(0.46, 0.68, 0.9);
      this.scene.fogDensity = 0.0022;
      this.skyMat.emissiveColor = new Color3(0.38, 0.62, 0.88);
      this.hemiLight.diffuse = new Color3(0.95, 0.98, 1.0);
      this.hemiLight.groundColor = new Color3(0.3, 0.34, 0.4);
      this.hemiLight.intensity = 0.88;
      this.dirLight.diffuse = new Color3(1.0, 0.97, 0.9);
      this.dirLight.intensity = 1.45;
    } else {
      // Night
      this.scene.clearColor = new Color4(0.03, 0.05, 0.1, 1);
      this.scene.fogColor = new Color3(0.04, 0.07, 0.14);
      this.scene.fogDensity = 0.0035;
      this.skyMat.emissiveColor = new Color3(0.03, 0.05, 0.11);
      this.hemiLight.diffuse = new Color3(0.35, 0.48, 0.72);
      this.hemiLight.groundColor = new Color3(0.08, 0.1, 0.16);
      this.hemiLight.intensity = 0.52;
      this.dirLight.diffuse = new Color3(0.45, 0.62, 0.95);
      this.dirLight.intensity = 0.75;
    }
  }

  public startGame(spawnInPreferredVehicle = false): void {
    audioManager.unlockAudio();
    saveManager.markGameStarted();
    this.mode = 'playing';
    audioManager.setPaused(false);

    if (spawnInPreferredVehicle) {
      const prefId = saveManager.getData().selectedVehicleId;
      const veh = this.vehicles.find((v) => v.spec.id === prefId) || this.vehicles[0];
      if (veh && !this.activeVehicle) {
        this.enterVehicle(veh);
      }
    }
  }

  public setPaused(paused: boolean): void {
    if (this.mode === 'menu') return;
    this.mode = paused ? 'paused' : 'playing';
    audioManager.setPaused(paused);
    if (paused && document.pointerLockElement === this.canvas) {
      document.exitPointerLock?.();
    }
    this.onPauseToggle(paused);
  }

  public returnToMainMenu(): void {
    this.mode = 'menu';
    audioManager.setPaused(true);
    if (document.pointerLockElement === this.canvas) {
      document.exitPointerLock?.();
    }
  }

  public selectMission(missionId: string): void {
    this.missionMgr.startMission(missionId);
    const m = this.missionMgr.getActiveMission();
    if (m) {
      this.onNotification({
        id: `sel_${Date.now()}`,
        title: `${m.code}: ${m.title}`,
        subtitle: m.stages[0]?.instruction || m.description,
        type: 'info',
        timestamp: Date.now(),
      });
    }
  }

  public restartCurrentMission(): void {
    this.missionMgr.restartCurrentMission();
  }

  public spawnOrSummonVehicle(vehicleId: string): void {
    saveManager.setSelectedVehicle(vehicleId);
    const veh = this.vehicles.find((v) => v.spec.id === vehicleId);
    if (!veh) return;

    if (this.activeVehicle && this.activeVehicle !== veh) {
      this.exitVehicle();
    }

    // Place the requested vehicle right next to the player on Central Ave / current position
    const refPos = this.activeVehicle ? this.activeVehicle.position : this.player.position;
    veh.position.set(refPos.x + 3.6, 0, refPos.z + 2.0);
    veh.speed = 0;
    this.enterVehicle(veh);

    this.onNotification({
      id: `veh_${Date.now()}`,
      title: `VEHICLE DELIVERED: ${veh.spec.name.toUpperCase()}`,
      subtitle: `${veh.spec.category} ready for deployment`,
      type: 'info',
      timestamp: Date.now(),
    });
  }

  public handleFullReset(): void {
    if (this.activeVehicle) {
      this.exitVehicle();
    }
    this.player.resetToSpawn();
    this.vehicles.forEach((v) => {
      v.position.set(v.spec.spawnPos.x, v.spec.spawnPos.y, v.spec.spawnPos.z);
      v.rotationY = v.spec.spawnRotY;
      v.speed = 0;
      v.setOccupied(false);
    });
    this.missionMgr.syncCollectedShards();
    this.missionMgr.startMission(saveManager.getData().activeMissionId);
  }

  public setTouchInput(partial: Partial<VirtualTouchInput>): void {
    this.touchInput = { ...this.touchInput, ...partial };
  }

  public triggerInteractAction(): void {
    if (this.mode !== 'playing') return;
    if (this.activeVehicle) {
      this.exitVehicle();
    } else if (this.nearbyVehicle) {
      this.enterVehicle(this.nearbyVehicle);
    }
  }

  public triggerResetAction(): void {
    if (this.mode !== 'playing') return;
    if (this.activeVehicle) {
      this.activeVehicle.resetToRoad();
      this.onNotification({
        id: `reset_v_${Date.now()}`,
        title: 'VEHICLE RESET',
        subtitle: 'Repositioned upright onto nearest roadway.',
        type: 'info',
        timestamp: Date.now(),
      });
    } else {
      this.player.resetToSpawn();
      this.onNotification({
        id: `reset_p_${Date.now()}`,
        title: 'RETURNED TO SPAWN PLAZA',
        subtitle: 'Player repositioned at Central Avenue South.',
        type: 'info',
        timestamp: Date.now(),
      });
    }
  }

  private enterVehicle(vehicle: VehicleEntity): void {
    this.activeVehicle = vehicle;
    vehicle.setOccupied(true);
    this.player.setVisible(false);
    this.cameraCtrl.yaw = vehicle.rotationY;
    saveManager.setSelectedVehicle(vehicle.spec.id);
    audioManager.playVehicleDoor(true);
  }

  private exitVehicle(): void {
    if (!this.activeVehicle) return;
    const veh = this.activeVehicle;
    veh.setOccupied(false);
    audioManager.updateVehicleAudio(false, 800, 0, false);
    audioManager.playVehicleDoor(false);

    // Place player safely to the left door of the vehicle
    const leftX = -Math.cos(veh.rotationY) * 2.35;
    const leftZ = Math.sin(veh.rotationY) * 2.35;
    const exitX = veh.position.x + leftX;
    const exitZ = veh.position.z + leftZ;

    const resolved = this.collision.resolveHorizontalCircle(exitX, veh.position.y, exitZ, 0.6, 1.8);
    this.player.position.set(resolved.x, veh.position.y, resolved.z);
    this.player.velocity.set(0, 0, 0);
    this.player.rotationY = veh.rotationY;
    this.player.setVisible(true);

    this.activeVehicle = null;
  }

  private handleKeyDown(e: KeyboardEvent): void {
    const code = e.code;

    if (code === 'Escape' || code === 'KeyP') {
      if (this.mode === 'playing') {
        this.setPaused(true);
      } else if (this.mode === 'paused') {
        this.setPaused(false);
      }
      return;
    }

    if (code === 'KeyH' && this.mode === 'playing') {
      this.onHelpToggle();
      return;
    }

    if (this.mode !== 'playing') return;

    audioManager.unlockAudio();

    if ((code === 'KeyE' || code === 'KeyF') && !e.repeat) {
      this.triggerInteractAction();
      return;
    }

    if (code === 'KeyR' && !e.repeat) {
      this.triggerResetAction();
      return;
    }

    this.keysDown.add(code);
  }

  private handleKeyUp(e: KeyboardEvent): void {
    this.keysDown.delete(e.code);
  }

  private handleMouseDown(e: MouseEvent): void {
    if (this.mode !== 'playing') return;
    audioManager.unlockAudio();
    this.isPointerDragging = true;
    this.lastPointerX = e.clientX;
    this.lastPointerY = e.clientY;
  }

  private handleMouseUp(): void {
    this.isPointerDragging = false;
  }

  private handleMouseMove(e: MouseEvent): void {
    if (this.mode !== 'playing') return;
    const sens = saveManager.getData().settings.mouseSensitivity;

    if (document.pointerLockElement === this.canvas) {
      this.cameraCtrl.handleMouseDelta(e.movementX, e.movementY, sens);
    } else if (this.isPointerDragging) {
      const dx = e.clientX - this.lastPointerX;
      const dy = e.clientY - this.lastPointerY;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
      this.cameraCtrl.handleMouseDelta(dx * 1.35, dy * 1.35, sens);
    }
  }

  private handleWheel(e: WheelEvent): void {
    if (this.mode !== 'playing') return;
    this.cameraCtrl.handleZoomDelta(e.deltaY);
  }

  private handleVisibilityChange(): void {
    if (document.hidden && this.mode === 'playing') {
      this.setPaused(true);
    }
  }

  private update(dt: number): void {
    if (this.mode === 'menu') {
      this.cameraCtrl.updateMenuOrbitCamera(dt);
      this.trafficSys.update(dt, this.player.position);
      this.missionMgr.update(dt, this.player.position);
      return;
    }

    if (this.mode === 'paused') {
      return;
    }

    // Keyboard Q/C camera orbit support
    if (this.keysDown.has('KeyQ')) {
      this.cameraCtrl.handleMouseDelta(-420 * dt, 0, 1.0);
    }
    if (this.keysDown.has('KeyC')) {
      this.cameraCtrl.handleMouseDelta(420 * dt, 0, 1.0);
    }

    const forward =
      this.keysDown.has('KeyW') ||
      this.keysDown.has('ArrowUp') ||
      this.touchInput.forward;
    const backward =
      this.keysDown.has('KeyS') ||
      this.keysDown.has('ArrowDown') ||
      this.touchInput.backward;
    const left =
      this.keysDown.has('KeyA') ||
      this.keysDown.has('ArrowLeft') ||
      this.touchInput.left;
    const right =
      this.keysDown.has('KeyD') ||
      this.keysDown.has('ArrowRight') ||
      this.touchInput.right;
    const shift =
      this.keysDown.has('ShiftLeft') ||
      this.keysDown.has('ShiftRight') ||
      this.touchInput.sprintOrBoost;
    const space =
      this.keysDown.has('Space') || this.touchInput.jumpOrBrake;

    let stepDist = 0;

    if (this.activeVehicle) {
      // Update all vehicles (active gets player input)
      for (const v of this.vehicles) {
        if (v === this.activeVehicle) {
          stepDist = v.update(
            dt,
            {
              forward,
              backward,
              left,
              right,
              handbrake: space,
              boost: shift,
            },
            this.collision,
            this.vehicles
          );
        } else {
          v.update(dt, null, this.collision, this.vehicles);
        }
      }
      // Keep player position synced to active vehicle for minimap & missions
      this.player.position.copyFrom(this.activeVehicle.position);
      this.player.rotationY = this.activeVehicle.rotationY;
      this.nearbyVehicle = null;
    } else {
      // On foot update
      stepDist = this.player.update(
        dt,
        {
          forward,
          backward,
          left,
          right,
          sprint: shift,
          jump: space,
        },
        this.cameraCtrl.yaw
      );

      for (const v of this.vehicles) {
        v.update(dt, null, this.collision, this.vehicles);
      }

      // Check proximity to any driveable vehicle
      let closest: VehicleEntity | null = null;
      let minDist = 5.0;
      for (const v of this.vehicles) {
        const d = Math.hypot(
          this.player.position.x - v.position.x,
          this.player.position.z - v.position.z
        );
        if (d < minDist) {
          minDist = d;
          closest = v;
        }
      }
      this.nearbyVehicle = closest;
    }

    this.distanceAccumulator += stepDist;
    if (this.distanceAccumulator > 25) {
      saveManager.getData().totalDistanceM += Math.round(this.distanceAccumulator);
      this.distanceAccumulator = 0;
    }

    const activePos = this.activeVehicle ? this.activeVehicle.position : this.player.position;
    const activeHeading = this.activeVehicle ? this.activeVehicle.rotationY : this.player.rotationY;
    const speedKmh = this.activeVehicle ? this.activeVehicle.getSpeedKmh() : 0;

    // Update Camera
    this.cameraCtrl.updateGameplayCamera(
      dt,
      activePos,
      activeHeading,
      Boolean(this.activeVehicle),
      speedKmh
    );

    // Update Traffic & Pedestrians
    this.trafficSys.update(dt, activePos);

    // Update Mission & Checkpoints
    const distToObjective = this.missionMgr.update(dt, activePos);

    // Emit HUD telemetry at ~20Hz
    this.telemetryTimer += dt;
    if (this.telemetryTimer >= 0.05) {
      this.telemetryTimer = 0;
      this.emitTelemetry(activePos, activeHeading, distToObjective);
    }
  }

  private emitTelemetry(activePos: Vector3, activeHeading: number, distToObjective: number): void {
    let interactionPrompt: string | null = null;
    if (this.activeVehicle) {
      interactionPrompt = `[E] Exit ${this.activeVehicle.spec.name}  •  [R] Reset Upright`;
    } else if (this.nearbyVehicle) {
      interactionPrompt = `Press [E] or [F] to Enter ${this.nearbyVehicle.spec.name}`;
    }

    const telemetry: HUDTelemetry = {
      playerPos: { x: activePos.x, y: activePos.y, z: activePos.z },
      playerHeading: activeHeading,
      cameraYaw: this.cameraCtrl.yaw,
      isDriving: Boolean(this.activeVehicle),
      isSprinting: !this.activeVehicle && this.player.isSprinting,
      stamina: Math.round(this.player.stamina),
      currentVehicleName: this.activeVehicle ? this.activeVehicle.spec.name : '',
      currentVehicleCategory: this.activeVehicle ? this.activeVehicle.spec.category : '',
      speedKmh: this.activeVehicle ? this.activeVehicle.getSpeedKmh() : 0,
      rpm: this.activeVehicle ? this.activeVehicle.getRpm() : 800,
      gear: this.activeVehicle ? this.activeVehicle.getGear() : 'N',
      nitro: this.activeVehicle ? Math.round(this.activeVehicle.nitro) : 100,
      isDrifting: Boolean(this.activeVehicle?.isDrifting),
      interactionPrompt,
      districtName: getDistrictName(activePos.x, activePos.z),
      activeMission: this.missionMgr.getActiveMission(),
      activeStageIndex: this.missionMgr.getStageIndex(),
      distanceToTarget: Math.round(distToObjective),
      missionTimerRemaining: this.missionMgr.getTimerRemaining(),
      targetPos: this.missionMgr.getTargetPosition(),
      fps: Math.round(this.engine.getFps()),
      parkedVehicles: this.vehicles.map((v) => ({
        id: v.spec.id,
        name: v.spec.name,
        x: v.position.x,
        z: v.position.z,
        rotY: v.rotationY,
        isTraffic: false,
      })),
      trafficVehicles: this.trafficSys.getMinimapTraffic(),
      shards: this.missionMgr.getMinimapShards(),
    };

    this.onTelemetry(telemetry);
  }

  public dispose(): void {
    window.removeEventListener('keydown', this.boundKeyDown);
    window.removeEventListener('keyup', this.boundKeyUp);
    window.removeEventListener('mousemove', this.boundMouseMove);
    this.canvas.removeEventListener('mousedown', this.boundMouseDown);
    window.removeEventListener('mouseup', this.boundMouseUp);
    this.canvas.removeEventListener('wheel', this.boundWheel);
    window.removeEventListener('resize', this.boundResize);
    document.removeEventListener('visibilitychange', this.boundVisibility);

    this.scene.dispose();
    this.engine.dispose();
  }
}
