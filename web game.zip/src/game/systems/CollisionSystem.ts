export interface BoxCollider {
  id: string;
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
  isBuilding?: boolean;
  isWalkableTop?: boolean;
}

export interface CollisionResolution {
  x: number;
  z: number;
  collided: boolean;
  normalX: number;
  normalZ: number;
  penetration: number;
}

export class CollisionSystem {
  private colliders: BoxCollider[] = [];
  private worldHalfExtent = 165;

  public clear(): void {
    this.colliders = [];
  }

  public addBoxCollider(
    id: string,
    centerX: number,
    centerY: number,
    centerZ: number,
    width: number,
    height: number,
    depth: number,
    options?: { isBuilding?: boolean; isWalkableTop?: boolean }
  ): void {
    const hw = width * 0.5;
    const hh = height * 0.5;
    const hd = depth * 0.5;
    this.colliders.push({
      id,
      minX: centerX - hw,
      maxX: centerX + hw,
      minY: centerY - hh,
      maxY: centerY + hh,
      minZ: centerZ - hd,
      maxZ: centerZ + hd,
      isBuilding: options?.isBuilding ?? true,
      isWalkableTop: options?.isWalkableTop ?? false,
    });
  }

  public getColliders(): BoxCollider[] {
    return this.colliders;
  }

  /**
   * Returns ground height at (x, z), accounting for sidewalks or raised platforms
   */
  public getGroundHeight(x: number, z: number, currentY = 0): number {
    let highest = 0;
    for (let i = 0; i < this.colliders.length; i++) {
      const c = this.colliders[i];
      if (!c.isWalkableTop) continue;
      if (x >= c.minX && x <= c.maxX && z >= c.minZ && z <= c.maxZ) {
        if (c.maxY <= currentY + 1.1 && c.maxY > highest) {
          highest = c.maxY;
        }
      }
    }
    return highest;
  }

  /**
   * Resolves horizontal circle vs static AABB collisions with smooth wall sliding
   */
  public resolveHorizontalCircle(
    x: number,
    y: number,
    z: number,
    radius: number,
    entityHeight = 1.8
  ): CollisionResolution {
    let curX = x;
    let curZ = z;
    let collided = false;
    let normalX = 0;
    let normalZ = 0;
    let maxPen = 0;

    // World boundary clamp
    const bound = this.worldHalfExtent - radius;
    if (curX < -bound) {
      curX = -bound;
      collided = true;
      normalX = 1;
    } else if (curX > bound) {
      curX = bound;
      collided = true;
      normalX = -1;
    }
    if (curZ < -bound) {
      curZ = -bound;
      collided = true;
      normalZ = 1;
    } else if (curZ > bound) {
      curZ = bound;
      collided = true;
      normalZ = -1;
    }

    // Multiple relaxation passes for corner stability
    for (let pass = 0; pass < 2; pass++) {
      for (let i = 0; i < this.colliders.length; i++) {
        const c = this.colliders[i];

        // If walkable top and entity is above top surface, don't collide horizontally
        if (c.isWalkableTop && y >= c.maxY - 0.25) {
          continue;
        }
        // Check vertical overlap
        if (y + entityHeight <= c.minY || y >= c.maxY) {
          continue;
        }

        // Closest point on AABB in XZ plane
        const closestX = Math.max(c.minX, Math.min(curX, c.maxX));
        const closestZ = Math.max(c.minZ, Math.min(curZ, c.maxZ));

        const dx = curX - closestX;
        const dz = curZ - closestZ;
        const distSq = dx * dx + dz * dz;

        if (distSq < radius * radius) {
          collided = true;
          if (distSq > 1e-6) {
            const dist = Math.sqrt(distSq);
            const pen = radius - dist;
            const nx = dx / dist;
            const nz = dz / dist;
            curX += nx * pen;
            curZ += nz * pen;
            if (pen > maxPen) {
              maxPen = pen;
              normalX = nx;
              normalZ = nz;
            }
          } else {
            // Center is inside AABB: push out along nearest face
            const dLeft = Math.abs(curX - c.minX);
            const dRight = Math.abs(c.maxX - curX);
            const dBack = Math.abs(curZ - c.minZ);
            const dFront = Math.abs(c.maxZ - curZ);
            const minFace = Math.min(dLeft, dRight, dBack, dFront);

            if (minFace === dLeft) {
              curX = c.minX - radius;
              normalX = -1;
              normalZ = 0;
            } else if (minFace === dRight) {
              curX = c.maxX + radius;
              normalX = 1;
              normalZ = 0;
            } else if (minFace === dBack) {
              curZ = c.minZ - radius;
              normalX = 0;
              normalZ = -1;
            } else {
              curZ = c.maxZ + radius;
              normalX = 0;
              normalZ = 1;
            }
            maxPen = Math.max(maxPen, minFace + radius);
          }
        }
      }
    }

    return {
      x: curX,
      z: curZ,
      collided,
      normalX,
      normalZ,
      penetration: maxPen,
    };
  }

  /**
   * Ray-vs-AABB intersection to prevent third-person camera from clipping inside buildings
   */
  public clipCameraRay(
    originX: number,
    originY: number,
    originZ: number,
    targetX: number,
    targetY: number,
    targetZ: number,
    safetyMargin = 0.45
  ): { x: number; y: number; z: number } {
    const dx = targetX - originX;
    const dy = targetY - originY;
    const dz = targetZ - originZ;
    const length = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (length < 1e-4) {
      return { x: targetX, y: targetY, z: targetZ };
    }

    const dirX = dx / length;
    const dirY = dy / length;
    const dirZ = dz / length;

    let minT = 1.0;

    for (let i = 0; i < this.colliders.length; i++) {
      const c = this.colliders[i];
      if (!c.isBuilding) continue;

      const t = this.intersectSegmentAABB(
        originX,
        originY,
        originZ,
        dirX,
        dirY,
        dirZ,
        length,
        c
      );

      if (t !== null && t < minT) {
        minT = t;
      }
    }

    if (minT < 1.0) {
      const clippedDist = Math.max(1.2, minT * length - safetyMargin);
      return {
        x: originX + dirX * clippedDist,
        y: Math.max(0.6, originY + dirY * clippedDist),
        z: originZ + dirZ * clippedDist,
      };
    }

    return {
      x: targetX,
      y: Math.max(0.6, targetY),
      z: targetZ,
    };
  }

  private intersectSegmentAABB(
    ox: number,
    oy: number,
    oz: number,
    dx: number,
    dy: number,
    dz: number,
    maxLen: number,
    box: BoxCollider
  ): number | null {
    let tmin = 0.0;
    let tmax = maxLen;

    // X slab
    if (Math.abs(dx) < 1e-6) {
      if (ox < box.minX || ox > box.maxX) return null;
    } else {
      const invD = 1.0 / dx;
      let t1 = (box.minX - ox) * invD;
      let t2 = (box.maxX - ox) * invD;
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
      }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) return null;
    }

    // Y slab
    if (Math.abs(dy) < 1e-6) {
      if (oy < box.minY || oy > box.maxY) return null;
    } else {
      const invD = 1.0 / dy;
      let t1 = (box.minY - oy) * invD;
      let t2 = (box.maxY - oy) * invD;
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
      }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) return null;
    }

    // Z slab
    if (Math.abs(dz) < 1e-6) {
      if (oz < box.minZ || oz > box.maxZ) return null;
    } else {
      const invD = 1.0 / dz;
      let t1 = (box.minZ - oz) * invD;
      let t2 = (box.maxZ - oz) * invD;
      if (t1 > t2) {
        const tmp = t1;
        t1 = t2;
        t2 = tmp;
      }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) return null;
    }

    if (tmin >= 0 && tmin <= maxLen) {
      return tmin / maxLen;
    }
    return null;
  }
}
