import {
  MeshBuilder,
  Scene,
  TransformNode,
  Vector3,
} from '@babylonjs/core';
import { MaterialLibrary } from '../materials/MaterialLibrary';
import { MinimapVehicle, Vec3, WorldActivityLevel } from '../../types/game';

interface TrafficAgent {
  id: string;
  root: TransformNode;
  waypoints: Vec3[];
  currentWpIndex: number;
  position: Vector3;
  rotationY: number;
  speed: number;
  maxSpeed: number;
  active: boolean;
}

interface PedestrianAgent {
  id: string;
  root: TransformNode;
  leftLeg: TransformNode;
  rightLeg: TransformNode;
  waypoints: Vec3[];
  currentWpIndex: number;
  position: Vector3;
  rotationY: number;
  speed: number;
  animPhase: number;
  active: boolean;
}

export class TrafficAndNPCSystem {
  private scene: Scene;
  private materials: MaterialLibrary;
  private trafficAgents: TrafficAgent[] = [];
  private pedestrians: PedestrianAgent[] = [];
  private activityLevel: WorldActivityLevel = 'high';

  constructor(scene: Scene, materials: MaterialLibrary) {
    this.scene = scene;
    this.materials = materials;
    this.initTrafficAgents();
    this.initPedestrians();
  }

  private initTrafficAgents(): void {
    // Define closed road lane loops (right-hand traffic offset by 3.2m from avenue centerline)
    const loops: Vec3[][] = [
      // Loop 1: Inner West-North-East-South clockwise loop
      [
        { x: -56.8, y: 0, z: -56.8 },
        { x: -56.8, y: 0, z: 56.8 },
        { x: 56.8, y: 0, z: 56.8 },
        { x: 56.8, y: 0, z: -56.8 },
      ],
      // Loop 2: Inner counter-clockwise outer lane
      [
        { x: 63.2, y: 0, z: -63.2 },
        { x: 63.2, y: 0, z: 63.2 },
        { x: -63.2, y: 0, z: 63.2 },
        { x: -63.2, y: 0, z: -63.2 },
      ],
      // Loop 3: North District loop
      [
        { x: -56.8, y: 0, z: 3.2 },
        { x: -56.8, y: 0, z: 116.8 },
        { x: 56.8, y: 0, z: 116.8 },
        { x: 56.8, y: 0, z: 3.2 },
      ],
      // Loop 4: South Marina loop
      [
        { x: -56.8, y: 0, z: -116.8 },
        { x: -56.8, y: 0, z: -3.2 },
        { x: 56.8, y: 0, z: -3.2 },
        { x: 56.8, y: 0, z: -116.8 },
      ],
    ];

    const colors = ['#38bdf8', '#e2e8f0', '#fb7185', '#a78bfa', '#34d399', '#fbbf24'];
    const glassMat = this.materials.getSolidPBR('trafficGlass', '#0f172a', 0.85, 0.15);
    const tireMat = this.materials.getSolidPBR('trafficTire', '#111827', 0.1, 0.85);
    const hlMat = this.materials.getEmissiveMaterial('trafficHL', '#fef08a', 1.3);
    const tlMat = this.materials.getEmissiveMaterial('trafficTL', '#ef4444', 1.2);

    for (let i = 0; i < 6; i++) {
      const loop = loops[i % loops.length];
      const startWp = (i * 2) % loop.length;
      const nextWp = (startWp + 1) % loop.length;
      const p0 = loop[startWp];
      const p1 = loop[nextWp];

      const startPos = new Vector3(
        (p0.x + p1.x) * 0.5,
        0,
        (p0.z + p1.z) * 0.5
      );

      const root = new TransformNode(`trafficCar_${i}`, this.scene);
      const bodyMat = this.materials.getSolidPBR(`trafficBody_${i}`, colors[i % colors.length], 0.55, 0.35);

      const lower = MeshBuilder.CreateBox(`tcLower_${i}`, { width: 1.9, height: 0.55, depth: 4.1 }, this.scene);
      lower.position.y = 0.58;
      lower.material = bodyMat;
      lower.parent = root;

      const cabin = MeshBuilder.CreateBox(`tcCabin_${i}`, { width: 1.62, height: 0.45, depth: 2.0 }, this.scene);
      cabin.position.set(0, 1.04, -0.15);
      cabin.material = glassMat;
      cabin.parent = root;

      const hl = MeshBuilder.CreateBox(`tcHL_${i}`, { width: 1.6, height: 0.14, depth: 0.08 }, this.scene);
      hl.position.set(0, 0.62, 2.04);
      hl.material = hlMat;
      hl.parent = root;

      const tl = MeshBuilder.CreateBox(`tcTL_${i}`, { width: 1.6, height: 0.14, depth: 0.08 }, this.scene);
      tl.position.set(0, 0.64, -2.04);
      tl.material = tlMat;
      tl.parent = root;

      for (const [wx, wz] of [
        [-0.95, 1.25],
        [0.95, 1.25],
        [-0.95, -1.25],
        [0.95, -1.25],
      ]) {
        const w = MeshBuilder.CreateCylinder(`tcW_${i}_${wx}_${wz}`, { diameter: 0.72, height: 0.28, tessellation: 10 }, this.scene);
        w.rotation.z = Math.PI * 0.5;
        w.position.set(wx, 0.36, wz);
        w.material = tireMat;
        w.parent = root;
      }

      const rotY = Math.atan2(p1.x - p0.x, p1.z - p0.z);
      root.position.copyFrom(startPos);
      root.rotation.y = rotY;

      this.trafficAgents.push({
        id: `traffic_${i}`,
        root,
        waypoints: loop,
        currentWpIndex: nextWp,
        position: startPos,
        rotationY: rotY,
        speed: 11,
        maxSpeed: 11 + (i % 3) * 1.5,
        active: true,
      });
    }
  }

  private initPedestrians(): void {
    const sidewalkPaths: Vec3[][] = [
      [{ x: -9.5, y: 0, z: -50 }, { x: -9.5, y: 0, z: 50 }],
      [{ x: 9.5, y: 0, z: 50 }, { x: 9.5, y: 0, z: -50 }],
      [{ x: -50, y: 0, z: -9.5 }, { x: 50, y: 0, z: -9.5 }],
      [{ x: 50, y: 0, z: 9.5 }, { x: -50, y: 0, z: 9.5 }],
      [{ x: 18, y: 0, z: 18 }, { x: 42, y: 0, z: 18 }, { x: 42, y: 0, z: 42 }, { x: 18, y: 0, z: 42 }],
      [{ x: -50.5, y: 0, z: -45 }, { x: -50.5, y: 0, z: 45 }],
      [{ x: 50.5, y: 0, z: -45 }, { x: 50.5, y: 0, z: 45 }],
      [{ x: -35, y: 0, z: -110.5 }, { x: 35, y: 0, z: -110.5 }],
      [{ x: -12, y: 0, z: 14 }, { x: 12, y: 0, z: 14 }, { x: 12, y: 0, z: 34 }, { x: -12, y: 0, z: 34 }],
      [{ x: -35, y: 0, z: 69.5 }, { x: 35, y: 0, z: 69.5 }],
    ];

    const coatColors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#6366f1', '#14b8a6'];
    const skinMat = this.materials.getSolidPBR('npcSkin', '#dca788', 0.1, 0.7);
    const pantsMat = this.materials.getSolidPBR('npcPants', '#1e293b', 0.2, 0.7);

    sidewalkPaths.forEach((path, i) => {
      const root = new TransformNode(`npc_${i}`, this.scene);
      const coatMat = this.materials.getSolidPBR(`npcCoat_${i}`, coatColors[i % coatColors.length], 0.25, 0.6);

      const torso = MeshBuilder.CreateBox(`npcTorso_${i}`, { width: 0.44, height: 0.62, depth: 0.26 }, this.scene);
      torso.position.y = 1.08;
      torso.material = coatMat;
      torso.parent = root;

      const head = MeshBuilder.CreateBox(`npcHead_${i}`, { width: 0.28, height: 0.3, depth: 0.28 }, this.scene);
      head.position.y = 1.56;
      head.material = skinMat;
      head.parent = root;

      const leftLeg = new TransformNode(`npcLL_${i}`, this.scene);
      leftLeg.position.set(-0.12, 0.75, 0);
      leftLeg.parent = root;
      const llMesh = MeshBuilder.CreateBox(`npcLLMesh_${i}`, { width: 0.17, height: 0.72, depth: 0.18 }, this.scene);
      llMesh.position.y = -0.36;
      llMesh.material = pantsMat;
      llMesh.parent = leftLeg;

      const rightLeg = new TransformNode(`npcRL_${i}`, this.scene);
      rightLeg.position.set(0.12, 0.75, 0);
      rightLeg.parent = root;
      const rlMesh = MeshBuilder.CreateBox(`npcRLMesh_${i}`, { width: 0.17, height: 0.72, depth: 0.18 }, this.scene);
      rlMesh.position.y = -0.36;
      rlMesh.material = pantsMat;
      rlMesh.parent = rightLeg;

      const startPos = new Vector3(path[0].x, 0, path[0].z);
      root.position.copyFrom(startPos);

      this.pedestrians.push({
        id: `npc_${i}`,
        root,
        leftLeg,
        rightLeg,
        waypoints: path,
        currentWpIndex: 1 % path.length,
        position: startPos,
        rotationY: 0,
        speed: 2.1 + (i % 3) * 0.35,
        animPhase: i * 1.3,
        active: true,
      });
    });
  }

  public setActivityLevel(level: WorldActivityLevel): void {
    this.activityLevel = level;

    const maxTraffic = level === 'off' ? 0 : level === 'low' ? 3 : this.trafficAgents.length;
    const maxPeds = level === 'off' ? 0 : level === 'low' ? 5 : this.pedestrians.length;

    this.trafficAgents.forEach((agent, idx) => {
      agent.active = idx < maxTraffic;
      agent.root.setEnabled(agent.active);
    });

    this.pedestrians.forEach((ped, idx) => {
      ped.active = idx < maxPeds;
      ped.root.setEnabled(ped.active);
    });
  }

  public update(dt: number, activePlayerPos: Vector3): void {
    if (this.activityLevel === 'off') return;

    // Update Traffic Vehicles
    for (const agent of this.trafficAgents) {
      if (!agent.active) continue;

      const target = agent.waypoints[agent.currentWpIndex];
      const dx = target.x - agent.position.x;
      const dz = target.z - agent.position.z;
      const dist = Math.hypot(dx, dz);

      if (dist < 2.5) {
        agent.currentWpIndex = (agent.currentWpIndex + 1) % agent.waypoints.length;
      }

      const desiredAngle = Math.atan2(dx, dz);
      let angleDiff = desiredAngle - agent.rotationY;
      while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      agent.rotationY += angleDiff * Math.min(1, dt * 6.5);

      // Check if player/car is directly in front of this traffic vehicle
      const fwdX = Math.sin(agent.rotationY);
      const fwdZ = Math.cos(agent.rotationY);
      const toPlayerX = activePlayerPos.x - agent.position.x;
      const toPlayerZ = activePlayerPos.z - agent.position.z;
      const distToPlayer = Math.hypot(toPlayerX, toPlayerZ);
      const forwardDot =
        distToPlayer > 0.01
          ? (toPlayerX * fwdX + toPlayerZ * fwdZ) / distToPlayer
          : 0;

      const blockedByPlayer = distToPlayer < 11.0 && forwardDot > 0.72;
      const targetSpeed = blockedByPlayer ? 0 : agent.maxSpeed;

      agent.speed += (targetSpeed - agent.speed) * Math.min(1, dt * 5.0);

      agent.position.x += fwdX * agent.speed * dt;
      agent.position.z += fwdZ * agent.speed * dt;

      agent.root.position.copyFrom(agent.position);
      agent.root.rotation.y = agent.rotationY;
    }

    // Update Pedestrians
    for (const ped of this.pedestrians) {
      if (!ped.active) continue;

      const distToPlayer = Math.hypot(
        activePlayerPos.x - ped.position.x,
        activePlayerPos.z - ped.position.z
      );

      // Pause politely if player or vehicle gets very close
      if (distToPlayer < 3.0) {
        ped.leftLeg.rotation.x *= 0.85;
        ped.rightLeg.rotation.x *= 0.85;
        // Look toward player
        const lookAngle = Math.atan2(
          activePlayerPos.x - ped.position.x,
          activePlayerPos.z - ped.position.z
        );
        ped.root.rotation.y = lookAngle;
        continue;
      }

      const wp = ped.waypoints[ped.currentWpIndex];
      const dx = wp.x - ped.position.x;
      const dz = wp.z - ped.position.z;
      const dist = Math.hypot(dx, dz);

      if (dist < 1.0) {
        ped.currentWpIndex = (ped.currentWpIndex + 1) % ped.waypoints.length;
      } else {
        const dirX = dx / dist;
        const dirZ = dz / dist;
        ped.position.x += dirX * ped.speed * dt;
        ped.position.z += dirZ * ped.speed * dt;
        ped.rotationY = Math.atan2(dirX, dirZ);
      }

      ped.animPhase += dt * 5.5;
      const legSwing = Math.sin(ped.animPhase) * 0.45;
      ped.leftLeg.rotation.x = legSwing;
      ped.rightLeg.rotation.x = -legSwing;

      ped.root.position.copyFrom(ped.position);
      ped.root.rotation.y = ped.rotationY;
    }
  }

  public getMinimapTraffic(): MinimapVehicle[] {
    return this.trafficAgents
      .filter((a) => a.active)
      .map((a) => ({
        id: a.id,
        name: 'Traffic',
        x: a.position.x,
        z: a.position.z,
        rotY: a.rotationY,
        isTraffic: true,
      }));
  }
}
