import {
  Mesh,
  MeshBuilder,
  Scene,
  StandardMaterial,
  TransformNode,
  Vector3,
} from '@babylonjs/core';
import { MaterialLibrary } from '../materials/MaterialLibrary';
import { DATA_SHARDS, MISSIONS } from '../data/worldCatalog';
import {
  MinimapShard,
  MissionDefinition,
  MissionStage,
  NotificationBanner,
  Vec3,
} from '../../types/game';
import { saveManager } from '../../managers/SaveManager';
import { audioManager } from '../../managers/AudioManager';

export class MissionManager {
  private scene: Scene;
  private materials: MaterialLibrary;

  private activeMission: MissionDefinition | null = null;
  private stageIndex = 0;
  private timerRemaining: number | null = null;

  // 3D Checkpoint Marker Meshes
  private checkpointRoot: TransformNode;
  private ringMesh: Mesh;
  private pillarMesh: Mesh;
  private chevronMesh: Mesh;
  private checkpointMat: StandardMaterial;
  private pillarMat: StandardMaterial;

  // Collectible Shards
  private shardMeshes: Map<string, Mesh> = new Map();
  private animTime = 0;

  private onNotification: (banner: NotificationBanner) => void;

  constructor(
    scene: Scene,
    materials: MaterialLibrary,
    onNotification: (banner: NotificationBanner) => void
  ) {
    this.scene = scene;
    this.materials = materials;
    this.onNotification = onNotification;

    this.checkpointRoot = new TransformNode('checkpointBeaconRoot', this.scene);
    this.checkpointMat = this.materials.getEmissiveMaterial('checkpointCyan', '#00f0ff', 1.6);
    this.pillarMat = this.materials.getEmissiveMaterial('checkpointPillar', '#38bdf8', 0.9);
    this.pillarMat.alpha = 0.24;
    this.pillarMat.backFaceCulling = false;

    this.ringMesh = MeshBuilder.CreateTorus(
      'cpRing',
      { diameter: 11.0, thickness: 0.45, tessellation: 32 },
      this.scene
    );
    this.ringMesh.position.y = 0.25;
    this.ringMesh.material = this.checkpointMat;
    this.ringMesh.parent = this.checkpointRoot;

    this.pillarMesh = MeshBuilder.CreateCylinder(
      'cpPillar',
      { diameterTop: 9.0, diameterBottom: 10.6, height: 28, tessellation: 24 },
      this.scene
    );
    this.pillarMesh.position.y = 14;
    this.pillarMesh.material = this.pillarMat;
    this.pillarMesh.parent = this.checkpointRoot;

    this.chevronMesh = MeshBuilder.CreatePolyhedron(
      'cpChevron',
      { type: 1, size: 1.35 },
      this.scene
    );
    this.chevronMesh.position.y = 4.2;
    this.chevronMesh.material = this.checkpointMat;
    this.chevronMesh.parent = this.checkpointRoot;

    this.buildCollectibleShards();
    this.startMission(saveManager.getData().activeMissionId);
  }

  private buildCollectibleShards(): void {
    const shardMat = this.materials.getEmissiveMaterial('dataShardMat', '#fbbf24', 1.5);
    const collectedIds = new Set(saveManager.getData().collectedShardIds);

    for (const shard of DATA_SHARDS) {
      const mesh = MeshBuilder.CreatePolyhedron(
        `shard_${shard.id}`,
        { type: 1, size: 0.55 },
        this.scene
      );
      mesh.position.set(shard.pos.x, shard.pos.y, shard.pos.z);
      mesh.material = shardMat;
      mesh.setEnabled(!collectedIds.has(shard.id));
      this.shardMeshes.set(shard.id, mesh);
    }
  }

  public syncCollectedShards(): void {
    const collectedIds = new Set(saveManager.getData().collectedShardIds);
    for (const shard of DATA_SHARDS) {
      const mesh = this.shardMeshes.get(shard.id);
      if (mesh) {
        mesh.setEnabled(!collectedIds.has(shard.id));
      }
    }
  }

  public startMission(missionId: string): void {
    const found = MISSIONS.find((m) => m.id === missionId) || MISSIONS[0];
    this.activeMission = found;
    this.stageIndex = 0;
    saveManager.setActiveMission(found.id);
    this.syncStageMarker();
  }

  public restartCurrentMission(): void {
    if (this.activeMission) {
      this.stageIndex = 0;
      this.syncStageMarker();
      this.onNotification({
        id: `restart_${Date.now()}`,
        title: `${this.activeMission.code}: ${this.activeMission.title}`,
        subtitle: 'Mission restarted. Proceed to the first checkpoint.',
        type: 'info',
        timestamp: Date.now(),
      });
    }
  }

  private syncStageMarker(): void {
    const stage = this.getCurrentStage();
    if (!stage) {
      this.checkpointRoot.setEnabled(false);
      this.timerRemaining = null;
      return;
    }

    this.checkpointRoot.setEnabled(true);
    this.checkpointRoot.position.set(stage.targetPos.x, stage.targetPos.y, stage.targetPos.z);
    this.timerRemaining = stage.timeLimitSeconds ?? null;
  }

  public getActiveMission(): MissionDefinition | null {
    return this.activeMission;
  }

  public getStageIndex(): number {
    return this.stageIndex;
  }

  public getCurrentStage(): MissionStage | null {
    if (!this.activeMission) return null;
    return this.activeMission.stages[this.stageIndex] || null;
  }

  public getTimerRemaining(): number | null {
    return this.timerRemaining;
  }

  public update(dt: number, activeEntityPos: Vector3): number {
    this.animTime += dt;

    // Animate collectible shards & check collection
    const collectedSet = new Set(saveManager.getData().collectedShardIds);
    for (const shard of DATA_SHARDS) {
      if (collectedSet.has(shard.id)) continue;
      const mesh = this.shardMeshes.get(shard.id);
      if (!mesh) continue;

      mesh.rotation.y = this.animTime * 2.2;
      mesh.position.y = shard.pos.y + Math.sin(this.animTime * 3.0 + shard.pos.x) * 0.22;

      const distToShard = Math.hypot(activeEntityPos.x - shard.pos.x, activeEntityPos.z - shard.pos.z);
      if (distToShard < 3.2) {
        if (saveManager.collectShard(shard.id, 150, 100)) {
          mesh.setEnabled(false);
          audioManager.playCheckpoint();
          this.onNotification({
            id: `shard_${shard.id}_${Date.now()}`,
            title: 'HORIZON DATA SHARD RECOVERED',
            subtitle: shard.name,
            rewardText: '+150 ₡  •  +100 XP',
            type: 'shard',
            timestamp: Date.now(),
          });
        }
      }
    }

    const stage = this.getCurrentStage();
    if (!stage || !this.activeMission) return 0;

    // Animate checkpoint ring & chevron
    const pulse = 1 + Math.sin(this.animTime * 3.5) * 0.08;
    this.ringMesh.scaling.set(pulse, 1, pulse);
    this.chevronMesh.rotation.y = this.animTime * 1.8;
    this.chevronMesh.position.y = 4.2 + Math.sin(this.animTime * 2.6) * 0.45;

    // Update Time Trial countdown if applicable
    if (this.timerRemaining !== null) {
      this.timerRemaining = Math.max(0, this.timerRemaining - dt);
      if (this.timerRemaining <= 0) {
        // Reset mission to stage 0
        this.stageIndex = 0;
        this.syncStageMarker();
        this.onNotification({
          id: `timeout_${Date.now()}`,
          title: 'TIME TRIAL EXPIRED',
          subtitle: 'Countdown reached zero. Resetting to Gate 1!',
          type: 'info',
          timestamp: Date.now(),
        });
        return Math.hypot(
          activeEntityPos.x - stage.targetPos.x,
          activeEntityPos.z - stage.targetPos.z
        );
      }
    }

    const dist = Math.hypot(
      activeEntityPos.x - stage.targetPos.x,
      activeEntityPos.z - stage.targetPos.z
    );

    if (dist <= stage.radius) {
      this.handleStageReached();
    }

    return dist;
  }

  private handleStageReached(): void {
    if (!this.activeMission) return;

    const isLastStage = this.stageIndex >= this.activeMission.stages.length - 1;

    if (!isLastStage) {
      this.stageIndex++;
      const nextStage = this.getCurrentStage();
      this.syncStageMarker();
      audioManager.playCheckpoint();
      this.onNotification({
        id: `cp_${Date.now()}`,
        title: `CHECKPOINT ${this.stageIndex}/${this.activeMission.stages.length} REACHED`,
        subtitle: nextStage ? nextStage.title : 'Proceed to next waypoint',
        type: 'checkpoint',
        timestamp: Date.now(),
      });
    } else {
      // Mission Completed!
      const completedMission = this.activeMission;
      audioManager.playMissionComplete();

      const nextMissionId = saveManager.completeMission(
        completedMission.id,
        completedMission.rewardCredits,
        completedMission.rewardXp
      );

      this.onNotification({
        id: `mission_done_${Date.now()}`,
        title: `MISSION COMPLETED: ${completedMission.title.toUpperCase()}`,
        subtitle: `Next Objective Unlocked`,
        rewardText: `+${completedMission.rewardCredits} ₡  •  +${completedMission.rewardXp} XP`,
        type: 'mission_complete',
        timestamp: Date.now(),
      });

      this.startMission(nextMissionId);
    }
  }

  public getMinimapShards(): MinimapShard[] {
    const collected = new Set(saveManager.getData().collectedShardIds);
    return DATA_SHARDS.map((s) => ({
      id: s.id,
      x: s.pos.x,
      z: s.pos.z,
      collected: collected.has(s.id),
    }));
  }

  public getTargetPosition(): Vec3 | null {
    const st = this.getCurrentStage();
    return st ? st.targetPos : null;
  }
}
