import { FreeCamera, Scene, Vector3 } from '@babylonjs/core';
import { CollisionSystem } from './CollisionSystem';

export class CameraController {
  public camera: FreeCamera;
  private collision: CollisionSystem;

  public yaw = 0; // Horizontal angle in radians (0 = looking toward +Z)
  public pitch = 0.28; // Vertical angle in radians
  public distance = 6.2;

  private currentFocus: Vector3 = new Vector3(0, 1.5, -48);
  private currentPos: Vector3 = new Vector3(0, 4, -55);
  private menuOrbitAngle = 0;
  private manualOrbitCooldown = 0;

  constructor(scene: Scene, collision: CollisionSystem) {
    this.collision = collision;
    this.camera = new FreeCamera('horizonCamera', new Vector3(0, 5, -56), scene);
    this.camera.minZ = 0.25;
    this.camera.maxZ = 520;
    this.camera.fov = 0.88;
  }

  public handleMouseDelta(dx: number, dy: number, sensitivity: number): void {
    const scale = 0.0026 * sensitivity;
    this.yaw += dx * scale;
    this.pitch = Math.max(-0.18, Math.min(1.05, this.pitch + dy * scale));
    this.manualOrbitCooldown = 1.6;
  }

  public handleZoomDelta(wheelDeltaY: number): void {
    this.distance = Math.max(3.4, Math.min(13.5, this.distance + wheelDeltaY * 0.004));
  }

  public updateGameplayCamera(
    dt: number,
    targetPos: Vector3,
    targetHeadingY: number,
    isDriving: boolean,
    speedKmh: number
  ): void {
    this.manualOrbitCooldown = Math.max(0, this.manualOrbitCooldown - dt);

    // When driving and user hasn't moved mouse recently, gently align camera behind vehicle heading
    if (isDriving && speedKmh > 6 && this.manualOrbitCooldown <= 0) {
      let diff = targetHeadingY - this.yaw;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;
      this.yaw += diff * Math.min(1, dt * 3.6);
    }

    const focusHeight = isDriving ? 1.45 : 1.52;
    const desiredFocus = new Vector3(targetPos.x, targetPos.y + focusHeight, targetPos.z);

    // Smooth target focus interpolation
    const focusLerp = Math.min(1, dt * (isDriving ? 16 : 14));
    Vector3.LerpToRef(this.currentFocus, desiredFocus, focusLerp, this.currentFocus);

    // Dynamic distance & FOV boost when driving fast
    const speedExtraDist = isDriving ? Math.min(3.4, (speedKmh / 180) * 3.4) : 0;
    const effectiveDist = this.distance + (isDriving ? 2.1 + speedExtraDist : 0);

    const targetFov = isDriving ? 0.88 + Math.min(0.18, (speedKmh / 200) * 0.18) : 0.86;
    this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 6);

    const cosPitch = Math.cos(this.pitch);
    const sinPitch = Math.sin(this.pitch);
    const sinYaw = Math.sin(this.yaw);
    const cosYaw = Math.cos(this.yaw);

    // Camera sits behind the yaw direction
    const desiredCamX = this.currentFocus.x - sinYaw * cosPitch * effectiveDist;
    const desiredCamY = this.currentFocus.y + sinPitch * effectiveDist;
    const desiredCamZ = this.currentFocus.z - cosYaw * cosPitch * effectiveDist;

    // Prevent camera from clipping through building walls
    const clipped = this.collision.clipCameraRay(
      this.currentFocus.x,
      this.currentFocus.y,
      this.currentFocus.z,
      desiredCamX,
      desiredCamY,
      desiredCamZ,
      0.55
    );

    const posLerp = Math.min(1, dt * 18);
    this.currentPos.x += (clipped.x - this.currentPos.x) * posLerp;
    this.currentPos.y += (clipped.y - this.currentPos.y) * posLerp;
    this.currentPos.z += (clipped.z - this.currentPos.z) * posLerp;

    this.camera.position.copyFrom(this.currentPos);
    this.camera.setTarget(this.currentFocus);
  }

  public updateMenuOrbitCamera(dt: number): void {
    this.menuOrbitAngle += dt * 0.14;
    const radius = 68;
    const cx = Math.sin(this.menuOrbitAngle) * radius;
    const cz = Math.cos(this.menuOrbitAngle) * radius - 10;
    const cy = 28 + Math.sin(this.menuOrbitAngle * 0.7) * 5;

    this.camera.position.set(cx, cy, cz);
    this.camera.setTarget(new Vector3(0, 14, 15));
  }
}
