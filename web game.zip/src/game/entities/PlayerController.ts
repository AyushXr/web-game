import {
  MeshBuilder,
  Scene,
  ShadowGenerator,
  TransformNode,
  Vector3,
} from '@babylonjs/core';
import { MaterialLibrary } from '../materials/MaterialLibrary';
import { CollisionSystem } from '../systems/CollisionSystem';
import { PLAYER_SPAWN_POS } from '../data/worldCatalog';
import { audioManager } from '../../managers/AudioManager';

export interface PlayerInputState {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  sprint: boolean;
  jump: boolean;
}

export class PlayerController {
  private scene: Scene;
  private materials: MaterialLibrary;
  private collision: CollisionSystem;

  public root: TransformNode;
  private bodyNode: TransformNode;
  private headNode: TransformNode;
  private leftArmPivot: TransformNode;
  private rightArmPivot: TransformNode;
  private leftLegPivot: TransformNode;
  private rightLegPivot: TransformNode;

  public position: Vector3 = new Vector3(PLAYER_SPAWN_POS.x, PLAYER_SPAWN_POS.y, PLAYER_SPAWN_POS.z);
  public velocity: Vector3 = new Vector3(0, 0, 0);
  public rotationY = 0; // Facing North (+Z) initially
  public isGrounded = true;
  public isSprinting = false;
  public stamina = 100;
  public isVisible = true;

  private animTime = 0;
  private readonly walkSpeed = 7.2;
  private readonly sprintSpeed = 12.8;
  private readonly jumpImpulse = 8.4;
  private readonly gravity = -22.0;
  private readonly collisionRadius = 0.55;

  constructor(
    scene: Scene,
    materials: MaterialLibrary,
    collision: CollisionSystem,
    shadowGen: ShadowGenerator | null
  ) {
    this.scene = scene;
    this.materials = materials;
    this.collision = collision;

    this.root = new TransformNode('playerRoot', this.scene);
    this.bodyNode = new TransformNode('playerBody', this.scene);
    this.bodyNode.parent = this.root;

    this.headNode = new TransformNode('playerHead', this.scene);
    this.leftArmPivot = new TransformNode('playerLeftArm', this.scene);
    this.rightArmPivot = new TransformNode('playerRightArm', this.scene);
    this.leftLegPivot = new TransformNode('playerLeftLeg', this.scene);
    this.rightLegPivot = new TransformNode('playerRightLeg', this.scene);

    this.buildHumanoidMesh(shadowGen);
    this.syncTransform();
  }

  private buildHumanoidMesh(shadowGen: ShadowGenerator | null): void {
    const jacketMat = this.materials.getSolidPBR('playerJacket', '#1e293b', 0.35, 0.45);
    const pantsMat = this.materials.getSolidPBR('playerPants', '#0f172a', 0.2, 0.65);
    const skinMat = this.materials.getSolidPBR('playerSkin', '#e2b897', 0.1, 0.7);
    const hairMat = this.materials.getSolidPBR('playerHair', '#090d16', 0.2, 0.5);
    const cyanTrimMat = this.materials.getEmissiveMaterial('playerTrim', '#00f0ff', 1.4);

    // Torso (Jacket)
    const torso = MeshBuilder.CreateBox('pTorso', { width: 0.54, height: 0.68, depth: 0.3 }, this.scene);
    torso.position.set(0, 1.14, 0);
    torso.material = jacketMat;
    torso.parent = this.bodyNode;

    // Cyber-collar / back trim
    const pack = MeshBuilder.CreateBox('pPack', { width: 0.34, height: 0.42, depth: 0.14 }, this.scene);
    pack.position.set(0, 1.18, -0.18);
    pack.material = pantsMat;
    pack.parent = this.bodyNode;

    const packGlow = MeshBuilder.CreateBox('pPackGlow', { width: 0.08, height: 0.28, depth: 0.16 }, this.scene);
    packGlow.position.set(0, 1.18, -0.19);
    packGlow.material = cyanTrimMat;
    packGlow.parent = this.bodyNode;

    // Head
    this.headNode.parent = this.bodyNode;
    this.headNode.position.set(0, 1.64, 0);

    const head = MeshBuilder.CreateBox('pHead', { width: 0.34, height: 0.36, depth: 0.34 }, this.scene);
    head.material = skinMat;
    head.parent = this.headNode;

    const hair = MeshBuilder.CreateBox('pHair', { width: 0.36, height: 0.14, depth: 0.36 }, this.scene);
    hair.position.set(0, 0.14, -0.01);
    hair.material = hairMat;
    hair.parent = this.headNode;

    const visor = MeshBuilder.CreateBox('pVisor', { width: 0.32, height: 0.08, depth: 0.06 }, this.scene);
    visor.position.set(0, 0.03, 0.16);
    visor.material = cyanTrimMat;
    visor.parent = this.headNode;

    // Left & Right Arms
    this.leftArmPivot.parent = this.bodyNode;
    this.leftArmPivot.position.set(-0.36, 1.42, 0);
    const leftArm = MeshBuilder.CreateBox('pLArm', { width: 0.17, height: 0.58, depth: 0.18 }, this.scene);
    leftArm.position.set(0, -0.24, 0);
    leftArm.material = jacketMat;
    leftArm.parent = this.leftArmPivot;

    this.rightArmPivot.parent = this.bodyNode;
    this.rightArmPivot.position.set(0.36, 1.42, 0);
    const rightArm = MeshBuilder.CreateBox('pRArm', { width: 0.17, height: 0.58, depth: 0.18 }, this.scene);
    rightArm.position.set(0, -0.24, 0);
    rightArm.material = jacketMat;
    rightArm.parent = this.rightArmPivot;

    // Left & Right Legs
    this.leftLegPivot.parent = this.bodyNode;
    this.leftLegPivot.position.set(-0.15, 0.78, 0);
    const leftLeg = MeshBuilder.CreateBox('pLLeg', { width: 0.21, height: 0.76, depth: 0.22 }, this.scene);
    leftLeg.position.set(0, -0.38, 0);
    leftLeg.material = pantsMat;
    leftLeg.parent = this.leftLegPivot;

    this.rightLegPivot.parent = this.bodyNode;
    this.rightLegPivot.position.set(0.15, 0.78, 0);
    const rightLeg = MeshBuilder.CreateBox('pRLeg', { width: 0.21, height: 0.76, depth: 0.22 }, this.scene);
    rightLeg.position.set(0, -0.38, 0);
    rightLeg.material = pantsMat;
    rightLeg.parent = this.rightLegPivot;

    if (shadowGen) {
      shadowGen.addShadowCaster(torso);
      shadowGen.addShadowCaster(head);
      shadowGen.addShadowCaster(leftArm);
      shadowGen.addShadowCaster(rightArm);
      shadowGen.addShadowCaster(leftLeg);
      shadowGen.addShadowCaster(rightLeg);
    }
  }

  public setVisible(visible: boolean): void {
    this.isVisible = visible;
    this.root.setEnabled(visible);
  }

  public resetToSpawn(): void {
    this.position.set(PLAYER_SPAWN_POS.x, PLAYER_SPAWN_POS.y, PLAYER_SPAWN_POS.z);
    this.velocity.set(0, 0, 0);
    this.rotationY = 0;
    this.syncTransform();
  }

  public update(dt: number, input: PlayerInputState, cameraYaw: number): number {
    if (!this.isVisible) return 0;

    // Calculate desired movement vector in world XZ relative to cameraYaw
    let moveForward = 0;
    let moveRight = 0;
    if (input.forward) moveForward += 1;
    if (input.backward) moveForward -= 1;
    if (input.right) moveRight += 1;
    if (input.left) moveRight -= 1;

    const hasInput = moveForward !== 0 || moveRight !== 0;

    // Sprint & Stamina management
    if (hasInput && input.sprint && this.stamina > 5) {
      this.isSprinting = true;
      this.stamina = Math.max(0, this.stamina - 18 * dt);
    } else {
      this.isSprinting = false;
      this.stamina = Math.min(100, this.stamina + 24 * dt);
    }

    const targetSpeed = hasInput ? (this.isSprinting ? this.sprintSpeed : this.walkSpeed) : 0;

    let targetVelX = 0;
    let targetVelZ = 0;

    if (hasInput) {
      const len = Math.sqrt(moveForward * moveForward + moveRight * moveRight);
      const nf = moveForward / len;
      const nr = moveRight / len;

      const sinYaw = Math.sin(cameraYaw);
      const cosYaw = Math.cos(cameraYaw);

      const dirX = sinYaw * nf + cosYaw * nr;
      const dirZ = cosYaw * nf - sinYaw * nr;

      targetVelX = dirX * targetSpeed;
      targetVelZ = dirZ * targetSpeed;

      // Smoothly rotate character toward movement direction
      const targetAngle = Math.atan2(dirX, dirZ);
      this.rotationY = this.lerpAngle(this.rotationY, targetAngle, Math.min(1, dt * 12));
    }

    // Smooth horizontal acceleration / deceleration
    const accelRate = hasInput ? 11.0 : 14.0;
    this.velocity.x += (targetVelX - this.velocity.x) * Math.min(1, dt * accelRate);
    this.velocity.z += (targetVelZ - this.velocity.z) * Math.min(1, dt * accelRate);

    // Jump & Gravity
    if (input.jump && this.isGrounded) {
      this.velocity.y = this.jumpImpulse;
      this.isGrounded = false;
      audioManager.playJump();
    }

    this.velocity.y += this.gravity * dt;

    const prevX = this.position.x;
    const prevZ = this.position.z;

    const nextX = this.position.x + this.velocity.x * dt;
    const nextZ = this.position.z + this.velocity.z * dt;
    let nextY = this.position.y + this.velocity.y * dt;

    // Resolve horizontal collision with buildings & props
    const resolved = this.collision.resolveHorizontalCircle(
      nextX,
      this.position.y,
      nextZ,
      this.collisionRadius,
      1.8
    );

    this.position.x = resolved.x;
    this.position.z = resolved.z;

    if (resolved.collided) {
      // Remove velocity component into wall normal
      const dot = this.velocity.x * resolved.normalX + this.velocity.z * resolved.normalZ;
      if (dot < 0) {
        this.velocity.x -= dot * resolved.normalX;
        this.velocity.z -= dot * resolved.normalZ;
      }
    }

    // Ground height detection
    const groundY = this.collision.getGroundHeight(this.position.x, this.position.z, this.position.y);
    if (nextY <= groundY) {
      nextY = groundY;
      this.velocity.y = 0;
      this.isGrounded = true;
    } else {
      this.isGrounded = false;
    }
    this.position.y = nextY;

    const horizontalSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    this.updateProceduralAnimation(dt, horizontalSpeed);
    audioManager.updateFootsteps(dt, horizontalSpeed > 0.8, this.isSprinting, this.isGrounded);

    this.syncTransform();

    return Math.hypot(this.position.x - prevX, this.position.z - prevZ);
  }

  private updateProceduralAnimation(dt: number, horizontalSpeed: number): void {
    if (!this.isGrounded) {
      // Airborne pose
      this.leftLegPivot.rotation.x = -0.35;
      this.rightLegPivot.rotation.x = 0.25;
      this.leftArmPivot.rotation.x = -0.5;
      this.rightArmPivot.rotation.x = -0.5;
      this.bodyNode.rotation.x = 0.08;
      return;
    }

    if (horizontalSpeed > 0.35) {
      const speedFactor = horizontalSpeed / this.walkSpeed;
      this.animTime += dt * (6.8 * Math.min(1.8, speedFactor));
      const swing = Math.sin(this.animTime) * Math.min(0.75, 0.42 * speedFactor);

      this.leftLegPivot.rotation.x = swing;
      this.rightLegPivot.rotation.x = -swing;
      this.leftArmPivot.rotation.x = -swing * 0.85;
      this.rightArmPivot.rotation.x = swing * 0.85;

      // Subtle forward lean when sprinting
      const targetLean = this.isSprinting ? 0.16 : 0.05;
      this.bodyNode.rotation.x += (targetLean - this.bodyNode.rotation.x) * Math.min(1, dt * 10);
      this.bodyNode.position.y = Math.abs(Math.cos(this.animTime)) * 0.04;
    } else {
      // Idle breathing animation
      this.animTime += dt * 2.2;
      this.leftLegPivot.rotation.x *= 0.85;
      this.rightLegPivot.rotation.x *= 0.85;
      this.leftArmPivot.rotation.x = Math.sin(this.animTime) * 0.04;
      this.rightArmPivot.rotation.x = -Math.sin(this.animTime) * 0.04;
      this.bodyNode.rotation.x *= 0.85;
      this.bodyNode.position.y = Math.sin(this.animTime) * 0.015;
    }
  }

  private syncTransform(): void {
    this.root.position.copyFrom(this.position);
    this.root.rotation.y = this.rotationY;
  }

  private lerpAngle(current: number, target: number, t: number): number {
    let diff = target - current;
    while (diff < -Math.PI) diff += Math.PI * 2;
    while (diff > Math.PI) diff -= Math.PI * 2;
    return current + diff * t;
  }
}
