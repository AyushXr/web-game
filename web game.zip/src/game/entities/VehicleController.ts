import {
  Mesh,
  MeshBuilder,
  Scene,
  ShadowGenerator,
  StandardMaterial,
  TransformNode,
  Vector3,
} from '@babylonjs/core';
import { MaterialLibrary } from '../materials/MaterialLibrary';
import { CollisionSystem } from '../systems/CollisionSystem';
import { VehicleSpec } from '../../types/game';
import { audioManager } from '../../managers/AudioManager';

export interface VehicleInputState {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  handbrake: boolean;
  boost: boolean;
}

export class VehicleEntity {
  public readonly spec: VehicleSpec;
  public root: TransformNode;
  private chassisNode: TransformNode;
  private wheelSteerFL: TransformNode;
  private wheelSteerFR: TransformNode;
  private wheelSpinMeshes: Mesh[] = [];
  private brakeLightMat: StandardMaterial;
  private markerMesh: Mesh;

  public position: Vector3;
  public rotationY: number;
  public speed = 0; // signed forward speed
  public lateralSpeed = 0; // drift lateral velocity
  public steerAngle = 0;
  public nitro = 100;
  public isOccupied = false;
  public isDrifting = false;

  // Suspension visual state
  private pitchAngle = 0;
  private rollAngle = 0;
  private bouncePhase = 0;
  private collisionCooldown = 0;

  constructor(
    spec: VehicleSpec,
    scene: Scene,
    materials: MaterialLibrary,
    shadowGen: ShadowGenerator | null
  ) {
    this.spec = spec;
    this.position = new Vector3(spec.spawnPos.x, spec.spawnPos.y, spec.spawnPos.z);
    this.rotationY = spec.spawnRotY;

    this.root = new TransformNode(`vehicle_${spec.id}`, scene);
    this.chassisNode = new TransformNode(`chassis_${spec.id}`, scene);
    this.chassisNode.parent = this.root;

    this.wheelSteerFL = new TransformNode(`steerFL_${spec.id}`, scene);
    this.wheelSteerFR = new TransformNode(`steerFR_${spec.id}`, scene);
    this.wheelSteerFL.parent = this.root;
    this.wheelSteerFR.parent = this.root;

    this.brakeLightMat = materials.getEmissiveMaterial(`brake_${spec.id}`, '#ef4444', 0.65);

    this.markerMesh = this.buildCarMesh(scene, materials, shadowGen);
    this.syncTransform(0);
  }

  private buildCarMesh(
    scene: Scene,
    materials: MaterialLibrary,
    shadowGen: ShadowGenerator | null
  ): Mesh {
    const bodyMat = materials.getSolidPBR(`carBody_${this.spec.id}`, this.spec.primaryColor, 0.72, 0.24);
    const trimMat = materials.getSolidPBR(`carTrim_${this.spec.id}`, this.spec.secondaryColor, 0.4, 0.45);
    const glassMat = materials.getSolidPBR(`carGlass_${this.spec.id}`, '#090d16', 0.9, 0.12);
    const tireMat = materials.getSolidPBR(`carTire_${this.spec.id}`, '#111827', 0.1, 0.85);
    const rimMat = materials.getSolidPBR(`carRim_${this.spec.id}`, '#cbd5e1', 0.85, 0.2);
    const headlightMat = materials.getEmissiveMaterial(`headlight_${this.spec.id}`, '#e0f2fe', 1.6);
    const neonMat = materials.getEmissiveMaterial(`neon_${this.spec.id}`, this.spec.neonColor, 1.3);

    const isSuv = this.spec.category === 'Tactical SUV';
    const bodyHeight = isSuv ? 0.72 : 0.54;
    const cabinHeight = isSuv ? 0.62 : 0.46;
    const cabinLength = isSuv ? 2.4 : 1.95;

    // Main lower body
    const lowerBody = MeshBuilder.CreateBox(
      `vLower_${this.spec.id}`,
      { width: 2.05, height: bodyHeight, depth: 4.5 },
      scene
    );
    lowerBody.position.set(0, 0.62, 0);
    lowerBody.material = bodyMat;
    lowerBody.parent = this.chassisNode;

    // Front splitter & side skirts
    const skirt = MeshBuilder.CreateBox(
      `vSkirt_${this.spec.id}`,
      { width: 2.12, height: 0.16, depth: 4.6 },
      scene
    );
    skirt.position.set(0, 0.34, 0);
    skirt.material = trimMat;
    skirt.parent = this.chassisNode;

    // Underglow strip
    const underglow = MeshBuilder.CreateBox(
      `vGlow_${this.spec.id}`,
      { width: 1.75, height: 0.05, depth: 3.6 },
      scene
    );
    underglow.position.set(0, 0.22, 0);
    underglow.material = neonMat;
    underglow.parent = this.chassisNode;

    // Cabin / Greenhouse
    const cabin = MeshBuilder.CreateBox(
      `vCabin_${this.spec.id}`,
      { width: 1.72, height: cabinHeight, depth: cabinLength },
      scene
    );
    cabin.position.set(0, 0.62 + bodyHeight * 0.5 + cabinHeight * 0.45, -0.2);
    cabin.material = glassMat;
    cabin.parent = this.chassisNode;

    // Roof cap
    const roof = MeshBuilder.CreateBox(
      `vRoof_${this.spec.id}`,
      { width: 1.66, height: 0.08, depth: cabinLength - 0.25 },
      scene
    );
    roof.position.set(0, cabin.position.y + cabinHeight * 0.5, -0.2);
    roof.material = bodyMat;
    roof.parent = this.chassisNode;

    // Rear Spoiler for sports/hyper cars
    if (!isSuv) {
      const wing = MeshBuilder.CreateBox(
        `vWing_${this.spec.id}`,
        { width: 1.95, height: 0.08, depth: 0.36 },
        scene
      );
      wing.position.set(0, 1.12, -2.05);
      wing.material = trimMat;
      wing.parent = this.chassisNode;
    }

    // Headlights (Front is +Z)
    for (const side of [-0.72, 0.72]) {
      const hl = MeshBuilder.CreateBox(
        `vHL_${this.spec.id}_${side}`,
        { width: 0.42, height: 0.16, depth: 0.1 },
        scene
      );
      hl.position.set(side, 0.68, 2.24);
      hl.material = headlightMat;
      hl.parent = this.chassisNode;
    }

    // Taillight bar (Rear is -Z)
    const tailBar = MeshBuilder.CreateBox(
      `vTail_${this.spec.id}`,
      { width: 1.82, height: 0.16, depth: 0.1 },
      scene
    );
    tailBar.position.set(0, 0.72, -2.24);
    tailBar.material = this.brakeLightMat;
    tailBar.parent = this.chassisNode;

    // 4 Wheels
    const wheelOffsets: Array<{ name: string; x: number; z: number; isFront: boolean }> = [
      { name: 'FL', x: -1.04, z: 1.42, isFront: true },
      { name: 'FR', x: 1.04, z: 1.42, isFront: true },
      { name: 'RL', x: -1.04, z: -1.42, isFront: false },
      { name: 'RR', x: 1.04, z: -1.42, isFront: false },
    ];

    this.wheelSteerFL.position.set(-1.04, 0.42, 1.42);
    this.wheelSteerFR.position.set(1.04, 0.42, 1.42);

    for (const w of wheelOffsets) {
      const tire = MeshBuilder.CreateCylinder(
        `wheel_${this.spec.id}_${w.name}`,
        { diameter: 0.82, height: 0.34, tessellation: 16 },
        scene
      );
      tire.rotation.z = Math.PI * 0.5;
      tire.material = tireMat;

      const hub = MeshBuilder.CreateCylinder(
        `hub_${this.spec.id}_${w.name}`,
        { diameter: 0.48, height: 0.36, tessellation: 10 },
        scene
      );
      hub.material = rimMat;
      hub.parent = tire;

      if (w.isFront) {
        tire.parent = w.x < 0 ? this.wheelSteerFL : this.wheelSteerFR;
        tire.position.set(0, 0, 0);
      } else {
        tire.parent = this.root;
        tire.position.set(w.x, 0.42, w.z);
      }

      this.wheelSpinMeshes.push(tire);
    }

    // Floating diamond marker above unoccupied driveable vehicle
    const marker = MeshBuilder.CreatePolyhedron(
      `vMarker_${this.spec.id}`,
      { type: 1, size: 0.26 },
      scene
    );
    marker.position.set(0, 2.55, 0);
    marker.material = neonMat;
    marker.parent = this.root;

    if (shadowGen) {
      shadowGen.addShadowCaster(lowerBody);
      shadowGen.addShadowCaster(cabin);
    }

    return marker;
  }

  public setOccupied(occupied: boolean): void {
    this.isOccupied = occupied;
    this.markerMesh.setEnabled(!occupied);
    if (!occupied) {
      this.isDrifting = false;
    }
  }

  public resetToRoad(): void {
    // Snap vehicle upright and clear velocity
    this.speed = 0;
    this.lateralSpeed = 0;
    this.steerAngle = 0;
    this.pitchAngle = 0;
    this.rollAngle = 0;
    this.position.y = 0;

    // Snap to nearest grid avenue X or Z so the car is guaranteed out of tight corners
    const grid = [-120, -60, 0, 60, 120];
    let nearestX = grid[0];
    let nearestZ = grid[0];
    for (const g of grid) {
      if (Math.abs(this.position.x - g) < Math.abs(this.position.x - nearestX)) nearestX = g;
      if (Math.abs(this.position.z - g) < Math.abs(this.position.z - nearestZ)) nearestZ = g;
    }
    if (Math.abs(this.position.x - nearestX) < Math.abs(this.position.z - nearestZ)) {
      this.position.x = nearestX + 3.2;
      this.rotationY = 0;
    } else {
      this.position.z = nearestZ - 3.2;
      this.rotationY = Math.PI * 0.5;
    }
    this.syncTransform(0);
  }

  public update(
    dt: number,
    input: VehicleInputState | null,
    collision: CollisionSystem,
    otherVehicles: VehicleEntity[]
  ): number {
    this.collisionCooldown = Math.max(0, this.collisionCooldown - dt);

    let throttleInput = 0;
    let steerInput = 0;
    let isBraking = false;
    let isBoosting = false;

    if (this.isOccupied && input) {
      if (input.forward) throttleInput += 1;
      if (input.backward) throttleInput -= 1;
      if (input.left) steerInput -= 1;
      if (input.right) steerInput += 1;

      if (input.boost && throttleInput > 0 && this.nitro > 4) {
        isBoosting = true;
        this.nitro = Math.max(0, this.nitro - 26 * dt);
      } else {
        this.nitro = Math.min(100, this.nitro + 14 * dt);
      }

      const maxSpd = this.spec.topSpeed * (isBoosting ? 1.24 : 1.0);
      const accel = this.spec.acceleration * (isBoosting ? 1.45 : 1.0);

      if (throttleInput > 0) {
        if (this.speed < 0) {
          // Braking while reversing
          isBraking = true;
          this.speed = Math.min(0, this.speed + this.spec.braking * dt);
        } else {
          this.speed = Math.min(maxSpd, this.speed + accel * dt);
        }
      } else if (throttleInput < 0) {
        if (this.speed > 0.5) {
          // Braking while moving forward
          isBraking = true;
          this.speed = Math.max(0, this.speed - this.spec.braking * dt);
        } else {
          // Reversing
          this.speed = Math.max(-maxSpd * 0.42, this.speed - this.spec.acceleration * 0.8 * dt);
        }
      } else {
        // Natural rolling resistance
        const drag = 6.5;
        if (Math.abs(this.speed) < drag * dt) {
          this.speed = 0;
        } else {
          this.speed -= Math.sign(this.speed) * drag * dt;
        }
      }

      // Handbrake
      if (input.handbrake) {
        isBraking = true;
        this.speed *= Math.max(0, 1 - 2.6 * dt);
        this.isDrifting = Math.abs(this.speed) > 8 && Math.abs(steerInput) > 0.1;
      } else {
        this.isDrifting = false;
      }

      // Smooth front wheel steering angle
      const targetSteer = steerInput * 0.55;
      this.steerAngle += (targetSteer - this.steerAngle) * Math.min(1, dt * 11);

      // Yaw rotation when moving
      if (Math.abs(this.speed) > 0.25) {
        const speedRatio = Math.min(1, Math.abs(this.speed) / 8.0);
        const highSpeedDamp = 1.0 - Math.min(0.38, (Math.abs(this.speed) / maxSpd) * 0.38);
        const driftMultiplier = this.isDrifting ? 1.38 : 1.0;
        const turnDir = this.speed >= 0 ? 1 : -1;

        const yawDelta =
          this.steerAngle *
          this.spec.handling *
          speedRatio *
          highSpeedDamp *
          driftMultiplier *
          turnDir *
          dt;

        this.rotationY += yawDelta;

        // Lateral slip during hard turns or handbrake drift
        const targetLat = this.isDrifting ? -steerInput * Math.abs(this.speed) * 0.22 : 0;
        this.lateralSpeed += (targetLat - this.lateralSpeed) * Math.min(1, dt * 6);
      } else {
        this.lateralSpeed *= 0.8;
      }

      // Suspension pitch & roll feedback
      const targetPitch =
        isBraking && this.speed > 1
          ? 0.045
          : throttleInput > 0
          ? -0.032 * (isBoosting ? 1.4 : 1.0)
          : 0;
      const targetRoll = -this.steerAngle * Math.min(1, Math.abs(this.speed) / 22) * 0.085;

      this.pitchAngle += (targetPitch - this.pitchAngle) * Math.min(1, dt * 9);
      this.rollAngle += (targetRoll - this.rollAngle) * Math.min(1, dt * 9);
    } else {
      // Unoccupied parked damping
      this.speed *= Math.max(0, 1 - 8 * dt);
      this.lateralSpeed *= 0.8;
      this.steerAngle *= 0.85;
      this.pitchAngle *= 0.85;
      this.rollAngle *= 0.85;
    }

    // Brake light emissive brightness
    const brakeIntensity = isBraking ? 2.2 : this.isOccupied ? 0.9 : 0.35;
    this.brakeLightMat.emissiveColor.set(brakeIntensity, 0.15 * brakeIntensity, 0.18 * brakeIntensity);

    // Move vehicle in world XZ
    const prevX = this.position.x;
    const prevZ = this.position.z;

    if (Math.abs(this.speed) > 0.01 || Math.abs(this.lateralSpeed) > 0.01) {
      const sinY = Math.sin(this.rotationY);
      const cosY = Math.cos(this.rotationY);

      const vx = sinY * this.speed + cosY * this.lateralSpeed;
      const vz = cosY * this.speed - sinY * this.lateralSpeed;

      const nextX = this.position.x + vx * dt;
      const nextZ = this.position.z + vz * dt;

      // Building & obstacle collision resolution (radius 1.75m)
      const res = collision.resolveHorizontalCircle(nextX, this.position.y, nextZ, 1.75, 1.6);
      this.position.x = res.x;
      this.position.z = res.z;

      if (res.collided) {
        // Reduce speed on wall impact
        const impactSpeed = Math.abs(this.speed);
        this.speed *= 0.55;
        if (impactSpeed > 6 && this.collisionCooldown <= 0) {
          audioManager.playCollisionBump(Math.min(1, impactSpeed / 30));
          this.collisionCooldown = 0.3;
        }
      }

      // Check collision against other parked/driveable vehicles
      for (const other of otherVehicles) {
        if (other === this) continue;
        const dx = this.position.x - other.position.x;
        const dz = this.position.z - other.position.z;
        const dist = Math.hypot(dx, dz);
        const minDist = 3.2;
        if (dist < minDist && dist > 0.001) {
          const overlap = minDist - dist;
          const nx = dx / dist;
          const nz = dz / dist;
          this.position.x += nx * overlap * 0.7;
          this.position.z += nz * overlap * 0.7;
          other.position.x -= nx * overlap * 0.3;
          other.position.z -= nz * overlap * 0.3;
          this.speed *= 0.6;
          if (this.collisionCooldown <= 0) {
            audioManager.playCollisionBump(0.5);
            this.collisionCooldown = 0.3;
          }
        }
      }
    }

    this.position.y = collision.getGroundHeight(this.position.x, this.position.z, this.position.y);

    // Update engine audio if occupied
    if (this.isOccupied) {
      audioManager.updateVehicleAudio(
        true,
        this.getRpm(),
        throttleInput,
        isBraking || this.isDrifting
      );
    }

    this.syncTransform(dt);
    return Math.hypot(this.position.x - prevX, this.position.z - prevZ);
  }

  private syncTransform(dt: number): void {
    this.root.position.copyFrom(this.position);
    this.root.rotation.y = this.rotationY;

    // Subtle suspension bounce at speed
    if (Math.abs(this.speed) > 1) {
      this.bouncePhase += dt * Math.abs(this.speed) * 1.4;
    }
    const bounceY = Math.sin(this.bouncePhase) * Math.min(0.02, Math.abs(this.speed) * 0.0006);

    this.chassisNode.position.y = bounceY;
    this.chassisNode.rotation.x = this.pitchAngle;
    this.chassisNode.rotation.z = this.rollAngle;

    // Front wheel steering angle
    this.wheelSteerFL.rotation.y = this.steerAngle;
    this.wheelSteerFR.rotation.y = this.steerAngle;

    // Spin all 4 wheels
    const wheelSpinDelta = (this.speed * dt) / 0.41;
    for (const w of this.wheelSpinMeshes) {
      w.rotation.x += wheelSpinDelta;
    }

    // Animate unoccupied floating marker
    if (!this.isOccupied) {
      const t = performance.now() * 0.003;
      this.markerMesh.rotation.y = t;
      this.markerMesh.position.y = 2.45 + Math.sin(t * 1.5) * 0.15;
    }
  }

  public getSpeedKmh(): number {
    return Math.round(Math.abs(this.speed) * 4.75);
  }

  public getGear(): string {
    if (this.speed < -0.5) return 'R';
    const kmh = this.getSpeedKmh();
    if (kmh < 2) return 'N';
    if (kmh < 28) return '1';
    if (kmh < 58) return '2';
    if (kmh < 92) return '3';
    if (kmh < 128) return '4';
    if (kmh < 165) return '5';
    return '6';
  }

  public getRpm(): number {
    const kmh = this.getSpeedKmh();
    if (kmh < 2) return 850;
    const gearThresholds = [0, 28, 58, 92, 128, 165, 230];
    const gear = Number(this.getGear()) || 1;
    const low = gearThresholds[gear - 1] * 0.65;
    const high = gearThresholds[gear] || 220;
    const ratio = Math.max(0, Math.min(1, (kmh - low) / Math.max(1, high - low)));
    return Math.round(1600 + ratio * 6100);
  }
}
