import {
  Color3,
  DynamicTexture,
  PBRMaterial,
  Scene,
  StandardMaterial,
  Texture,
} from '@babylonjs/core';

export class MaterialLibrary {
  private scene: Scene;
  private cache: Map<string, StandardMaterial | PBRMaterial> = new Map();

  constructor(scene: Scene) {
    this.scene = scene;
  }

  public getRoadMaterial(axis: 'ns' | 'ew'): StandardMaterial {
    const key = `road_${axis}`;
    if (this.cache.has(key)) return this.cache.get(key) as StandardMaterial;

    const tex = new DynamicTexture(`tex_${key}`, { width: 512, height: 512 }, this.scene, true);
    const ctx = tex.getContext();

    // Base dark asphalt
    ctx.fillStyle = '#1c212b';
    ctx.fillRect(0, 0, 512, 512);

    // Subtle asphalt speckle noise
    for (let i = 0; i < 3200; i++) {
      const x = Math.random() * 512;
      const y = Math.random() * 512;
      const v = 24 + Math.floor(Math.random() * 20);
      ctx.fillStyle = `rgb(${v},${v + 3},${v + 8})`;
      ctx.fillRect(x, y, 2, 2);
    }

    if (axis === 'ns') {
      // Shoulder solid white lines
      ctx.fillStyle = 'rgba(226, 232, 240, 0.65)';
      ctx.fillRect(26, 0, 8, 512);
      ctx.fillRect(512 - 34, 0, 8, 512);

      // Double amber center divider
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(250, 0, 5, 512);
      ctx.fillRect(259, 0, 5, 512);

      // Dashed lane dividers
      ctx.fillStyle = 'rgba(241, 245, 249, 0.55)';
      for (let y = 20; y < 512; y += 64) {
        ctx.fillRect(138, y, 5, 34);
        ctx.fillRect(370, y, 5, 34);
      }
    } else {
      ctx.fillStyle = 'rgba(226, 232, 240, 0.65)';
      ctx.fillRect(0, 26, 512, 8);
      ctx.fillRect(0, 512 - 34, 512, 8);

      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(0, 250, 512, 5);
      ctx.fillRect(0, 259, 512, 5);

      ctx.fillStyle = 'rgba(241, 245, 249, 0.55)';
      for (let x = 20; x < 512; x += 64) {
        ctx.fillRect(x, 138, 34, 5);
        ctx.fillRect(x, 370, 34, 5);
      }
    }

    tex.update();
    tex.wrapU = Texture.WRAP_ADDRESSMODE;
    tex.wrapV = Texture.WRAP_ADDRESSMODE;

    const mat = new StandardMaterial(key, this.scene);
    mat.diffuseTexture = tex;
    mat.specularColor = new Color3(0.12, 0.14, 0.18);
    mat.roughness = 0.85;
    this.cache.set(key, mat);
    return mat;
  }

  public getIntersectionMaterial(): StandardMaterial {
    const key = 'road_intersection';
    if (this.cache.has(key)) return this.cache.get(key) as StandardMaterial;

    const tex = new DynamicTexture(`tex_${key}`, { width: 512, height: 512 }, this.scene, true);
    const ctx = tex.getContext();

    ctx.fillStyle = '#1c212b';
    ctx.fillRect(0, 0, 512, 512);

    // Subtle noise
    for (let i = 0; i < 2200; i++) {
      const x = Math.random() * 512;
      const y = Math.random() * 512;
      const v = 25 + Math.floor(Math.random() * 18);
      ctx.fillStyle = `rgb(${v},${v + 3},${v + 7})`;
      ctx.fillRect(x, y, 2, 2);
    }

    // Crosswalk zebra stripes on all 4 sides
    ctx.fillStyle = 'rgba(241, 245, 249, 0.72)';
    for (let i = 56; i < 456; i += 36) {
      // North & South crosswalks
      ctx.fillRect(i, 14, 20, 42);
      ctx.fillRect(i, 512 - 56, 20, 42);
      // West & East crosswalks
      ctx.fillRect(14, i, 42, 20);
      ctx.fillRect(512 - 56, i, 42, 20);
    }

    tex.update();
    const mat = new StandardMaterial(key, this.scene);
    mat.diffuseTexture = tex;
    mat.specularColor = new Color3(0.14, 0.15, 0.18);
    this.cache.set(key, mat);
    return mat;
  }

  public getSidewalkMaterial(): StandardMaterial {
    const key = 'sidewalk_paver';
    if (this.cache.has(key)) return this.cache.get(key) as StandardMaterial;

    const tex = new DynamicTexture(`tex_${key}`, { width: 256, height: 256 }, this.scene, true);
    const ctx = tex.getContext();

    ctx.fillStyle = '#475569';
    ctx.fillRect(0, 0, 256, 256);

    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 3;
    for (let i = 0; i <= 256; i += 64) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 256);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(256, i);
      ctx.stroke();
    }

    tex.update();
    tex.wrapU = Texture.WRAP_ADDRESSMODE;
    tex.wrapV = Texture.WRAP_ADDRESSMODE;
    tex.uScale = 4;
    tex.vScale = 4;

    const mat = new StandardMaterial(key, this.scene);
    mat.diffuseTexture = tex;
    mat.specularColor = new Color3(0.08, 0.08, 0.1);
    this.cache.set(key, mat);
    return mat;
  }

  public getPlazaMaterial(): StandardMaterial {
    const key = 'plaza_tiles';
    if (this.cache.has(key)) return this.cache.get(key) as StandardMaterial;

    const tex = new DynamicTexture(`tex_${key}`, { width: 256, height: 256 }, this.scene, true);
    const ctx = tex.getContext();

    ctx.fillStyle = '#334155';
    ctx.fillRect(0, 0, 256, 256);

    ctx.fillStyle = '#3b4a61';
    ctx.fillRect(8, 8, 112, 112);
    ctx.fillRect(136, 136, 112, 112);

    ctx.strokeStyle = '#0ea5e9';
    ctx.lineWidth = 2;
    ctx.strokeRect(4, 4, 248, 248);

    tex.update();
    tex.wrapU = Texture.WRAP_ADDRESSMODE;
    tex.wrapV = Texture.WRAP_ADDRESSMODE;
    tex.uScale = 6;
    tex.vScale = 6;

    const mat = new StandardMaterial(key, this.scene);
    mat.diffuseTexture = tex;
    mat.specularColor = new Color3(0.2, 0.25, 0.3);
    this.cache.set(key, mat);
    return mat;
  }

  public getGrassMaterial(): StandardMaterial {
    const key = 'park_grass';
    if (this.cache.has(key)) return this.cache.get(key) as StandardMaterial;

    const tex = new DynamicTexture(`tex_${key}`, { width: 256, height: 256 }, this.scene, true);
    const ctx = tex.getContext();
    ctx.fillStyle = '#1b4d3e';
    ctx.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 1800; i++) {
      const x = Math.random() * 256;
      const y = Math.random() * 256;
      ctx.fillStyle = Math.random() > 0.5 ? '#225e4b' : '#153e31';
      ctx.fillRect(x, y, 3, 3);
    }
    tex.update();
    tex.wrapU = Texture.WRAP_ADDRESSMODE;
    tex.wrapV = Texture.WRAP_ADDRESSMODE;
    tex.uScale = 8;
    tex.vScale = 8;

    const mat = new StandardMaterial(key, this.scene);
    mat.diffuseTexture = tex;
    mat.specularColor = new Color3(0.04, 0.06, 0.04);
    this.cache.set(key, mat);
    return mat;
  }

  public getBuildingFacadeMaterial(styleIndex: number): StandardMaterial {
    const idx = ((styleIndex % 5) + 5) % 5;
    const key = `building_facade_${idx}`;
    if (this.cache.has(key)) return this.cache.get(key) as StandardMaterial;

    const tex = new DynamicTexture(`tex_${key}`, { width: 512, height: 512 }, this.scene, true);
    const ctx = tex.getContext();

    const palettes = [
      { wall: '#131c2e', frame: '#1e293b', winOff: '#0f172a', winLit1: '#38bdf8', winLit2: '#bae6fd' },
      { wall: '#27272a', frame: '#3f3f46', winOff: '#18181b', winLit1: '#fbbf24', winLit2: '#fef08a' },
      { wall: '#1e293b', frame: '#334155', winOff: '#0f172a', winLit1: '#2dd4bf', winLit2: '#99f6e4' },
      { wall: '#312528', frame: '#4a373b', winOff: '#1c1517', winLit1: '#fb923c', winLit2: '#fed7aa' },
      { wall: '#171f32', frame: '#25324d', winOff: '#0b101d', winLit1: '#818cf8', winLit2: '#e0e7ff' },
    ];
    const pal = palettes[idx];

    ctx.fillStyle = pal.wall;
    ctx.fillRect(0, 0, 512, 512);

    // Draw floors and architectural window grid
    const cols = 8;
    const rows = 12;
    const cellW = 512 / cols;
    const cellH = 512 / rows;

    // Seeded deterministic pseudo-random so each style looks consistent
    let seed = (idx + 1) * 9301;
    const rand = () => {
      seed = (seed * 49297 + 233280) % 233280;
      return seed / 233280;
    };

    for (let r = 0; r < rows; r++) {
      // Horizontal spandrel band
      ctx.fillStyle = pal.frame;
      ctx.fillRect(0, r * cellH, 512, 6);

      for (let c = 0; c < cols; c++) {
        const wx = c * cellW + 7;
        const wy = r * cellH + 9;
        const ww = cellW - 14;
        const wh = cellH - 15;

        const p = rand();
        if (p > 0.62) {
          ctx.fillStyle = p > 0.84 ? pal.winLit2 : pal.winLit1;
        } else {
          ctx.fillStyle = pal.winOff;
        }
        ctx.fillRect(wx, wy, ww, wh);
      }
    }

    tex.update();
    tex.wrapU = Texture.WRAP_ADDRESSMODE;
    tex.wrapV = Texture.WRAP_ADDRESSMODE;

    const mat = new StandardMaterial(key, this.scene);
    mat.diffuseTexture = tex;
    mat.emissiveTexture = tex;
    mat.emissiveColor = new Color3(0.32, 0.32, 0.35);
    mat.specularColor = new Color3(0.3, 0.35, 0.42);
    mat.specularPower = 48;
    this.cache.set(key, mat);
    return mat;
  }

  public getSolidPBR(
    name: string,
    hexColor: string,
    metallic = 0.2,
    roughness = 0.5,
    emissiveHex?: string
  ): PBRMaterial {
    const key = `pbr_${name}_${hexColor}_${metallic}_${roughness}_${emissiveHex || ''}`;
    if (this.cache.has(key)) return this.cache.get(key) as PBRMaterial;

    const mat = new PBRMaterial(key, this.scene);
    mat.albedoColor = Color3.FromHexString(hexColor);
    mat.metallic = metallic;
    mat.roughness = roughness;
    if (emissiveHex) {
      mat.emissiveColor = Color3.FromHexString(emissiveHex);
    }
    this.cache.set(key, mat);
    return mat;
  }

  public getEmissiveMaterial(name: string, hexColor: string, intensity = 1.0): StandardMaterial {
    const key = `emissive_${name}_${hexColor}_${intensity}`;
    if (this.cache.has(key)) return this.cache.get(key) as StandardMaterial;

    const mat = new StandardMaterial(key, this.scene);
    const c = Color3.FromHexString(hexColor);
    mat.diffuseColor = c;
    mat.emissiveColor = c.scale(intensity);
    mat.specularColor = Color3.Black();
    this.cache.set(key, mat);
    return mat;
  }

  public getWaterMaterial(): StandardMaterial {
    const key = 'water_marina';
    if (this.cache.has(key)) return this.cache.get(key) as StandardMaterial;

    const mat = new StandardMaterial(key, this.scene);
    mat.diffuseColor = new Color3(0.04, 0.18, 0.32);
    mat.specularColor = new Color3(0.6, 0.75, 0.9);
    mat.specularPower = 64;
    mat.emissiveColor = new Color3(0.02, 0.08, 0.16);
    this.cache.set(key, mat);
    return mat;
  }
}
