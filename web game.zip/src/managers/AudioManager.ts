import { GameSettings } from '../types/game';

export class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;

  // Continuous engine nodes
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;

  // Ambient city drone
  private ambientOsc1: OscillatorNode | null = null;
  private ambientOsc2: OscillatorNode | null = null;
  private ambientGain: GainNode | null = null;

  private isInitialized = false;
  private isPaused = false;
  private footstepTimer = 0;

  private masterVol = 0.75;
  private musicVol = 0.5;
  private sfxVol = 0.8;

  public applySettings(settings: GameSettings): void {
    this.masterVol = settings.masterVolume;
    this.musicVol = settings.musicVolume;
    this.sfxVol = settings.sfxVolume;
    this.syncGains();
  }

  public unlockAudio(): void {
    if (!this.isInitialized) {
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AudioCtx) return;
        this.ctx = new AudioCtx();

        this.masterGain = this.ctx.createGain();
        this.musicGain = this.ctx.createGain();
        this.sfxGain = this.ctx.createGain();

        this.musicGain.connect(this.masterGain);
        this.sfxGain.connect(this.masterGain);
        this.masterGain.connect(this.ctx.destination);

        this.setupEngineSound();
        this.setupAmbientSound();
        this.isInitialized = true;
        this.syncGains();
      } catch {
        // Ignore if audio context disallowed
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private syncGains(): void {
    if (!this.ctx || !this.masterGain || !this.musicGain || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    const effectiveMaster = this.isPaused ? 0 : this.masterVol;
    this.masterGain.gain.setTargetAtTime(effectiveMaster, now, 0.04);
    this.musicGain.gain.setTargetAtTime(this.musicVol, now, 0.04);
    this.sfxGain.gain.setTargetAtTime(this.sfxVol, now, 0.04);
  }

  public setPaused(paused: boolean): void {
    this.isPaused = paused;
    this.syncGains();
  }

  private setupEngineSound(): void {
    if (!this.ctx || !this.sfxGain) return;

    this.engineOsc1 = this.ctx.createOscillator();
    this.engineOsc2 = this.ctx.createOscillator();
    this.engineFilter = this.ctx.createBiquadFilter();
    this.engineGain = this.ctx.createGain();

    this.engineOsc1.type = 'sawtooth';
    this.engineOsc2.type = 'triangle';
    this.engineOsc1.frequency.value = 55;
    this.engineOsc2.frequency.value = 110;

    this.engineFilter.type = 'lowpass';
    this.engineFilter.frequency.value = 240;
    this.engineFilter.Q.value = 3.0;

    this.engineGain.gain.value = 0.0;

    this.engineOsc1.connect(this.engineFilter);
    this.engineOsc2.connect(this.engineFilter);
    this.engineFilter.connect(this.engineGain);
    this.engineGain.connect(this.sfxGain);

    this.engineOsc1.start();
    this.engineOsc2.start();
  }

  private setupAmbientSound(): void {
    if (!this.ctx || !this.musicGain) return;

    this.ambientOsc1 = this.ctx.createOscillator();
    this.ambientOsc2 = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    this.ambientGain = this.ctx.createGain();

    this.ambientOsc1.type = 'sine';
    this.ambientOsc2.type = 'triangle';
    this.ambientOsc1.frequency.value = 110; // A2 warm pad
    this.ambientOsc2.frequency.value = 164.81; // E3 fifth

    filter.type = 'lowpass';
    filter.frequency.value = 320;

    this.ambientGain.gain.value = 0.06;

    this.ambientOsc1.connect(filter);
    this.ambientOsc2.connect(filter);
    filter.connect(this.ambientGain);
    this.ambientGain.connect(this.musicGain);

    this.ambientOsc1.start();
    this.ambientOsc2.start();
  }

  public updateVehicleAudio(isDriving: boolean, rpm: number, throttle: number, isBrakingOrDrifting: boolean): void {
    if (!this.ctx || !this.engineOsc1 || !this.engineOsc2 || !this.engineFilter || !this.engineGain) return;

    const now = this.ctx.currentTime;
    if (!isDriving || this.isPaused) {
      this.engineGain.gain.setTargetAtTime(0, now, 0.08);
      return;
    }

    const normRpm = Math.max(0, Math.min(1, (rpm - 800) / 7200));
    const baseFreq = 46 + normRpm * 145;
    this.engineOsc1.frequency.setTargetAtTime(baseFreq, now, 0.03);
    this.engineOsc2.frequency.setTargetAtTime(baseFreq * 1.5, now, 0.03);

    const filterFreq = 180 + normRpm * 900 + Math.abs(throttle) * 280;
    this.engineFilter.frequency.setTargetAtTime(filterFreq, now, 0.04);

    const targetGain = 0.07 + normRpm * 0.09 + Math.abs(throttle) * 0.04;
    this.engineGain.gain.setTargetAtTime(targetGain, now, 0.05);

    if (isBrakingOrDrifting && Math.random() < 0.15) {
      this.playTireScreechTick();
    }
  }

  private playTireScreechTick(): void {
    if (!this.ctx || !this.sfxGain || this.isPaused) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(680 + Math.random() * 180, now);
    gain.gain.setValueAtTime(0.025, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.07);
  }

  public updateFootsteps(dt: number, isMovingOnFoot: boolean, isSprinting: boolean, isGrounded: boolean): void {
    if (!isMovingOnFoot || !isGrounded || this.isPaused) {
      this.footstepTimer = 0;
      return;
    }
    const interval = isSprinting ? 0.28 : 0.44;
    this.footstepTimer += dt;
    if (this.footstepTimer >= interval) {
      this.footstepTimer = 0;
      this.playFootstep(isSprinting);
    }
  }

  public playFootstep(heavy = false): void {
    if (!this.ctx || !this.sfxGain || this.isPaused) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    const startFreq = heavy ? 135 : 110;
    osc.frequency.setValueAtTime(startFreq + Math.random() * 20, now);
    osc.frequency.exponentialRampToValueAtTime(42, now + 0.065);

    filter.type = 'lowpass';
    filter.frequency.value = 340;

    gain.gain.setValueAtTime(heavy ? 0.12 : 0.075, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.075);
  }

  public playJump(): void {
    if (!this.ctx || !this.sfxGain || this.isPaused) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(290, now + 0.12);
    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.13);
  }

  public playVehicleDoor(entering: boolean): void {
    if (!this.ctx || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(entering ? 220 : 320, now);
    osc.frequency.exponentialRampToValueAtTime(entering ? 360 : 180, now + 0.14);
    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.16);
  }

  public playCollisionBump(intensity = 0.5): void {
    if (!this.ctx || !this.sfxGain || this.isPaused) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(95, now);
    osc.frequency.exponentialRampToValueAtTime(32, now + 0.14);
    const vol = Math.min(0.25, Math.max(0.04, intensity * 0.2));
    gain.gain.setValueAtTime(vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.16);
  }

  public playUiClick(): void {
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(620, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.05);
    gain.gain.setValueAtTime(0.09, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.055);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.06);
  }

  public playCheckpoint(): void {
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;
    const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const now = this.ctx.currentTime + idx * 0.07;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(0.14, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.24);
    });
  }

  public playMissionComplete(): void {
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;
    const notes = [440, 554.37, 659.25, 880]; // A4 major triad up to A5
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const now = this.ctx.currentTime + idx * 0.09;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.46);
    });
  }

  public dispose(): void {
    try {
      this.engineOsc1?.stop();
      this.engineOsc2?.stop();
      this.ambientOsc1?.stop();
      this.ambientOsc2?.stop();
      this.ctx?.close();
    } catch {
      // ignore
    }
    this.ctx = null;
    this.isInitialized = false;
  }
}

export const audioManager = new AudioManager();
