import { GameSettings, SaveData } from '../types/game';
import { MISSIONS, VEHICLE_CATALOG } from '../game/data/worldCatalog';

const SAVE_STORAGE_KEY = 'project_horizon_save_v1';
const CURRENT_SAVE_VERSION = 1;

export const DEFAULT_SETTINGS: GameSettings = {
  mouseSensitivity: 1.0,
  masterVolume: 0.75,
  musicVolume: 0.5,
  sfxVolume: 0.8,
  graphicsQuality: 'high',
  shadowsEnabled: true,
  worldActivity: 'high',
  timeOfDay: 'sunset',
  showFps: true,
  touchControls: false,
};

export function createDefaultSaveData(): SaveData {
  return {
    version: CURRENT_SAVE_VERSION,
    hasSavedGame: false,
    credits: 250,
    xp: 0,
    level: 1,
    completedMissionIds: [],
    activeMissionId: MISSIONS[0].id,
    collectedShardIds: [],
    selectedVehicleId: VEHICLE_CATALOG[0].id,
    totalDistanceM: 0,
    settings: { ...DEFAULT_SETTINGS },
    lastSavedAt: new Date().toISOString(),
  };
}

export class SaveManager {
  private data: SaveData;
  private listeners: Set<(data: SaveData) => void> = new Set();

  constructor() {
    this.data = this.load();
  }

  public load(): SaveData {
    try {
      const raw = window.localStorage.getItem(SAVE_STORAGE_KEY);
      if (!raw) {
        return createDefaultSaveData();
      }
      const parsed = JSON.parse(raw) as Partial<SaveData>;
      if (!parsed || typeof parsed !== 'object' || parsed.version !== CURRENT_SAVE_VERSION) {
        return createDefaultSaveData();
      }

      const defaults = createDefaultSaveData();
      const mergedSettings: GameSettings = {
        ...DEFAULT_SETTINGS,
        ...(parsed.settings && typeof parsed.settings === 'object' ? parsed.settings : {}),
      };

      const validMissionIds = new Set(MISSIONS.map((m) => m.id));
      const activeMissionId =
        typeof parsed.activeMissionId === 'string' && validMissionIds.has(parsed.activeMissionId)
          ? parsed.activeMissionId
          : defaults.activeMissionId;

      const completedMissionIds = Array.isArray(parsed.completedMissionIds)
        ? parsed.completedMissionIds.filter((id): id is string => typeof id === 'string' && validMissionIds.has(id))
        : [];

      const collectedShardIds = Array.isArray(parsed.collectedShardIds)
        ? parsed.collectedShardIds.filter((id): id is string => typeof id === 'string')
        : [];

      const credits = typeof parsed.credits === 'number' && Number.isFinite(parsed.credits) ? Math.max(0, parsed.credits) : defaults.credits;
      const xp = typeof parsed.xp === 'number' && Number.isFinite(parsed.xp) ? Math.max(0, parsed.xp) : defaults.xp;
      const level = Math.floor(xp / 500) + 1;

      return {
        version: CURRENT_SAVE_VERSION,
        hasSavedGame: Boolean(parsed.hasSavedGame),
        credits,
        xp,
        level,
        completedMissionIds,
        activeMissionId,
        collectedShardIds,
        selectedVehicleId:
          typeof parsed.selectedVehicleId === 'string' ? parsed.selectedVehicleId : defaults.selectedVehicleId,
        totalDistanceM:
          typeof parsed.totalDistanceM === 'number' && Number.isFinite(parsed.totalDistanceM)
            ? parsed.totalDistanceM
            : 0,
        settings: mergedSettings,
        lastSavedAt: typeof parsed.lastSavedAt === 'string' ? parsed.lastSavedAt : new Date().toISOString(),
      };
    } catch {
      return createDefaultSaveData();
    }
  }

  public save(): void {
    try {
      this.data.lastSavedAt = new Date().toISOString();
      window.localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(this.data));
      this.notify();
    } catch {
      // Ignore storage quota errors in restricted environments
    }
  }

  public getData(): SaveData {
    return this.data;
  }

  public markGameStarted(): void {
    this.data.hasSavedGame = true;
    this.save();
  }

  public updateSettings(partial: Partial<GameSettings>): GameSettings {
    this.data.settings = {
      ...this.data.settings,
      ...partial,
    };
    this.save();
    return this.data.settings;
  }

  public addRewards(credits: number, xp: number): void {
    this.data.credits = Math.max(0, this.data.credits + credits);
    this.data.xp = Math.max(0, this.data.xp + xp);
    this.data.level = Math.floor(this.data.xp / 500) + 1;
    this.data.hasSavedGame = true;
    this.save();
  }

  public completeMission(missionId: string, rewardCredits: number, rewardXp: number): string {
    if (!this.data.completedMissionIds.includes(missionId)) {
      this.data.completedMissionIds.push(missionId);
    }
    this.data.credits += rewardCredits;
    this.data.xp += rewardXp;
    this.data.level = Math.floor(this.data.xp / 500) + 1;
    this.data.hasSavedGame = true;

    // Advance to next uncompleted mission, or next mission in sequence
    const idx = MISSIONS.findIndex((m) => m.id === missionId);
    const nextMission = MISSIONS[(idx + 1) % MISSIONS.length];
    if (nextMission) {
      this.data.activeMissionId = nextMission.id;
    }
    this.save();
    return this.data.activeMissionId;
  }

  public setActiveMission(missionId: string): void {
    if (MISSIONS.some((m) => m.id === missionId)) {
      this.data.activeMissionId = missionId;
      this.data.hasSavedGame = true;
      this.save();
    }
  }

  public setSelectedVehicle(vehicleId: string): void {
    this.data.selectedVehicleId = vehicleId;
    this.data.hasSavedGame = true;
    this.save();
  }

  public collectShard(shardId: string, rewardCredits = 150, rewardXp = 100): boolean {
    if (this.data.collectedShardIds.includes(shardId)) {
      return false;
    }
    this.data.collectedShardIds.push(shardId);
    this.data.credits += rewardCredits;
    this.data.xp += rewardXp;
    this.data.level = Math.floor(this.data.xp / 500) + 1;
    this.data.hasSavedGame = true;
    this.save();
    return true;
  }

  public resetProgress(): SaveData {
    const currentSettings = { ...this.data.settings };
    this.data = createDefaultSaveData();
    this.data.settings = currentSettings;
    this.save();
    return this.data;
  }

  public subscribe(listener: (data: SaveData) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    for (const listener of this.listeners) {
      listener(this.data);
    }
  }
}

export const saveManager = new SaveManager();
