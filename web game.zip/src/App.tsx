import React, { useEffect, useRef, useState } from 'react';
import { HorizonEngine } from './game/HorizonEngine';
import { saveManager } from './managers/SaveManager';
import {
  GameSettings,
  HUDTelemetry,
  MinimapBuilding,
  NotificationBanner,
  SaveData,
} from './types/game';
import { MISSIONS, PLAYER_SPAWN_POS } from './game/data/worldCatalog';
import { MainMenu } from './components/MainMenu';
import { HUD } from './components/HUD';
import {
  AboutModal,
  ControlsModal,
  MissionAndGarageModal,
  PauseModal,
  ResetConfirmModal,
  SettingsModal,
} from './components/Modals';

const INITIAL_TELEMETRY: HUDTelemetry = {
  playerPos: { ...PLAYER_SPAWN_POS },
  playerHeading: 0,
  cameraYaw: 0,
  isDriving: false,
  isSprinting: false,
  stamina: 100,
  currentVehicleName: '',
  currentVehicleCategory: '',
  speedKmh: 0,
  rpm: 800,
  gear: 'N',
  nitro: 100,
  isDrifting: false,
  interactionPrompt: null,
  districtName: 'New Horizon Downtown Core',
  activeMission: MISSIONS[0],
  activeStageIndex: 0,
  distanceToTarget: 66,
  missionTimerRemaining: null,
  targetPos: MISSIONS[0].stages[0].targetPos,
  fps: 60,
  parkedVehicles: [],
  trafficVehicles: [],
  shards: [],
};

export const App: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<HorizonEngine | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [initError, setInitError] = useState<string | null>(null);
  const [screenMode, setScreenMode] = useState<'menu' | 'playing' | 'paused'>('menu');
  const [activeModal, setActiveModal] = useState<
    null | 'settings' | 'controls' | 'missions' | 'about' | 'resetConfirm'
  >(null);

  const [saveData, setSaveData] = useState<SaveData>(() => saveManager.getData());
  const [telemetry, setTelemetry] = useState<HUDTelemetry>(INITIAL_TELEMETRY);
  const [buildings, setBuildings] = useState<MinimapBuilding[]>([]);
  const [notification, setNotification] = useState<NotificationBanner | null>(null);

  useEffect(() => {
    const unsub = saveManager.subscribe((updated) => {
      setSaveData({ ...updated });
    });
    return unsub;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let notifTimeout: number | undefined;

    try {
      const game = new HorizonEngine(canvas, {
        onTelemetry: (t) => setTelemetry(t),
        onNotification: (banner) => {
          setNotification(banner);
          if (notifTimeout) window.clearTimeout(notifTimeout);
          notifTimeout = window.setTimeout(() => {
            setNotification(null);
          }, 4500);
        },
        onPauseToggle: (paused) => {
          setScreenMode(paused ? 'paused' : 'playing');
        },
        onHelpToggle: () => {
          setActiveModal((prev) => (prev === 'controls' ? null : 'controls'));
        },
      });

      engineRef.current = game;
      (window as unknown as { __HORIZON_ENGINE__?: HorizonEngine }).__HORIZON_ENGINE__ = game;
      setBuildings(game.getMinimapBuildings());
      setIsLoading(false);
    } catch (err) {
      setInitError(err instanceof Error ? err.message : 'Failed to initialize 3D WebGL context.');
      setIsLoading(false);
    }

    return () => {
      if (notifTimeout) window.clearTimeout(notifTimeout);
      engineRef.current?.dispose();
      engineRef.current = null;
    };
  }, []);

  const handleStartGame = (spawnInVehicle = false) => {
    if (!engineRef.current) return;
    engineRef.current.startGame(spawnInVehicle);
    setScreenMode('playing');
    setActiveModal(null);
  };

  const handleResume = () => {
    if (!engineRef.current) return;
    engineRef.current.setPaused(false);
    setScreenMode('playing');
    setActiveModal(null);
  };

  const handleUpdateSettings = (partial: Partial<GameSettings>) => {
    const updated = saveManager.updateSettings(partial);
    engineRef.current?.applySettings(updated);
  };

  const handleConfirmReset = () => {
    const resetData = saveManager.resetProgress();
    setSaveData({ ...resetData });
    engineRef.current?.handleFullReset();
    setActiveModal(null);
    setNotification({
      id: `reset_done_${Date.now()}`,
      title: 'PROGRESS RESET COMPLETE',
      subtitle: 'Returned to Level 1 and Mission 01.',
      type: 'info',
      timestamp: Date.now(),
    });
  };

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#070a12] select-none">
      {/* 3D WebGL Canvas */}
      <canvas
        ref={canvasRef}
        className="w-full h-full block outline-none cursor-crosshair"
      />

      {/* Loading Indicator */}
      {isLoading && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-white">
          <div className="w-12 h-12 rounded-full border-4 border-cyan-500/30 border-t-cyan-400 animate-spin mb-4" />
          <div className="text-lg font-black tracking-widest uppercase text-cyan-400">
            Initializing Project Horizon
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Building New Horizon District, PBR shaders, and vehicle physics...
          </div>
        </div>
      )}

      {/* Graceful WebGL Error Fallback */}
      {initError && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 p-6 text-center">
          <div className="max-w-md bg-slate-900 border border-rose-500/40 rounded-2xl p-6">
            <h2 className="text-lg font-bold text-rose-400 mb-2">3D Graphics Context Error</h2>
            <p className="text-xs text-slate-300">{initError}</p>
          </div>
        </div>
      )}

      {/* Main Menu Overlay */}
      {!isLoading && !initError && screenMode === 'menu' && (
        <MainMenu
          saveData={saveData}
          onStartGame={handleStartGame}
          onOpenSettings={() => setActiveModal('settings')}
          onOpenControls={() => setActiveModal('controls')}
          onOpenAbout={() => setActiveModal('about')}
          onOpenResetConfirm={() => setActiveModal('resetConfirm')}
          onSelectVehicle={(vId) => saveManager.setSelectedVehicle(vId)}
        />
      )}

      {/* Gameplay HUD */}
      {!isLoading && !initError && (screenMode === 'playing' || screenMode === 'paused') && (
        <HUD
          telemetry={telemetry}
          saveData={saveData}
          buildings={buildings}
          notification={notification}
          onPause={() => engineRef.current?.setPaused(true)}
          onOpenHelp={() => setActiveModal('controls')}
          onOpenMissionsAndGarage={() => setActiveModal('missions')}
          onRestartMission={() => engineRef.current?.restartCurrentMission()}
          onInteract={() => engineRef.current?.triggerInteractAction()}
          onResetEntity={() => engineRef.current?.triggerResetAction()}
          onCycleTimeOfDay={(tod) => handleUpdateSettings({ timeOfDay: tod })}
          onTouchInputChange={(partial) => engineRef.current?.setTouchInput(partial)}
        />
      )}

      {/* Pause Menu Modal */}
      {screenMode === 'paused' && activeModal === null && (
        <PauseModal
          saveData={saveData}
          onResume={handleResume}
          onRestartMission={() => engineRef.current?.restartCurrentMission()}
          onOpenMissions={() => setActiveModal('missions')}
          onOpenSettings={() => setActiveModal('settings')}
          onOpenControls={() => setActiveModal('controls')}
          onOpenResetConfirm={() => setActiveModal('resetConfirm')}
          onReturnMainMenu={() => {
            engineRef.current?.returnToMainMenu();
            setScreenMode('menu');
          }}
        />
      )}

      {/* Sub-Modals */}
      {activeModal === 'settings' && (
        <SettingsModal
          settings={saveData.settings}
          onUpdateSettings={handleUpdateSettings}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'controls' && (
        <ControlsModal onClose={() => setActiveModal(null)} />
      )}

      {activeModal === 'missions' && (
        <MissionAndGarageModal
          saveData={saveData}
          onSelectMission={(mId) => {
            engineRef.current?.selectMission(mId);
            if (screenMode === 'paused') handleResume();
          }}
          onSummonVehicle={(vId) => {
            engineRef.current?.spawnOrSummonVehicle(vId);
            if (screenMode === 'paused') handleResume();
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'about' && (
        <AboutModal onClose={() => setActiveModal(null)} />
      )}

      {activeModal === 'resetConfirm' && (
        <ResetConfirmModal
          onConfirmReset={handleConfirmReset}
          onCancel={() => setActiveModal(null)}
        />
      )}
    </div>
  );
};

export default App;
