export type GraphicsQuality = 'low' | 'medium' | 'high';
export type WorldActivityLevel = 'off' | 'low' | 'high';
export type TimeOfDayPreset = 'day' | 'sunset' | 'night';

export interface GameSettings {
  mouseSensitivity: number; // 0.2 to 2.5
  masterVolume: number; // 0 to 1
  musicVolume: number; // 0 to 1
  sfxVolume: number; // 0 to 1
  graphicsQuality: GraphicsQuality;
  shadowsEnabled: boolean;
  worldActivity: WorldActivityLevel;
  timeOfDay: TimeOfDayPreset;
  showFps: boolean;
  touchControls: boolean;
}

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface VehicleSpec {
  id: string;
  name: string;
  category: 'Sports Coupe' | 'Street Sedan' | 'Tactical SUV' | 'Hyper Intercept';
  topSpeed: number; // internal units/s (~38 = 180 km/h)
  acceleration: number;
  handling: number;
  braking: number;
  primaryColor: string;
  secondaryColor: string;
  neonColor: string;
  description: string;
  spawnPos: Vec3;
  spawnRotY: number;
}

export interface MissionStage {
  id: string;
  title: string;
  instruction: string;
  targetPos: Vec3;
  radius: number;
  timeLimitSeconds?: number;
}

export interface MissionDefinition {
  id: string;
  code: string;
  title: string;
  category: 'Story Objective' | 'Express Delivery' | 'Time Trial' | 'Reconnaissance';
  description: string;
  rewardCredits: number;
  rewardXp: number;
  recommendedMode: 'any' | 'vehicle' | 'foot';
  stages: MissionStage[];
}

export interface SaveData {
  version: number;
  hasSavedGame: boolean;
  credits: number;
  xp: number;
  level: number;
  completedMissionIds: string[];
  activeMissionId: string;
  collectedShardIds: string[];
  selectedVehicleId: string;
  totalDistanceM: number;
  settings: GameSettings;
  lastSavedAt: string;
}

export interface MinimapBuilding {
  x: number;
  z: number;
  w: number;
  d: number;
  color?: string;
}

export interface MinimapVehicle {
  id: string;
  name: string;
  x: number;
  z: number;
  rotY: number;
  isTraffic?: boolean;
}

export interface MinimapShard {
  id: string;
  x: number;
  z: number;
  collected: boolean;
}

export interface NotificationBanner {
  id: string;
  title: string;
  subtitle: string;
  rewardText?: string;
  type: 'mission_complete' | 'checkpoint' | 'shard' | 'info';
  timestamp: number;
}

export interface HUDTelemetry {
  playerPos: Vec3;
  playerHeading: number;
  cameraYaw: number;
  isDriving: boolean;
  isSprinting: boolean;
  stamina: number; // 0..100
  currentVehicleName: string;
  currentVehicleCategory: string;
  speedKmh: number;
  rpm: number; // 800..8000
  gear: string; // 'R' | 'N' | '1'..'6'
  nitro: number; // 0..100
  isDrifting: boolean;
  interactionPrompt: string | null;
  districtName: string;
  activeMission: MissionDefinition | null;
  activeStageIndex: number;
  distanceToTarget: number;
  missionTimerRemaining: number | null;
  targetPos: Vec3 | null;
  fps: number;
  parkedVehicles: MinimapVehicle[];
  trafficVehicles: MinimapVehicle[];
  shards: MinimapShard[];
}
