# PROJECT HORIZON — 3D Open-World Action & Driving Browser Game

**Project Horizon** is a complete, single-player 3D open-world exploration and driving game built for modern browsers using **Babylon.js**, **TypeScript**, **React 18**, **Tailwind CSS**, and **Vite**.

---

## 1. Core Features & Systems

- **Explorable 3D City District (*New Horizon District*)**:
  - Connected street grid (`Central Avenue`, `Horizon Grand Boulevard`, `North Skyline Boulevard`, `Marina Promenade`, `Westside Auto & Tech District`).
  - Varied skyscraper architecture with procedural lit facades, lobby podiums, rooftop neon crowns, and spires.
  - Landmarks: **Horizon Spire & Central Plaza**, **Westside Horizon Garage**, **Emerald Commons Park** (with reflective pond and trees), and the **South Marina Waterfront**.
- **Third-Person Character Controller**:
  - Articulated 3D humanoid character with procedural skeletal animation blending (Idle breathing, Walk cycle, Sprint lean & fast stride, Jump/Airborne pose).
  - Smooth acceleration/deceleration, sprinting with recharging stamina (`Shift`), jumping (`Space`) with gravity and ground elevation detection, and smooth wall-sliding collision resolution against buildings.
- **Driveable Vehicle System**:
  - 4 distinct driveable vehicles parked across the district (or deployable anytime via the **Horizon Garage** menu):
    1. **Horizon GT-R Apex** (*Sports Coupe* — parked right beside player spawn)
    2. **Solaris V8 Interceptor** (*Hyper Intercept* — parked at the Westside Horizon Garage bay)
    3. **Vanguard Executive S** (*Street Sedan*)
    4. **Atlas 4x4 Defender** (*Tactical SUV*)
  - Arcade-physics driving dynamics: throttle, braking, reverse, speed-sensitive steering, front-wheel visual steering & 4-wheel spin, chassis suspension pitch & roll, handbrake drifting (`Space`), Nitro Boost (`Shift`), building/vehicle collision response, and upright road reset (`R`).
- **Mission & Progression System**:
  - **Mission 01: Reach the Destination** — Walk or drive north up Central Avenue to the Horizon Tower Plaza checkpoint beacon.
  - **Mission 02: Downtown Express Delivery** — Multi-stage pickup at Westside Horizon Garage and delivery to East Harbor Terminal.
  - **Mission 03: Sunset Boulevard Circuit** — High-speed 4-gate countdown Time Trial around the downtown perimeter.
  - **Mission 04: Skyline & Park Reconnaissance** — Multi-landmark survey across Emerald Commons Park, North Apex Overlook, and South Marina Promenade.
  - **8 Collectible Horizon Data Shards** scattered at key district landmarks for bonus Credits (`₡`) and XP.
- **Lightweight AI World Activity**:
  - Road-following AI traffic vehicles with lane navigation and obstacle braking.
  - Sidewalk-walking AI pedestrians with limb animation and proximity reaction.
  - Configurable simulation density (`High / Low / Off`) in Settings for lower-performance devices.
- **Procedural Web Audio Synthesizer**:
  - Zero external audio asset dependencies; browser autoplay-compliant Web Audio API synthesis for footsteps, dynamic RPM vehicle engine hum, tire drift screech, ambient city pad, UI clicks, and mission/checkpoint fanfares.
- **Persistent Versioned Save System**:
  - Automatically saves completed missions, active objective, Credits, XP, Level, collected Data Shards, selected vehicle, and user settings to `localStorage` (`project_horizon_save_v1`).

---

## 2. Controls Reference

| Action | On-Foot Key / Input | In-Vehicle Key / Input |
| :--- | :--- | :--- |
| **Move / Drive** | `W / A / S / D` or `Arrow Keys` | `W / S` (Throttle/Brake) • `A / D` (Steer) |
| **Sprint / Nitro Boost** | `Left Shift` (Hold) | `Left Shift` (Hold for Nitro) |
| **Jump / Handbrake Drift** | `Spacebar` | `Spacebar` (Hold for Drift) |
| **Enter / Exit Vehicle** | `E` or `F` (near vehicle) | `E` or `F` |
| **Reset Position / Upright** | `R` (return to Spawn Plaza) | `R` (snap upright to nearest road) |
| **Rotate Camera** | Mouse Drag / Pointer Lock / `Q & C` | Auto-Follow + Mouse Drag / `Q & C` |
| **Zoom Camera** | Mouse Scroll Wheel | Mouse Scroll Wheel |
| **Pause Menu** | `ESC` or `P` | `ESC` or `P` |
| **Controls Help Overlay** | `H` | `H` |

---

## 3. Project Structure

```text
/
├── index.html
├── package.json
├── vite.config.ts
└── src/
    ├── main.tsx
    ├── App.tsx
    ├── index.css
    ├── types/
    │   └── game.ts                  # Core TypeScript interfaces (SaveData, Telemetry, Missions, Vehicles)
    ├── managers/
    │   ├── SaveManager.ts           # Versioned localStorage persistence & settings state
    │   └── AudioManager.ts          # Procedural Web Audio API sound engine
    ├── game/
    │   ├── HorizonEngine.ts         # Main Babylon.js engine loop, lighting, inputs & state coordinator
    │   ├── data/
    │   │   └── worldCatalog.ts      # Vehicle specs, Mission definitions & Data Shard coordinates
    │   ├── materials/
    │   │   └── MaterialLibrary.ts   # Procedural canvas textures & PBR materials
    │   ├── world/
    │   │   └── CityBuilder.ts       # Connected roads, intersections, skyscrapers, park, garage & skyline
    │   ├── entities/
    │   │   ├── PlayerController.ts  # Articulated humanoid character, locomotion & animations
    │   │   └── VehicleController.ts # 3D car builder, suspension, drift/nitro & driving physics
    │   └── systems/
    │       ├── CollisionSystem.ts   # AABB & circle wall-sliding collision + camera ray clipping
    │       ├── CameraController.ts  # Smooth third-person spring camera & menu orbit camera
    │       ├── MissionManager.ts    # 3D checkpoint beacons, arrival detection, timers & shards
    │       └── TrafficAndNPCSystem.ts # Road-following AI cars & sidewalk pedestrians
    └── components/
        ├── MainMenu.tsx             # Live 3D backdrop Main Menu (Play, Continue, Vehicle Select)
        ├── HUD.tsx                  # Tactical gameplay overlay, objectives, notifications & prompts
        ├── Minimap.tsx              # Real-time 2D canvas radar with roads, buildings & beacons
        ├── Speedometer.tsx          # Digital KM/H, Gear, RPM bar & Nitro gauge
        └── Modals.tsx               # Pause, Settings, Controls, Missions/Garage & Reset modals
```

---

## 4. Running Locally & Production Build

### Install Dependencies
```bash
npm install
```

### Start Development Server
```bash
npm run dev
```
Then open `http://localhost:5173` in your browser.

### Build for Production
```bash
npm run build
```
This runs TypeScript type checking (`tsc -b`) and bundles the optimized production output into `dist/`.

### Preview Production Build Locally
```bash
npm run preview
```

### Publishing Online
The `dist/` directory generated by `npm run build` is a self-contained static web application (with zero external asset dependencies) and can be deployed directly to Vercel, Netlify, Cloudflare Pages, GitHub Pages, or any static hosting provider.
